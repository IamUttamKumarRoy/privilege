@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Point Table
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
             
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example_B">
                    <thead>
                      <tr>
                        <td style="text-align:center">Rank</td> 
                        <td style="text-align:left">Teams</td> 
                        <td style="text-align:center">Mat</td>
                        <td style="text-align:center">Won</td>
                        <td style="text-align:center">Lost</td>
                        <td style="text-align:center">Tied</td>
                        <td style="text-align:center">NR</td>
                        <td style="text-align:center">Pts</td>
                        <td style="text-align:center">NRR</td> 
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $inc = 1;
                      $odd_even = "even";
                      @endphp
  
                      @if(!empty($points_table))
                        @foreach($points_table as $point_table)                          
                          @if($inc%2 == 0)                              
                            @php
                            $odd_even = "even"  
                            @endphp                                                    
                          @else 
                            @php
                            $odd_even = "odd"  
                            @endphp
                          @endif
                        <tr class="{{ $odd_even }}">
                            <td style="text-align:center">{{ $inc }}</td>  
                            <td>{{ $team_data[$point_table->team_id] }}</td>  
                            <td style="text-align:center">{{ $point_table->match_played }}</td> 
                            <td style="text-align:center">{{ $point_table->match_won }}</td> 
                            <td style="text-align:center">{{ $point_table->match_lost }}</td> 
                            <td style="text-align:center">{{ $point_table->match_tied }}</td> 
                            <td style="text-align:center">{{ $point_table->match_no_result }}</td> 
                            <td style="text-align:center">{{ $point_table->match_points }}</td> 
                            <td style="text-align:center">
                              
                              {{ number_format(($point_table->match_net_run_rate/$point_table->match_played),3) }}
                            </td> 
                        </tr>
                        @php
                        $inc += 1; 
                        @endphp
                        @endforeach
                      @endif  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
@endsection