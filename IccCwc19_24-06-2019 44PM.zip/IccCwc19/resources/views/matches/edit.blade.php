@extends('layouts.sb_admin')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit Tournament
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('tournaments.update', $tournament->id) }}" enctype="multipart/form-data" >
            @csrf
            @method('PATCH') 
            <div class="form-group">
                <label for="tournament_name">tournament Name:</label>
                <input type="text" class="form-control" name="tournament_name" value="{{$tournament->tournament_name}}"/>
            </div>
            <div class="form-group">
                <label for="team_number">Team Number:</label>
                <input type="text" class="form-control" name="team_number"  value="{{$tournament->team_number}}"/>
            </div> 
            <div class="form-group">
                <label for="started_date">Started Date:</label>
                <input type="text" class="form-control datePicCls" name="started_date"  value="{{date("m/d/Y", strtotime($tournament->started_date)) }}"/>
            </div>
            <div class="form-group">
                <label for="ended_date">Ended Date:</label>
                <input type="text" class="form-control datePicCls" name="ended_date"  value="{{date("m/d/Y", strtotime($tournament->ended_date)) }}"/>
            </div>    
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
  </div>
</div>
@endsection