@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Match
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            <a href="{{ route('matches.create')}}" class="btn btn-outline btn-primary">Add New</a>
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                       <!--  <td>Tournament</td> -->
                        <td>Match No</td>
                        <!-- <td>Country</td> -->
                        <td>City</td>
                        <td>Venu</td>
                        <td>Time</td>
                        <td>Team 1</td>
                        <td>Team 2</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $inc = 1;
                      $odd_even = "even";
                      @endphp
  
                      @if(!empty($matches))
                        @foreach($matches as $match)                          
                          @if($inc%2 == 0)                              
                            @php
                            $odd_even = "even"  
                            @endphp                                                    
                          @else 
                            @php
                            $odd_even = "odd"  
                            @endphp
                          @endif
                        <tr class="{{ $odd_even }}">
                            <td>{{ $match->id }}</td> 
                            <!-- <td>{{ $tournament_list_arr[$match->tournament_id] }}</td>  -->
                            <td style="text-align:center">{{ $match->match_no }}</td> 
                            <!-- <td>
                              @if(!empty($country_list[$match->country_id]))  
                                     {{ $country_list[$match->country_id] }}                                              
                                @else  
                                  {{ $match->country_id }}
                               @endif
                            </td>  -->
                            <td>{{ $city_list[$match->city_id] }}</td> 
                            <td>{{ $match->venu }}</td> 
                            <td>
                              {{ date("M d,D H:i A", strtotime($match->time_of_play)) }}
                            </td> 
                            <td>{{ $team_list_arr[$match->team_one_id] }}</td> 
                            <td>{{ $team_list_arr[$match->team_two_id] }}</td> 
                            <td>
                              @if(!in_array($match->id, $match_result_ids) )                              
                                <a href="{{ route('match_results.create',$match->id)}}" class="btn btn-primary">Result</a> 
                              @endif 
                              
                            </td>
                            <td>
                              <a href="{{ route('matches.show',$match->id)}}" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="{{ route('matches.edit',$match->id)}}" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="{{ route('matches.destroy', $match->id)}}" method="post">
                                  @csrf
                                  @method('DELETE')
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        @php
                        $inc += 1; 
                        @endphp
                        @endforeach
                      @endif  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
@endsection