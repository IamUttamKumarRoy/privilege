@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Section Type
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            <a href="{{ route('teams.create')}}" class="btn btn-outline btn-primary">Add New</a>
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                        <td>Team Name</td>
                        <td>Short Name</td>
                        <td>Logo</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $inc = 1;
                      $odd_even = "even";
                      @endphp
  
                      @if(!empty($teams))
                        @foreach($teams as $team)                          
                          @if($inc%2 == 0)                              
                            @php
                            $odd_even = "even"  
                            @endphp                                                    
                          @else 
                            @php
                            $odd_even = "odd"  
                            @endphp
                          @endif
                        <tr class="{{ $odd_even }}">
                            <td>{{ $team->id }}</td> 
                            <td>{{ $team->team_name }}</td> 
                            <td>{{ $team->short_name }}</td> 
                            <td>
                              <img src="{{ URL::to('assets/logo/' . $team->logo) }}" alt="" class="logo">
                            </td> 
                            <td>
                              <a href="{{ route('teams.show',$team->id)}}" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="{{ route('teams.edit',$team->id)}}" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="{{ route('teams.destroy', $team->id)}}" method="post">
                                  @csrf
                                  @method('DELETE')
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        @php
                        $inc += 1; 
                        @endphp
                        @endforeach
                      @endif  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
@endsection