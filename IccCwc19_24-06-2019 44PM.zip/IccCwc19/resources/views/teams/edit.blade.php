@extends('layouts.sb_admin')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit Book
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('teams.update', $team->id) }}" enctype="multipart/form-data" >
            @csrf
            @method('PATCH') 
            <div class="form-group">
                <label for="team_name">Team Name:</label>
                <input type="text" class="form-control" name="team_name" value="{{$team->team_name}}"/>
            </div>
            <div class="form-group">
                <label for="short_name">Short Name:</label>
                <input type="text" class="form-control" name="short_name"  value="{{$team->short_name}}"/>
            </div> 
            <div class="form-group">
                <label for="description">Logo:</label>
                <input type="file" class="form-control" name="logo"/>
            </div>  
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
  </div>
</div>
@endsection