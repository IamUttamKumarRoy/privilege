@extends('layouts.sb_admin')

@section('content')
            <h1>Team {{ $team->team_name }}</h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Book Title:</strong> {{ $team->short_name }}<br> 
        </p>
        <p>
            <img src="{{ URL::to('assets/logo/' . $team->logo) }}" alt="" class="img-responsive"> <br> 
        </p>
    </div>
@endsection