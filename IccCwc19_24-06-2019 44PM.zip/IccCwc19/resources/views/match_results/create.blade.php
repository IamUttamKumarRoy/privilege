@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
               Match Result
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('match_results.store') }}" enctype="multipart/form-data" >
                    @csrf 

                    <table class="table table-striped">  
                        <thead>
                          <tr> 
                            <td></td>
                            <td></td> 
                          </tr>
                        </thead>                      
                        <tbody>
                            <tr>
                                <td>Tournament</td>
                                <td>{{ $tournament_list[$match->tournament_id] }} </td> 
                            </tr>
                            <tr>
                                <td>Match No</td>
                                <td>{{ $match->match_no }} </td> 
                            </tr>   
                            <tr>
                                <td>Venu</td>
                                <td>{{ $match->venu }} ,{{ $city_list[$match->city_id] }} </td> 
                            </tr>            
                        </tbody>
                    </table> 
                    <input type="hidden" name="tournament_id" value="{{ $match->tournament_id }}"/>
                    <input type="hidden" name="match_id" value="{{ $match->id }}"/>
                    <input type="hidden" name="team_id" value="{{ $match->team_one_id }}"/>
                    <input type="hidden" name="team_two_id" value="{{ $match->team_two_id }}"/>
                    <table class="table table-striped">  
                        <thead>
                          <tr> 
                            <td colspan="2">{{ $team_list[$match->team_one_id] }}</td>
                            <td colspan="2">{{ $team_list[$match->team_two_id] }}</td> 
                          </tr>
                        </thead>                      
                        <tbody>
                            <tr>
                                <td>Result</td>
                                <td>
                                    <select class="form-control resultOneDb" name="result_id_one">
                                    @if(!empty($result_arr) )
                                        @foreach($result_arr as $result_id=> $result_name)
                                            <option value="{{ $result_id }}">{{ $result_name }}</option>
                                        @endforeach
                                    @endif 
                                    </select>
                                </td>
                                <td>Result</td>
                                <td>
                                    <select class="form-control resultTwoDb" name="result_id_two">
                                    @if(!empty($result_arr) )
                                        @foreach($result_arr as $result_id=> $result_name)
                                            <option value="{{ $result_id }}">{{ $result_name }}</option>
                                        @endforeach
                                    @endif 
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Win By Run</td>
                                <td><input type="text" class="form-control" name="win_by_run_one"/></td>
                                <td>Win By Run</td>
                                <td><input type="text" class="form-control" name="win_by_run_two"/></td>
                            </tr>
                            <tr>
                                <td>Win By Wicket</td>
                                <td><input type="text" class="form-control" name="win_by_wicket_one"/></td>
                                <td>Win By Wicket</td>
                                <td><input type="text" class="form-control" name="win_by_wicket_two"/></td>
                            </tr>
                            <tr>
                                <td>Team One Run</td>
                                <td><input type="text" class="form-control" name="team_one_run"/></td>
                                <td>Team Two Run</td>
                                <td><input type="text" class="form-control" name="team_two_run"/></td>
                            </tr>
                            <tr>
                                <td>Team One Over</td>
                                <td><input type="text" class="form-control" name="team_one_over"/></td>
                                <td>Team Two Over</td>
                                <td><input type="text" class="form-control" name="team_two_over"/></td>
                            </tr>            
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection