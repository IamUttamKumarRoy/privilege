$(document).ready(function(){

	$('.resultOneDb').on('change', function() {
	  
	  	var result_id = this.value;
	  	if( result_id==1 ) {
	  		$('.resultTwoDb').val(2) 
	  	} 
	  	else if( result_id==2 ) {
	  		$('.resultTwoDb').val(1) 
	  	}
	  	else {
	  		$('.resultTwoDb').val(result_id) 
	  	}
	  	
	});

	$('.resultTwoDb').on('change', function() {
	  
	  	var result_id = this.value;
	  	if( result_id==1 ) {
	  		$('.resultOneDb').val(2) 
	  	} 
	  	else if( result_id==2 ) {
	  		$('.resultOneDb').val(1) 
	  	}
	  	else {
	  		$('.resultOneDb').val(result_id) 
	  	}
	  	
	});

});