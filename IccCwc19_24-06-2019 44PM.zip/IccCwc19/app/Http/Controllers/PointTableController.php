<?php

namespace App\Http\Controllers;

use App\PointTable;
use App\Team;
use Illuminate\Http\Request;

class PointTableController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        $points_table = PointTable::orderBy('match_points', 'DESC')
                        ->orderBy('match_net_run_rate', 'DESC')
                        ->get();
        $team_data       = Team::where('status', 1)->pluck('team_name', 'id');

        if( !empty($team_data ) ) {
            foreach ($team_data as $team_id => $team_name ) {
               $team_list[$team_id]  = $team_name;
            }
        }

        return view('points_table.index', compact('points_table','team_data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PointTable  $pointTable
     * @return \Illuminate\Http\Response
     */
    public function show(PointTable $pointTable)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PointTable  $pointTable
     * @return \Illuminate\Http\Response
     */
    public function edit(PointTable $pointTable)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PointTable  $pointTable
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PointTable $pointTable)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PointTable  $pointTable
     * @return \Illuminate\Http\Response
     */
    public function destroy(PointTable $pointTable)
    {
        //
    }
}
