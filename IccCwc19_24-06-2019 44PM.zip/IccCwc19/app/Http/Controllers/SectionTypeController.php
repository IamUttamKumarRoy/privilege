<?php

namespace App\Http\Controllers;

use App\SectionType;
use Illuminate\Http\Request;

class SectionTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        $section_types = SectionType::all();
        return view('section_types.index', compact('section_types'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('section_types.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
             'section_type' => 'required|max:255' 
        ]);
        
        
        $section_type = SectionType::create($validatedData);

        return redirect('/section_types')->with('success', 'Section Type is successfully saved');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SectionType  $sectionType
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $section_type = SectionType::findOrFail($id);
        return view('section_types.show',compact('section_type'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SectionType  $sectionType
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $section_type = SectionType::findOrFail($id);
        return view('section_types.edit',compact('section_type'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SectionType  $sectionType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'section_type' => 'required|max:255' 
        ]);
        SectionType::whereId($id)->update($validatedData);

        return redirect('/section_types')->with('success', 'Section Type is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SectionType  $sectionType
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $section_type = SectionType::findOrFail($id);
        $section_type->delete();

        return redirect('/section_types')->with('success', 'section Type is successfully deleted');
    }
}
