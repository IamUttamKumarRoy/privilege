<?php

namespace App\Http\Controllers;

use DB;

use App\Country;
use App\State;
use App\City;
use App\Team;
use App\Tournament;
use App\Match;
use App\MatchResult;
use App\TeamResult;
use App\PointTable;
use Illuminate\Http\Request;

class MatchResultController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // Variable Declaration
        $country_list     = array();
        $state_list       = array();
        $state_list_ids   = array();
        $city_list        = array();

        $team_list       = array();
        $tournament_list = array();      
        $result_arr      = array(1=>"Win",2=>"Lost",3=>"Tied",4=>"No Result");
        $url_get_var     = $request->query();
        $match_id        = key($url_get_var);
        
        $match           = Match::findOrFail($match_id);

        $team_data       = Team::where('status', 1)->pluck('team_name', 'id');
        $tournament_data = Tournament::where('status', 1)->pluck('tournament_name', 'id');
        $country_data = Country::where('id', 230)->pluck('name', 'id');
        $state_data = State::where('country_id', 230)->pluck('name', 'id');
        

        if( !empty($country_data) ) {
            foreach ($country_data as $country_id => $country_name ) {
                $country_list[$country_id] = $country_name;
            }
        }

        if( !empty($state_data) ) {
            foreach ($state_data as $state_id => $state_name ) {
                $state_list[$state_id] = $state_name;
                $state_list_ids[$state_id] = $state_id;
            }
        }

        if( !empty($team_data ) ) {
            foreach ($team_data as $team_id => $team_name ) {
               $team_list[$team_id]  = $team_name;
            }
        }
        if( !empty($tournament_data) ) {
            foreach ($tournament_data as $tournament_id => $tournament_name ) {
                $tournament_list[$tournament_id] = $tournament_name;
            }
        }

        $city_data = City::whereIn('state_id', $state_list_ids)->orderBy('name', 'asc')->pluck('name', 'id');

        if( !empty($city_data) ) {
            foreach ($city_data as $city_id => $city_name) {
                $city_list[$city_id] = $city_name;
            }
        }


        return view('match_results.create',compact('team_list','tournament_list','match','result_arr','city_list'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {             
        // Variable 
        $team_result_data    = array();
        $match_result_data   = array();
        $point_table_data_one= array();
        $point_table_data_two= array();
        $match_result_insert = '';
        $team_result_insert  = '';
        $tournament_id       = '';
        $team_id             = '';
        $team_two_id         = '';
        $result_id_one       = '';
        $result_id_two       = '';

        $team_one_point_table_id = '';
        $team_two_point_table_id = '';

        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'match_id' => 'required',  
        ]);
 
        $tournament_id     = $submitted_data['tournament_id'];
        $team_id           = $submitted_data['team_id'];
        $team_two_id       = $submitted_data['team_two_id']; 
        $result_id_one     = $submitted_data['result_id_one']; 
        $result_id_two     = $submitted_data['result_id_two']; 

        $match_result_data['match_id']  = $validated_data['match_id']; 

        $match_result_data['winner_team_id']  = 0; 
        $match_result_data['win_by_run']      = 0; 
        $match_result_data['win_by_wicket']   = 0;  
        $match_result_data['result_id']       = $submitted_data['result_id_one']; 

        if( $submitted_data['result_id_one'] == 1  ) {
            $match_result_data['winner_team_id']  = $submitted_data['team_id']; 
            $match_result_data['win_by_run']      = $submitted_data['win_by_run_one']; 
            $match_result_data['win_by_wicket']   = $submitted_data['win_by_wicket_one'];  
        }
        else if($submitted_data['result_id_two'] == 1  ) {
            $match_result_data['winner_team_id']  = $submitted_data['team_two_id']; 
            $match_result_data['win_by_run']      = $submitted_data['win_by_run_two']; 
            $match_result_data['win_by_wicket']   = $submitted_data['win_by_wicket_two']; 
        }
        else {

        }                
        $match_result_data['status']  = 1; 

        // Team Result Insertion
        $record_inc = 0;

        $team_result_data[$record_inc]['team_id']       = $submitted_data['team_id']; 
        $team_result_data[$record_inc]['team_two_id']   = $submitted_data['team_two_id']; 
        $team_result_data[$record_inc]['result_id']     = $submitted_data['result_id_one']; 
        $team_result_data[$record_inc]['win_by_run']    = $submitted_data['win_by_run_one']; 
        $team_result_data[$record_inc]['win_by_wicket'] = $submitted_data['win_by_wicket_one']; 
        $team_result_data[$record_inc]['team_one_run']  = $submitted_data['team_one_run']; 
        $team_result_data[$record_inc]['team_two_run']  = $submitted_data['team_two_run']; 
        $team_result_data[$record_inc]['team_one_over'] = $submitted_data['team_one_over']; 
        $team_result_data[$record_inc]['team_two_over'] = $submitted_data['team_two_over'];         

        $record_inc++;

        $team_result_data[$record_inc]['team_id']       = $submitted_data['team_two_id']; 
        $team_result_data[$record_inc]['team_two_id']   = $submitted_data['team_id']; 
        $team_result_data[$record_inc]['result_id']     = $submitted_data['result_id_two']; 
        $team_result_data[$record_inc]['win_by_run']    = $submitted_data['win_by_run_two']; 
        $team_result_data[$record_inc]['win_by_wicket'] = $submitted_data['win_by_wicket_two']; 
        $team_result_data[$record_inc]['team_one_run']  = $submitted_data['team_two_run']; 
        $team_result_data[$record_inc]['team_two_run']  = $submitted_data['team_one_run']; 
        $team_result_data[$record_inc]['team_one_over'] = $submitted_data['team_two_over']; 
        $team_result_data[$record_inc]['team_two_over'] = $submitted_data['team_one_over'];
        
        // Point Table 
        $point_table_one = PointTable::where('team_id', $team_id)->first();
        $point_table_two = PointTable::where('team_id', $team_two_id)->first(); 
        
        // Team One
        $match_played       = 1;
        $match_won          = get_result($result_id_one,1);
        $match_lost         = get_result($result_id_one,2);
        $match_tied         = get_result($result_id_one,3);
        $match_no_result    = get_result($result_id_one,4);
        $match_points       = 0;

        $match_net_run_rate = 0;
        $chase_run_rate     = 0;
        $remaining_over     = 0;
        $remaining_over_run = 0;

        // Net Run Rate for Team One
        if( $result_id_one == 1 ) {
            if( $submitted_data['win_by_run_one'] > 0 ) {
                $match_net_run_rate = $submitted_data['win_by_run_one']/50;
            } else {
                $chase_run_rate     = $submitted_data['team_one_run']/$submitted_data['team_one_over']; 
                $remaining_over     = 50- $submitted_data['team_one_over']; 
                $remaining_over_run = $remaining_over*$chase_run_rate; 
                $match_net_run_rate = $remaining_over_run/50;
            }
            $match_points = 2;
        }
        else if( $result_id_one == 2 ) {
            if( $submitted_data['win_by_run_two'] > 0 ) {
                $match_net_run_rate = $submitted_data['win_by_run_two']/50;
            } else {
                $chase_run_rate     = $submitted_data['team_two_run']/$submitted_data['team_two_over']; 
                $remaining_over     = 50-$submitted_data['team_two_over']; 
                $remaining_over_run = $remaining_over*$chase_run_rate; 
                $match_net_run_rate = $remaining_over_run/50;
            }
            $match_net_run_rate = -$match_net_run_rate; 
        }
        else {
            $match_points = 1;
        }

        if( !empty($point_table_one) ) {
            $team_one_point_table_id = $point_table_one->id; 

            $match_played       += $point_table_one->match_played;
            $match_won          += $point_table_one->match_won;
            $match_lost         += $point_table_one->match_lost;
            $match_tied         += $point_table_one->match_tied;
            $match_no_result    += $point_table_one->match_no_result;
            $match_points       += $point_table_one->match_points;
            $match_net_run_rate += $point_table_one->match_net_run_rate;
        } 

        $point_table_data_one['tournament_id']     = $tournament_id;
        $point_table_data_one['team_id']           = $team_id;
        $point_table_data_one['match_played']      = $match_played;
        $point_table_data_one['match_won']         = $match_won;
        $point_table_data_one['match_lost']        = $match_lost;
        $point_table_data_one['match_tied']        = $match_tied;
        $point_table_data_one['match_no_result']   = $match_no_result;
        $point_table_data_one['match_points']      = $match_points;
        $point_table_data_one['match_net_run_rate']= $match_net_run_rate;
        $point_table_data_one['status']            = 1; 

        // Team Two 
        $match_played       = 1;
        $match_won          = get_result($result_id_two,1);
        $match_lost         = get_result($result_id_two,2);
        $match_tied         = get_result($result_id_two,3);
        $match_no_result    = get_result($result_id_two,4);
        $match_points       = 0;
        $match_net_run_rate = 0;
        $chase_run_rate     = 0;
        $remaining_over     = 0;
        $remaining_over_run = 0;

        // Net Run Rate 
        if( $result_id_two == 1 ) {
            if( $submitted_data['win_by_run_two'] > 0 ) {
                $match_net_run_rate = $submitted_data['win_by_run_two']/50;
            } else {
                $chase_run_rate     = $submitted_data['team_two_run']/$submitted_data['team_two_over']; 
                $remaining_over     = 50 - $submitted_data['team_two_over']; 
                $remaining_over_run = $remaining_over*$chase_run_rate; 
                $match_net_run_rate = $remaining_over_run/50;
            }
            $match_points = 2;
        }
        else if( $result_id_two == 2 ) {
            if( $submitted_data['win_by_run_one'] > 0 ) {
                $match_net_run_rate = $submitted_data['win_by_run_one']/50;
            } else {
                $chase_run_rate     = $submitted_data['team_one_run']/ $submitted_data['team_one_over']; 
                $remaining_over     = 50 - $submitted_data['team_one_over']; 
                $remaining_over_run = $remaining_over*$chase_run_rate; 
                $match_net_run_rate = $remaining_over_run/50;
            }
            $match_net_run_rate = -$match_net_run_rate; 
        } 
        else {
            $match_points = 1;
        }      

        if( !empty($point_table_two) ) {
            $team_two_point_table_id = $point_table_two->id;

            $match_played       += $point_table_two->match_played;
            $match_won          += $point_table_two->match_won;
            $match_lost         += $point_table_two->match_lost;
            $match_tied         += $point_table_two->match_tied;
            $match_no_result    += $point_table_two->match_no_result;
            $match_points       += $point_table_two->match_points;
            $match_net_run_rate += $point_table_two->match_net_run_rate;
        }  
        $point_table_data_two['tournament_id']     = $tournament_id;
        $point_table_data_two['team_id']           = $team_two_id;
        $point_table_data_two['match_played']      = $match_played;
        $point_table_data_two['match_won']         = $match_won;
        $point_table_data_two['match_lost']        = $match_lost;
        $point_table_data_two['match_tied']        = $match_tied;
        $point_table_data_two['match_no_result']   = $match_no_result;
        $point_table_data_two['match_points']      = $match_points;
        $point_table_data_two['match_net_run_rate']= $match_net_run_rate;
        $point_table_data_two['status']            = 1; 
        
        /*pr($point_table_data_one);
        pr($point_table_data_two);
        pr($point_table_one);
        pr($point_table_two);
        die;*/    
        // Point Table
        DB::beginTransaction();
        $match_result_insert = MatchResult::create($match_result_data);
        $team_result_insert = TeamResult::insert($team_result_data);

        if( !$match_result_insert || !$team_result_insert )
        {
            DB::rollBack();
            return redirect('/matches/create')->with('success', 'Match save unsuccessfull');
        } else { 
            DB::commit();

            DB::beginTransaction();

            if( $team_one_point_table_id == null ) {
                $point_team_one = PointTable::create($point_table_data_one);
            } else {
                $point_team_one = PointTable::whereId($team_one_point_table_id)->update($point_table_data_one);
            }

            if( $team_two_point_table_id == null ) {
                $point_team_two = PointTable::create($point_table_data_two);
            } else {
                $point_team_two = PointTable::whereId($team_two_point_table_id)->update($point_table_data_two);
            }  
            
            if( !$point_team_one || !$point_team_two )
            {
                DB::rollBack(); 
            } else { 
                DB::commit();
            }

            return redirect('/matches')->with('success', 'Match is successfully saved');
        } 
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MatchResult  $matchResult
     * @return \Illuminate\Http\Response
     */
    public function show(MatchResult $matchResult)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MatchResult  $matchResult
     * @return \Illuminate\Http\Response
     */
    public function edit(MatchResult $matchResult)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MatchResult  $matchResult
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MatchResult $matchResult)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MatchResult  $matchResult
     * @return \Illuminate\Http\Response
     */
    public function destroy(MatchResult $matchResult)
    {
        //
    }
}
