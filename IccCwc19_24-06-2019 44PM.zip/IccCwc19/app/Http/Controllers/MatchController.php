<?php

namespace App\Http\Controllers;

use App\Country;
use App\State;
use App\City;
use App\Team;
use App\Tournament;
use App\Match;
use App\MatchResult;
use Illuminate\Http\Request;

class MatchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Variable Declaration
        $match_result_ids = array();
        $country_list     = array();
        $state_list       = array();
        $state_list_ids   = array();
        $city_list        = array();
        $tournament_list_arr =  array();
        $team_list_arr       =  array();

        $matches = Match::all();
        $match_results = MatchResult::where('status', 1)->pluck('match_id', 'match_id');

        $team_list = Team::where('status', 1)->pluck('team_name', 'id');
        $tournament_list = Tournament::where('status', 1)->pluck('tournament_name', 'id');
        $country_data = Country::where('status', null)->pluck('name', 'id');
        $state_data = State::where('country_id', 230)->pluck('name', 'id');

        if( !empty($match_results) ) {
            foreach ($match_results as $key => $match_id) {
                $match_result_ids[$match_id] = $match_id;
            }
        }
        if( !empty($team_list ) )
        {
            foreach ($team_list as $team_id => $team_name) {
               $team_list_arr[$team_id] = $team_name;
            }
        } 
        if( !empty($tournament_list ) )
        {
            foreach ($tournament_list as $tournament_id => $tournament_name ) {
                $tournament_list_arr[$tournament_id] = $tournament_name;
            }
        }    

        if( !empty($country_data) ) {
            foreach ($country_data as $country_id => $country_name ) {
                $country_list[$country_id] = $country_name;
            }
        }

        if( !empty($state_data) ) {
            foreach ($state_data as $state_id => $state_name ) {
                $state_list[$state_id] = $state_name;
                $state_list_ids[$state_id] = $state_id;
            }
        }
        $city_data = City::whereIn('state_id', $state_list_ids)->pluck('name', 'id');

        if( !empty($city_data) ) {
            foreach ($city_data as $city_id => $city_name) {
                $city_list[$city_id] = $city_name;
            }
        }
 
        

        return view('matches.index', compact('matches','match_result_ids','team_list_arr','tournament_list_arr','country_list','state_list','city_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
        // Variable Declaration
        $country_list     = array();
        $state_list       = array();
        $state_list_ids   = array();
        $city_list        = array();

        $team_list = Team::where('status', 1)->pluck('team_name', 'id');
        $tournament_list = Tournament::where('status', 1)->pluck('tournament_name', 'id');
        $country_data = Country::where('id', 230)->pluck('name', 'id');
        $state_data = State::where('country_id', 230)->pluck('name', 'id');
        

        if( !empty($country_data) ) {
            foreach ($country_data as $country_id => $country_name ) {
                $country_list[$country_id] = $country_name;
            }
        }

        if( !empty($state_data) ) {
            foreach ($state_data as $state_id => $state_name ) {
                $state_list[$state_id] = $state_name;
                $state_list_ids[$state_id] = $state_id;
            }
        }
        $city_data = City::whereIn('state_id', $state_list_ids)->orderBy('name', 'asc')->pluck('name', 'id');

        if( !empty($city_data) ) {
            foreach ($city_data as $city_id => $city_name) {
                $city_list[$city_id] = $city_name;
            }
        }
        
        
        return view('matches.create',compact('team_list','tournament_list','country_list','state_list','city_list'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'tournament_id' => 'required', 
            'match_no' => 'required', 
            'venu'     => 'required',  
            'time_of_play'    => 'required',  
            'country_id'    => 'required',  
            'city_id'    => 'required',  
            'team_one_id'    => 'required',  
            'team_two_id'      => 'required'  
        ]); 
        $submitted_data['status']  = 1;
        $submitted_data['time_of_play']  = date("Y-m-d H:i:s", strtotime($submitted_data['time_of_play']));
        //$submitted_data['time_zone']  = date("Y-m-d H:i:s", strtotime($submitted_data['time_zone']));
        
        if(Match::create($submitted_data)){
            return redirect('/matches')->with('success', 'Match is successfully saved');
        }
        else {
            return redirect('/matches/create')->with('success', 'Match save unsuccessfull');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function show(Match $match)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function edit(Match $match)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Match $match)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function destroy(Match $match)
    {
        //
    }
}
