<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PointTable extends Model
{ 
	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'tournament_id',
        'team_id', 
        'match_played', 
        'match_won', 
        'match_lost', 
        'match_tied', 
        'match_no_result', 
        'match_points', 
        'match_net_run_rate', 
        'status'
    ];
}
