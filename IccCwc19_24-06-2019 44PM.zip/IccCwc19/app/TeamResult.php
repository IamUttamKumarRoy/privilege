<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamResult extends Model
{	
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'team_id',
        'team_two_id',
        'result_id',
        'win_by_run',
        'win_by_wicket', 
        'team_one_run', 
        'team_one_over', 
        'team_two_over' 
    ];
}
