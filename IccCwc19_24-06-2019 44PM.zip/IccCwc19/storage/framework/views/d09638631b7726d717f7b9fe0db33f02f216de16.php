<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Section Type
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            <a href="<?php echo e(route('privilege_menus.create')); ?>" class="btn btn-outline btn-primary">Add New</a>
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                        <td>Privilege Name</td>
                        <td>Uri</td>
                        <td>Method</td>
                        <td>Action</td>
                        <td>Controller</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $inc = 1;
                      $odd_even = "even";
                      ?>
  
                      <?php if(!empty($privilege_menus)): ?>
                        <?php $__currentLoopData = $privilege_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilege_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                          
                          <?php if($inc%2 == 0): ?>                              
                            <?php
                            $odd_even = "even"  
                            ?>                                                    
                          <?php else: ?> 
                            <?php
                            $odd_even = "odd"  
                            ?>
                          <?php endif; ?>
                        <tr class="<?php echo e($odd_even); ?>">
                            <td><?php echo e($privilege_menu->id); ?></td>
                            <td><?php echo e($privilege_menu->privilege_name); ?></td>
                            <td><?php echo e($privilege_menu->uri); ?></td> 
                            <td><?php echo e($privilege_menu->methods); ?></td> 
                            <td><?php echo e($privilege_menu->action); ?></td> 
                            <td><?php echo e($privilege_menu->controller); ?></td> 
                            <td>
                              <a href="<?php echo e(route('privilege_menus.show',$privilege_menu->id)); ?>" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="<?php echo e(route('privilege_menus.edit',$privilege_menu->id)); ?>" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="<?php echo e(route('privilege_menus.destroy', $privilege_menu->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                        $inc += 1; 
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/privilege_menus/index.blade.php ENDPATH**/ ?>