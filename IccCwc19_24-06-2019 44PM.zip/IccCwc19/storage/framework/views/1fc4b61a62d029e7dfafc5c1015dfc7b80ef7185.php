<?php $__env->startSection('content'); ?>
            <h1>Tournament <?php echo e($tournament->tournament_name); ?></h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Tournament Team:</strong> <?php echo e($tournament->team_number); ?><br> 
        </p>
        <p>
            <strong>Started Date:</strong> <?php echo e($tournament->started_date); ?><br> 
        </p>
        <p>
            <strong>Ended Date:</strong> <?php echo e($tournament->ended_date); ?><br> 
        </p> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/tournaments/show.blade.php ENDPATH**/ ?>