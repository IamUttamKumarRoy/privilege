<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Section Type
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('teams.store')); ?>" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?> 
                    <div class="form-group">
                        <label for="section_name">Team Name:</label>
                        <input type="text" class="form-control" name="team_name"/>
                    </div>
                    <div class="form-group">
                        <label for="head_title">Short Name:</label>
                        <input type="text" class="form-control" name="short_name"/>
                    </div> 
                    <div class="form-group">
                        <label for="description">Logo:</label>
                        <input type="file" class="form-control" name="logo"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/teams/create.blade.php ENDPATH**/ ?>