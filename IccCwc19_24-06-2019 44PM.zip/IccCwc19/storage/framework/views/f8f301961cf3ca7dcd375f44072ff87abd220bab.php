<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Match
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('matches.store')); ?>" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?> 
                    <div class="form-group">
                        <label>Tournament</label>
                        <select class="form-control" name="tournament_id">
                        <?php if(!empty($tournament_list) ): ?>
                            <?php $__currentLoopData = $tournament_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament_id=> $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tournament_id); ?>"><?php echo e($tournament); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="match_no">Match No:</label>
                        <input type="text" class="form-control" name="match_no"/>
                    </div>
                    <div class="form-group">
                        <label for="country_id">Country:</label> 
                        <select class="form-control" name="country_id">
                        <?php if(!empty($country_list) ): ?>
                            <?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country_id=> $country_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country_id); ?>"><?php echo e($country_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city_id">City:</label> 
                        <select class="form-control" name="city_id">
                        <?php if(!empty($city_list) ): ?>
                            <?php $__currentLoopData = $city_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city_id=> $city_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city_id); ?>"><?php echo e($city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="venu">Venu:</label>
                        <input type="text" class="form-control" name="venu"/>
                    </div> 
                    <div class="form-group">
                        <label for="time_of_play">Time Of Play:</label>
                        <input type="text" class="form-control dateTimePicCls" name="time_of_play"/>
                    </div> 
                    <div class="form-group">
                        <label>Team 1</label>
                        <select class="form-control" name="team_one_id">
                        <?php if(!empty($team_list) ): ?>
                            <?php $__currentLoopData = $team_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team_id=> $team_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team_id); ?>"><?php echo e($team_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Team 2</label>
                        <select class="form-control" name="team_two_id">
                        <?php if(!empty($team_list) ): ?>
                            <?php $__currentLoopData = $team_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team_id=> $team_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team_id); ?>"><?php echo e($team_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/matches/create.blade.php ENDPATH**/ ?>