<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
               Match Result
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('match_results.store')); ?>" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?> 

                    <table class="table table-striped">  
                        <thead>
                          <tr> 
                            <td></td>
                            <td></td> 
                          </tr>
                        </thead>                      
                        <tbody>
                            <tr>
                                <td>Tournament</td>
                                <td><?php echo e($tournament_list[$match->tournament_id]); ?> </td> 
                            </tr>
                            <tr>
                                <td>Match No</td>
                                <td><?php echo e($match->match_no); ?> </td> 
                            </tr>   
                            <tr>
                                <td>Venu</td>
                                <td><?php echo e($match->venu); ?> ,<?php echo e($city_list[$match->city_id]); ?> </td> 
                            </tr>            
                        </tbody>
                    </table> 
                    <input type="hidden" name="tournament_id" value="<?php echo e($match->tournament_id); ?>"/>
                    <input type="hidden" name="match_id" value="<?php echo e($match->id); ?>"/>
                    <input type="hidden" name="team_id" value="<?php echo e($match->team_one_id); ?>"/>
                    <input type="hidden" name="team_two_id" value="<?php echo e($match->team_two_id); ?>"/>
                    <table class="table table-striped">  
                        <thead>
                          <tr> 
                            <td colspan="2"><?php echo e($team_list[$match->team_one_id]); ?></td>
                            <td colspan="2"><?php echo e($team_list[$match->team_two_id]); ?></td> 
                          </tr>
                        </thead>                      
                        <tbody>
                            <tr>
                                <td>Result</td>
                                <td>
                                    <select class="form-control resultOneDb" name="result_id_one">
                                    <?php if(!empty($result_arr) ): ?>
                                        <?php $__currentLoopData = $result_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_id=> $result_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($result_id); ?>"><?php echo e($result_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> 
                                    </select>
                                </td>
                                <td>Result</td>
                                <td>
                                    <select class="form-control resultTwoDb" name="result_id_two">
                                    <?php if(!empty($result_arr) ): ?>
                                        <?php $__currentLoopData = $result_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_id=> $result_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($result_id); ?>"><?php echo e($result_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> 
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Win By Run</td>
                                <td><input type="text" class="form-control" name="win_by_run_one"/></td>
                                <td>Win By Run</td>
                                <td><input type="text" class="form-control" name="win_by_run_two"/></td>
                            </tr>
                            <tr>
                                <td>Win By Wicket</td>
                                <td><input type="text" class="form-control" name="win_by_wicket_one"/></td>
                                <td>Win By Wicket</td>
                                <td><input type="text" class="form-control" name="win_by_wicket_two"/></td>
                            </tr>
                            <tr>
                                <td>Team One Run</td>
                                <td><input type="text" class="form-control" name="team_one_run"/></td>
                                <td>Team Two Run</td>
                                <td><input type="text" class="form-control" name="team_two_run"/></td>
                            </tr>
                            <tr>
                                <td>Team One Over</td>
                                <td><input type="text" class="form-control" name="team_one_over"/></td>
                                <td>Team Two Over</td>
                                <td><input type="text" class="form-control" name="team_two_over"/></td>
                            </tr>            
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/match_results/create.blade.php ENDPATH**/ ?>