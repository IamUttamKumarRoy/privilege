<?php
/*
Plugin Name: Udev Basic Plugin
Plugin URI: https://www.uttamkumarroy.com/plugin/udev-basic-plugin
Description: Plugin Basic
Text Domain: udev-plugin-basic
Version: 1.0.0
Author: Uttam Kumar Roy
Author URI: https://www.uttamkumarroy.com/
*/

if( !defined( 'WPINC' ) ) {
    die();
}


if( !class_exists( 'UDEV_Basic_Plugin' ) ) {

	final class UDEV_Basic_Plugin 
	{
		private static $instance;

		//do not change below constant
        const DS = '/';

		public static function getInstance() {

            if (self::$instance == null) {
                self::$instance = new self;
                self::$instance->dir = dirname(__FILE__);
                self::$instance->autoload();
                self::$instance->actions();
            } else {
                throw new BadFunctionCallException(sprintf('Plugin %s already instantiated', __CLASS__));
            }
            return self::$instance;
        }

        public function autoload() {
            require_once ( $this->dir . self::DS . "Udev" . self::DS . "Autoloader" . self::DS . "LoaderClass.php" );

            // Add the Autoloader
            $loader = new Udev_Autoloader_LoaderClass( "RPS", dirname( __FILE__ ) );
            $loader->register( );
        }

        /**
         * call all actions/filters here
         */
        private function actions() {
        	
	        add_action('admin_menu', array($this,'udev_plugin_settings'));

        }


		function udev_plugin_settings() {
		    $page_title = 'Udev Basic ';
		    $menu_title = 'Udev Basic ';
		    $capability = 'edit_posts';
		    $menu_slug  = 'udev_basic_plugin';
		    $function   = 'udev_basic_plugin_display';
		    $icon_url   = '';
		    $position   = 25;

		    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,$function), $icon_url, $position );
		}
		function udev_basic_plugin_display()
		{
			$db_class = Udev_Install_Db::getInstance();
			$db_class->createDB();
	            
			?>
			<div class="wrap">        
			<h2><i id="icon-edit" class="dashicons dashicons-admin-generic" style="line-height: 1.5em;"></i>&nbsp;Settings</h2>
			
				
		    </div>
			<?php 
		}

	}

	UDEV_Basic_Plugin::getInstance();
}
