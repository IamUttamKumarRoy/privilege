<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','google_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Get the list items for the list
     */
    public function list_category()
    {
        return $this->hasMany(ListCategory::class);
    }

    /**
     * Get the listings for the Listing Category.
     */
    public function listings()
    {
        return $this->hasMany(Listing::class);
    }

    /**
     * Get the list items for the list
     */
    public function list_items()
    {
        return $this->hasMany(ListItem::class);
    }

    /**
     * Get the list items fields for the list item
     */
    public function list_item_fields()
    {
        return $this->hasMany(ListItemField::class);
    }

    /**
     * Get the list items fields for the list item
     */
    public function list_item_progress()
    {
        return $this->hasMany(ListItemProgress::class);
    }

}
