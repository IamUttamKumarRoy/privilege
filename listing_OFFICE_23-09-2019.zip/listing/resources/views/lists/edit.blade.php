@extends('layouts.layout')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit List</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('lists.index') }}"> Back</a>
            </div>
        </div>
    </div>
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    <form action="{{ route('lists.update',$list->id) }}" method="POST">
        @csrf
        @method('PUT')
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Parent:</strong>
                    <select class="form-control" name="parent_id">
                        <option value="">Select Parent</option>    
                    @if(!empty($list_data) )
                        @foreach($list_data as $list_id => $list_title)
                            <option value="{{ $list_id }}">{{ $list_title }}</option>
                        @endforeach
                    @endif 
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>List Type:</strong>
                    <input type="text" name="list_type" value="{{ $list->list_type }}" class="form-control" placeholder="List Type">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>List Title:</strong>
                    <input type="text" name="list_title" value="{{ $list->list_title }}" class="form-control" placeholder="List Title">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>List Body:</strong>
                    <textarea class="form-control" style="height:150px" name="list_body" placeholder="List Body">{{ $list->list_body }}</textarea>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
@endsection