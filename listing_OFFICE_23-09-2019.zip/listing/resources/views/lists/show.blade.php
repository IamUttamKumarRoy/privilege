@extends('layouts.layout')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show List</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('lists.index') }}"> Back</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                {{ $list->list_title }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Details:</strong>
                {{ $list->list_body }}
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Details:</strong>
                

                @if(!empty($list->list_items) )
                    @foreach($list->list_items as $list_id => $list_item)
                        <span>{{ $list_item->item_title }}</span>
                        <span>{{ $list_item->item_body }}</span><br/>
                    @endforeach
                @endif 

                {{ pr($list->list_items) }}
            </div>
        </div>
    </div>
@endsection