<hr>
<div class="form-group row mb-0">
 <div class="col-md-8 offset-md-4">
    <a href="<?php echo e(url('/auth/redirect/facebook')); ?>" class="btn btn-primary"><i class="fa fa-facebook"></i> Facebook</a>
</div>
</div>
<?php echo $__env->make('adminlte::login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\listing\resources\views/auth/login.blade.php ENDPATH**/ ?>