<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');



Route::group(['middleware' => 'auth'], function () {
	
	Route::resource('list_category','ListCategoryController');
	Route::resource('lists','ListingController');
	Route::resource('list_items','ListItemController');
	
 	Route::get('/mylist/{list}', 'ListingController@mylist');

});

Route::get('google', function () {
    return view('googleAuth');
});

    
//Route::get('auth/google', 'Auth\LoginController@redirectToGoogle');
//Route::get('auth/google/callback', 'Auth\LoginController@handleGoogleCallback');

Route::get('/auth/redirect/{provider}', 'SocialController@redirect');
Route::get('/callback/{provider}', 'SocialController@callback');


Auth::routes();
/*Route::get('auth/facebook', 'Auth\FacebookloginController@redirectToFacebook');
Route::get('auth/facebook/callback', 'Auth\FacebookloginController@handleFacebookCallback');*/

Route::get('login/github', 'Auth\LoginController@redirectToProvider');
Route::get('login/github/callback', 'Auth\LoginController@handleProviderCallback');