<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Comment;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /*
        $post = Post::find(1);
		$comments = $post->comments;
		pr($post);
		pr($comments);
		*/
		/*
		$post = Post::find(1);
		$comment = new Comment;
		$comment->comment = "Hi ItSolutionStuff.com";
		$post = $post->comments()->save($comment);
		*/
		$post = Post::find(1);
		$comment1 = new Comment;
		$comment1->comment = "Hi ItSolutionStuff.com Comment 1";
		$comment2 = new Comment;
		$comment2->comment = "Hi ItSolutionStuff.com Comment 2";
		$post = $post->comments()->saveMany([$comment1, $comment2]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $comment = Comment::find(1);
		$post = $comment->post;
		dd($post);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
