<?php
if(!defined('WPINC')) {
    die();
}

if( !class_exists( 'UWebDev_Admin_Menu_AdminPanel' ) ) {

	final class UWebDev_Admin_Menu_AdminPanel 
	{
		private static $instance;
    
	    public static function getInstance() {
	        if(self::$instance==null) {
	            self::$instance = new self; 

	            self::$instance->TD = UWebDev_Portfolio::TD;
            	self::$instance->actions();
	        }
	        
	        return self::$instance;
	    }
	    
	    private function __construct() {
	        ;
	    }

	     public function actions() {
	     	add_action('admin_menu', array($this,'adminMenu'));
	     }

	     public function adminMenu() {
	     	add_menu_page('Uweb Dev ', 'Uweb Dev Page', 'manage_options', 'uwebdev_page', array($this,'department') );

	     	add_submenu_page('uwebdev_page', 'Department', 'Department', 'manage_options', 'uwebdev_page' );

	     	add_submenu_page( 'uwebdev_page', 'Students', 'Students', 'manage_options', 'uwebdev_subject_page', array($this,'subjectMenu' ));
	     }

	     public function department() {
	     	$dept_obj = UWebDev_Admin_Menu_Department::getInstance('uwebdev_page');
        	$dept_obj->showContent();        	
	     }	
	     public function subjectMenu() {
	     	$dept_obj = UWebDev_Admin_Menu_Department::getInstance('uwebdev_subject_page');
        	$dept_obj->showContent();
	     }	     
	}
}