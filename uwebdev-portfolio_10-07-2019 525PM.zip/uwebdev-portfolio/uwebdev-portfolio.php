<?php
/*
Plugin Name: UWebDev Portfolio Management
Plugin URI: https://www.uwebdev.com/wp/plugin/uwebdev-portfolio
Description: UWebDev Portfolio Management
Text Domain: uwebdev-portfolio
Version: 1.0.0
Author: Uttam Kumar Roy
Author URI: https://www.uttamkumarroy.com/
*/

if( !defined( 'WPINC' ) ) {
    die();
}


if( !class_exists( 'UWebDev_Portfolio' ) ) {

	final class UWebDev_Portfolio 
	{
		private static $instance;
        private $dir, $url; 

        const VER = 2.7;

		//do not change below constant
        const DS = '/';
        const PLUGIN_SLUG = 'uwebdev_portfolio';
        const TD = 'uwebdev-portfolio';
        const TABLE_PREFIX = 'uwebdev_';
        const FILE = __FILE__;

		public static function getInstance() {

            if (self::$instance == null) {
                self::$instance = new self;
                self::$instance->dir = dirname(__FILE__);
                self::$instance->setDbTables();
                self::$instance->autoload();
                self::$instance->actions();

            } else {
                throw new BadFunctionCallException(sprintf('Plugin %s already instantiated', __CLASS__));
            }
            return self::$instance;
        }

        public function autoload() {
            require_once ( $this->dir . self::DS . "UWebDev" . self::DS . "Autoloader" . self::DS . "LoaderClass.php" );

            // Add the Autoloader
            $loader = new UWebDev_Autoloader_LoaderClass( "UWebDev", dirname( __FILE__ ) );
            $loader->register( );


        }

        /**
         * Return prefix for plugin database tables
         * @return string
         */
        public static function getTablePrefix() {
            global $wpdb;
            return $wpdb->prefix . self::TABLE_PREFIX;
        }

         private function check_for_updates() {
         	$db_class = UWebDev_InstallDb::getInstance();
	        $db_class->createDB();
         }
        /**
         * call all actions/filters here
         */
        private function actions() {
        	register_activation_hook(__FILE__, array($this, 'activate'));
            register_deactivation_hook(__FILE__, array($this, 'deactivate'));

            //load plugin text domain
            add_action( 'plugins_loaded', array($this,'loadTextdomain') );
            
            //multisite install tables after adding a new blog
            add_action( 'wpmu_new_blog', array( $this, 'onCreateBlog'), 10, 6 );
            //delete tables after blog is deleted
            add_filter( 'wpmu_drop_tables', array($this, 'onDeleteBlog'), 10, 2 );

	        //add_action('admin_menu', array($this,'uwebdev_plugin_settings'));

	        if ( is_admin() ) { 
	            //check for updates
	            //$this->check_for_updates();

                //register menus
                UWebDev_Admin_Menu_AdminPanel::getInstance();

                echo "OK";
            }  
        }

        public function loadTextdomain() {
            //http://codex.wordpress.org/I18n_for_WordPress_Developers
            load_plugin_textdomain( self::TD, false, dirname( plugin_basename( __FILE__ ) ) . '/lang' ); 
        }

        public function activate( $network_wide ) {
            // uncaught exception doesn't prevent plugin from being activated, therefore replace it with fatal error so it does
            set_exception_handler(create_function('$e', 'trigger_error($e->getMessage(), E_USER_ERROR);'));

            global $wpdb;

            if ( is_multisite() && $network_wide ) {

                // Get all blogs in the network and activate plugin on each one
                $blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );

                foreach ( $blog_ids as $blog_id ) {
                    switch_to_blog( $blog_id );
                    //install/update all required database
                    $db_class = UWebDev_InstallDb::getInstance();
                    $db_class->createDB(); 

                    //predefine all options
                    $option_class = UWebDev_DefaultOptions::getInstance();
                    $option_class->createOptions();

                    restore_current_blog();
                }

            } else {
                //install/update all required database
                $db_class = UWebDev_InstallDb::getInstance();
                $db_class->createDB(); 

                //predefine all options
                $option_class = UWebDev_DefaultOptions::getInstance();
                $option_class->createOptions();
            }
        }

        public function deactivate() {

        }

        public function onCreateBlog( $blog_id, $user_id, $domain, $path, $site_id, $meta ) {
            $plugin = plugin_basename( __FILE__ );

            if ( is_plugin_active_for_network( $plugin ) ) {
                switch_to_blog( $blog_id );

                //install/update all required database
                $db_class = UWebDev_InstallDb::getInstance();
                $db_class->createDB();
                $db_class->insertGPA();

                //predefine all options
                $option_class = UWebDev_DefaultOptions::getInstance();
                $option_class->createOptions();

                restore_current_blog();
            }
        }

        private function setDbTables () {
            global $wpdb;
            $wpdb->uwebdev_department   = self::getTablePrefix() . 'departments';
            $wpdb->uwebdev_batch        = self::getTablePrefix() . 'batches';
            $wpdb->uwebdev_exam         = self::getTablePrefix() . 'exams'; 
        }

        function onDeleteBlog( $tables, $blog_id ) {

            $tables[]   = self::getTablePrefix() . 'departments';
            $tables[]   = self::getTablePrefix() . 'batches';
            $tables[]   = self::getTablePrefix() . 'exams';
            $tables[]   = self::getTablePrefix() . 'grade';
            $tables[]   = self::getTablePrefix() . 'exam_records';
            $tables[]   = self::getTablePrefix() . 'exam_record_meta';
            $tables[]   = self::getTablePrefix() . 'marks';

            return $tables;
        }

		function uwebdev_plugin_settings() {
		    $page_title = 'UWebDev Basic ';
		    $menu_title = 'UWebDev Basic ';
		    $capability = 'edit_posts';
		    $menu_slug  = 'uwebdev_basic_plugin';
		    $function   = 'uwebdev_basic_plugin_display';
		    $icon_url   = '';
		    $position   = 25;

		    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,$function), $icon_url, $position );
		}
		function uwebdev_basic_plugin_display()
		{
			$db_class = UWebDev_InstallDb::getInstance();
			//$db_class->createDB();
	            
	        $admin_class = UWebDev_Admin_AdminPanel::getInstance();
			//$admin_class->getMenu();

			?>
			<div class="wrap">        
			<h2><i id="icon-edit" class="dashicons dashicons-admin-generic" style="line-height: 1.5em;"></i>&nbsp;Settings</h2>
			
				
		    </div>
			<?php 
		}

	}

	UWebDev_Portfolio::getInstance();
}
