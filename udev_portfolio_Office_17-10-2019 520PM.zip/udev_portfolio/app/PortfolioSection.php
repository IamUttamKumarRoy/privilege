<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PortfolioSection extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'section_type_id',
        'section_name',
        'head_title',
        'description',
        'status'
    ];
}
