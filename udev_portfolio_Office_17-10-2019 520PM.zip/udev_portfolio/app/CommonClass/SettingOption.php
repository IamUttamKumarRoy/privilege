<?php

namespace App\CommonClass;

use Illuminate\Http\Request; 
use App\Setting;

class SettingOption
{
	public function __construct() 
	{ 
	}

	public function showForm( $website_settings = null ) 
	{	   
	   echo view('settings.site_setting',compact('website_settings'));
	}
  	
  	public function saveFormInput(Request $request) 
	{
	   //dd($request->all());

	   if( !empty($request->all()) )
	   {
	   	  foreach ($request->all() as $field_name => $field_value) 
	   	  {
	   	  	if( $field_name == "_token" )
	   	  		continue;
			$setting_option = Setting::firstOrNew(array('variable_name' => $field_name));
			$setting_option->variable_value = $field_value;
			$setting_option->save();
	   	  }
	   }
	   return redirect('/settings')->with('success', 'Setting  save unsuccessfull');
	}

}
?>