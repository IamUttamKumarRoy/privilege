<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit Book
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('privilege_menus.update', $privilege_menu->id)); ?>">
           
          <div class="form-group">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <label>Section Type</label>
            <select class="form-control" name="privilege_menu_category_id">
            <?php if(!empty($privilege_menu_category_list) ): ?>
                <?php $__currentLoopData = $privilege_menu_category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id=> $menu_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if( $category_id == $privilege_menu->privilege_menu_category_id ): ?>
                    <option value="<?php echo e($category_id); ?>" selected><?php echo e($menu_category); ?></option>
                  <?php else: ?> 
                    <option value="<?php echo e($category_id); ?>"><?php echo e($menu_category); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </select>
          </div>
          <div class="form-group">                        
              <label for="name">Privilege Name:</label>
              <input type="text" class="form-control" name="privilege_name" value="<?php echo e($privilege_menu->privilege_name); ?>"/>
          </div> 

          <div class="form-group">
              <label for="name">URI:</label>
              <input type="text" class="form-control" name="uri" value="<?php echo e($privilege_menu->uri); ?>"/>
          </div> 
          <div class="form-group">
              <label for="name">Methods:</label>
              <input type="text" class="form-control" name="methods" value="<?php echo e($privilege_menu->methods); ?>"/>
          </div>  
          <div class="form-group">
              <label for="name">Action:</label>
              <input type="text" class="form-control" name="action" value="<?php echo e($privilege_menu->action); ?>"/>
          </div> 
          <div class="form-group">                        
              <label for="name">Controller:</label>
              <input type="text" class="form-control" name="controller" value="<?php echo e($privilege_menu->controller); ?>"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update Book</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>