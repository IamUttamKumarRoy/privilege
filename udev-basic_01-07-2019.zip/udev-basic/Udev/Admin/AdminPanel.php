<?php
if(!defined('WPINC')) {
    die();
}

if( !class_exists( 'Udev_Admin_AdminPanel' ) ) {

	final class Udev_Admin_AdminPanel 
	{
		private static $instance;
    
	    public static function getInstance() {
	        if(self::$instance==null) {
	            self::$instance = new self; 
	        }
	        
	        return self::$instance;
	    }
	    
	    private function __construct() {
	        ;
	    }

	     public function getMenu() {
	     	echo "getMenu";
	     }
	}
}