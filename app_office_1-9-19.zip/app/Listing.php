<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'parent_id',
        'list_type', 
        'list_title', 
        'list_body', 
        'list_thumb',  
        'status'
    ];

    /**
     * Get the list category that owns the list.
     */
    public function list_category()
    {
        return $this->belongsTo(ListCategory::class);
    }

    /**
     * Get the list items for the list
     */
    public function list_items()
    {
        return $this->hasMany(ListItem::class);
    }
}
