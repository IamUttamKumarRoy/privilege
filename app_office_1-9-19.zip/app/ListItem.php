<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListItem extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'parent_id',
        'listing_id', 
        'item_type', 
        'item_title', 
        'item_body',  
        'item_thumb',  
        'status'
    ];

    /**
     * Get the list that owns the list item
     */
    public function listing()
    {
        return $this->belongsTo(Listing::class);
    }

    /**
     * Get the list items fields for the list item
     */
    public function list_item_fields()
    {
        return $this->hasMany(ListItemField::class);
    }
}
