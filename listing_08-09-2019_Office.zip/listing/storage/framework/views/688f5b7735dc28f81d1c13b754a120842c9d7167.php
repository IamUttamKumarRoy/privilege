<!DOCTYPE html>
<html>
<head>
    <title>L-5.8 CRUD</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>

	<div class="container">

	    <?php echo $__env->yieldContent('content'); ?>

	</div>

</body>
</html><?php /**PATH D:\xampp7\htdocs\laravel_projects\listing\resources\views/layouts/layout.blade.php ENDPATH**/ ?>