<?php

namespace App\Http\Controllers;

use App\ListItemField;
use Illuminate\Http\Request;

class ListItemFieldController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ListItemField  $listItemField
     * @return \Illuminate\Http\Response
     */
    public function show(ListItemField $listItemField)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ListItemField  $listItemField
     * @return \Illuminate\Http\Response
     */
    public function edit(ListItemField $listItemField)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ListItemField  $listItemField
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ListItemField $listItemField)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ListItemField  $listItemField
     * @return \Illuminate\Http\Response
     */
    public function destroy(ListItemField $listItemField)
    {
        //
    }
}
