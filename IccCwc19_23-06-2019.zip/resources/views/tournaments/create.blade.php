@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Tournament
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('tournaments.store') }}" enctype="multipart/form-data" >
                    @csrf 
                    <div class="form-group">
                        <label for="tournament_name">Tournament Name:</label>
                        <input type="text" class="form-control" name="tournament_name"/>
                    </div>
                    <div class="form-group">
                        <label for="team_number">Team Number:</label>
                        <input type="text" class="form-control" name="team_number"/>
                    </div> 
                    <div class="form-group">
                        <label for="odi_number">Total Match:</label>
                        <input type="text" class="form-control" name="odi_number"/>
                    </div> 
                    <div class="form-group">
                        <label for="started_date">Started Date:</label>
                        <input type="text" class="form-control datePicCls" name="started_date"/>
                    </div> 
                    <div class="form-group">
                        <label for="ended_date">Dnded Date:</label>
                        <input type="text" class="form-control datePicCls" name="ended_date"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection