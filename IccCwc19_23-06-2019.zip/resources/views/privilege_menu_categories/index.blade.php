@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Section Type
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            <a href="{{ route('privilege_menu_categories.create')}}" class="btn btn-outline btn-primary">Add New</a>
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                        <td>Section Name</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $inc = 1;
                      $odd_even = "even";
                      @endphp
  
                      @if(!empty($privilege_menu_categories))
                        @foreach($privilege_menu_categories as $privilege_menu_category)                          
                          @if($inc%2 == 0)                              
                            @php
                            $odd_even = "even"  
                            @endphp                                                    
                          @else 
                            @php
                            $odd_even = "odd"  
                            @endphp
                          @endif
                        <tr class="{{ $odd_even }}">
                            <td>{{$privilege_menu_category->id}}</td>
                            <td>{{$privilege_menu_category->category_name}}</td> 
                            <td>
                              <a href="{{ route('privilege_menu_categories.show',$privilege_menu_category->id)}}" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="{{ route('privilege_menu_categories.edit',$privilege_menu_category->id)}}" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="{{ route('privilege_menu_categories.destroy', $privilege_menu_category->id)}}" method="post">
                                  @csrf
                                  @method('DELETE')
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        @php
                        $inc += 1; 
                        @endphp
                        @endforeach
                      @endif  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
@endsection