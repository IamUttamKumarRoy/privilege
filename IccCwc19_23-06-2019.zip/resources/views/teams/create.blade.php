@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Section Type
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('teams.store') }}" enctype="multipart/form-data" >
                    @csrf 
                    <div class="form-group">
                        <label for="section_name">Team Name:</label>
                        <input type="text" class="form-control" name="team_name"/>
                    </div>
                    <div class="form-group">
                        <label for="head_title">Short Name:</label>
                        <input type="text" class="form-control" name="short_name"/>
                    </div> 
                    <div class="form-group">
                        <label for="description">Logo:</label>
                        <input type="file" class="form-control" name="logo"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection