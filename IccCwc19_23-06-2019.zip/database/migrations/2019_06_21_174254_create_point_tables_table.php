<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePointTablesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('point_tables', function (Blueprint $table) {
            $table->increments('id');
            $table->smallInteger('tournament_id')->unsigned()->nullable();
            $table->smallInteger('team_id')->unsigned()->nullable();
            $table->tinyInteger('match_played')->unsigned()->nullable();
            $table->tinyInteger('match_won')->unsigned()->nullable();
            $table->tinyInteger('match_lost')->unsigned()->nullable();
            $table->tinyInteger('match_tied')->unsigned()->nullable();
            $table->tinyInteger('match_no_result')->unsigned()->nullable();
            $table->float('match_net_run_rate')->nullable();
            $table->tinyInteger('status')->unsigned()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('point_tables');
    }
}
