<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrivilegeMenu extends Model
{  
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'privilege_name',
        'uri',
        'methods',
        'action',
        'controller',
        'ordering',
        'status'
    ]; 
    
    //public $timestamps = false;

    /**
     * The users that belong to the role.
     */
    public function user_roles()
    {
        return $this->belongsToMany(UserRole::class,'user_role_privilege_menu');
    }

}
