<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserRole;
use App\PrivilegeMenu;


class UserRolePrivilegeMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /*$data = [
            'role_id' => 1, 
            'privilege_menu_id' => 1 
        ];
        $role_privilege = UserRolePrivilegeMenu::create($data);        
        */

        /* // -- OK
        $privilege_menu = new PrivilegeMenu;
        $privilege_menu->privilege_name = 'Book View';
        $privilege_menu->uri = 'books';
        $privilege_menu->action = 'books';
        $privilege_menu->controller = 'BookController';

        $privilege_menu->save();

        $user_role = UserRole::find([1,2]);
        $privilege_menu->user_roles()->attach($user_role);
        */

        $user_role = new UserRole;
        $user_role->role_name = 'Subscriber'; 

        $user_role->save();

        $privilege_menu = PrivilegeMenu::find([1,2]);
        $user_role->privilege_menus()->attach($privilege_menu);

        return 'Success';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function show(UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function edit(UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }
}
