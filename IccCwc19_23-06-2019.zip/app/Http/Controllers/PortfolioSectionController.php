<?php

namespace App\Http\Controllers;

use App\PortfolioSection;
use Illuminate\Http\Request;
//use App\CommonClass\AppController;

class PortfolioSectionController extends Controller
{
    /*protected $appc;

    public function __construct(AppController $appc) {
        $this->appc = $appc;
    }*/

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $section_type_list = $this->appc->getSectionTypeList();

        $portfolio_sections = PortfolioSection::all();

        return view('portfolio_sections.index', compact('portfolio_sections','section_type_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $section_type_list = $this->appc->getSectionTypeList();
        
        return view('portfolio_sections.create',compact('section_type_list'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {        
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'section_type_id' => 'required', 
            'section_name' => 'required|max:30', 
            'head_title' => 'required|max:100' 
        ]);
        $submitted_data['status']  = 1;
        pr($submitted_data);
        pr($validated_data);
        

        if(PortfolioSection::create($submitted_data)){
            return redirect('/portfolio_sections')->with('success', 'Section Type is successfully saved');
        }
        else {
            return redirect('/portfolio_sections/create')->with('success', 'Section Type save unsuccessfull');
        }         
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PortfolioSection  $portfolioSection
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PortfolioSection  $portfolioSection
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $section_type_list = $this->appc->getSectionTypeList();

        $portfolio_section = PortfolioSection::findOrFail($id);
        return view('portfolio_sections.edit',compact('portfolio_section','section_type_list'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PortfolioSection  $portfolioSection
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'section_type_id' => 'required', 
            'section_name' => 'required|max:30', 
            'head_title' => 'required|max:100' 
        ]);
        //pr($submitted_data);
       // $is_updated = PortfolioSection::whereId($id)->update($validated_data);
        //die;
        

        if(PortfolioSection::whereId($id)->update($validated_data))
        {
            return redirect('/portfolio_sections')->with('success', 'Section Type is successfully updated');
        }
        else {
            return redirect('/portfolio_sections/create')->with('success', 'Section Type update unsuccessfull');
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PortfolioSection  $portfolioSection
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
        $portfolio_section = PortfolioSection::findOrFail($id);
        $portfolio_section->delete();

        return redirect('/portfolio_sections')->with('success', 'Portfolio Section is successfully deleted');
    }
}
