<?php

namespace App\Http\Controllers;

use App\Team;
use Illuminate\Http\Request;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $teams = Team::all();

        return view('teams.index', compact('teams'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('teams.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'team_name' => 'required', 
            'short_name' => 'required'  
        ]);
        $submitted_data['status']  = 1;

        if( $files = $request->file('logo') )
        {
            $name = $files->getClientOriginalName();
            $name = uniqid().$name;

            if($files->move('assets/logo',$name) ) {
                $submitted_data['logo']  = $name;
            }             
        }
        
        if(Team::create($submitted_data)){
            return redirect('/teams')->with('success', 'Team is successfully saved');
        }
        else {
            return redirect('/teams/create')->with('success', 'Team save unsuccessfull');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $team = Team::findOrFail($id).first();
        return view('teams.show',compact('team'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $team = Team::findOrFail($id);
        return view('teams.edit',compact('team'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated_data = $request->validate([
            'team_name' => 'required', 
            'short_name' => 'required'  
        ]);

        if( $files = $request->file('logo') )
        {
            $name = $files->getClientOriginalName();
            $name = uniqid().$name;

            if( $files->move('assets/logo',$name) ) {
                $validated_data['logo']  = $name;
            } 

        }        
        Team::whereId($id)->update($validated_data);

        return redirect('/teams')->with('success', 'Team is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Team  $team
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $team = Team::findOrFail($id);
        $team->delete();

        return redirect('/teams')->with('success', 'Team is successfully deleted');
    }
}
