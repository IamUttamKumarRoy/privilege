<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatchResult extends Model
{ 
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'match_id',
        'result_id',
        'winner_team_id',
        'win_by_run',
        'win_by_wicket', 
        'status'
    ];
}
