<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Match extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'tournament_id',
        'match_no',
        'venu',        
        'country_id', 
        'city_id',
        'time_of_play', 
        'team_one_id',
        'team_two_id',
        'status'
    ];
    
    public function tournament()
    {
    	return $this->belongsTo('App\Tournament');
    }
    public function country()
    {
        return $this->belongsTo('App\Country');
    }
    public function city()
    {
        return $this->belongsTo('App\City');
    }
}
