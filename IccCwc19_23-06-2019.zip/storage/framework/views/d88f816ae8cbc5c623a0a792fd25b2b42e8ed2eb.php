<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Privilege Menu Category
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('privilege_menu_categories.store')); ?>">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <label for="name">Category Name:</label>
                        <input type="text" class="form-control" name="category_name"/>
                    </div> 
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <label for="name">Precedence:</label>
                        <input type="text" class="form-control" name="precedence"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/privilege_menu_categories/create.blade.php ENDPATH**/ ?>