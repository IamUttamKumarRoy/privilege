<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Match
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            <a href="<?php echo e(route('matches.create')); ?>" class="btn btn-outline btn-primary">Add New</a>
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                        <td>Tournament</td>
                        <td>Match No</td>
                        <td>Country</td>
                        <td>City</td>
                        <td>Venu</td>
                        <td>Time</td>
                        <td>Team 1</td>
                        <td>Team 2</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $inc = 1;
                      $odd_even = "even";
                      ?>
  
                      <?php if(!empty($matches)): ?>
                        <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                          
                          <?php if($inc%2 == 0): ?>                              
                            <?php
                            $odd_even = "even"  
                            ?>                                                    
                          <?php else: ?> 
                            <?php
                            $odd_even = "odd"  
                            ?>
                          <?php endif; ?>
                        <tr class="<?php echo e($odd_even); ?>">
                            <td><?php echo e($match->id); ?></td> 
                            <td><?php echo e($tournament_list_arr[$match->tournament_id]); ?></td> 
                            <td><?php echo e($match->match_no); ?></td> 
                            <td>
                              <?php if(!empty($country_list[$match->country_id])): ?>  
                                     <?php echo e($country_list[$match->country_id]); ?>                                              
                                <?php else: ?>  
                                  <?php echo e($match->country_id); ?>

                               <?php endif; ?>
                            </td> 
                            <td><?php echo e($city_list[$match->city_id]); ?></td> 
                            <td><?php echo e($match->venu); ?></td> 
                            <td><?php echo e($match->time_of_play); ?></td> 
                            <td><?php echo e($team_list_arr[$match->team_one_id]); ?></td> 
                            <td><?php echo e($team_list_arr[$match->team_two_id]); ?></td> 
                            <td>
                              <a href="<?php echo e(route('match_results.create',$match->id)); ?>" class="btn btn-primary">Match Result</a>
                            </td>
                            <td>
                              <a href="<?php echo e(route('matches.show',$match->id)); ?>" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="<?php echo e(route('matches.edit',$match->id)); ?>" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="<?php echo e(route('matches.destroy', $match->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                        $inc += 1; 
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp733\htdocs\laravel_projects\IccCwc19\resources\views/matches/index.blade.php ENDPATH**/ ?>