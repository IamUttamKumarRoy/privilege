<?php $__env->startSection('content'); ?>
            <h1>Team <?php echo e($team->team_name); ?></h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Book Title:</strong> <?php echo e($team->short_name); ?><br> 
        </p>
        <p>
            <img src="<?php echo e(URL::to('assets/logo/' . $team->logo)); ?>" alt="" class="img-responsive"> <br> 
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/teams/show.blade.php ENDPATH**/ ?>