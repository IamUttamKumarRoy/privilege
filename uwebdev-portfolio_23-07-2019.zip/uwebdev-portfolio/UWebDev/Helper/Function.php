<?php
if ( !defined( 'WPINC' ) ) {
    die();
}

class UWebDev_Helper_Function {
    public function __construct() {
        //nothing here
    }
    public static function get_option( $option, $section, $default = '' ) {

        $options = get_option( $section );

        if ( isset( $options[$option] ) ) {
            return $options[$option];
        }

        return $default;
    }
    

    public static function PR( $data = array() ) {
        echo "<pre>"; print_r($data); echo "</pre>";
    }

    public static function javascript_redirect($location) {
        // redirect after header here can't use wp_redirect($location);
        ?>
          <script type="text/javascript">
          <!--
          window.location= '<?php echo $location; ?>';
          //-->
          </script>
        <?php
        exit;
    }
}

