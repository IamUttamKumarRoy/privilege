<?php

if ( !defined( 'WPINC' ) ) {
	die();
}

class UWebDev_DefaultOptions {
	private static $instance;
	private $TD;

	public static function getInstance() {
		if(self::$instance==null) {
			self::$instance = new self;
			self::$instance->TD = UWebDev_Portfolio::TD;
			//self::$instance->createOptions();
		}

		return self::$instance;
	}

	private function __construct() {
		;
	}

	public function createOptions() {

		$default_options = array(
			'user_role'			=> 'manage_options',
			'bootstrap_css'     => '',
			'bootstrap_js'      => ''
		);

		if( get_option( UWebDev_Portfolio::PLUGIN_SLUG . '_basics', '') == '' ) {
			add_option( UWebDev_Portfolio::PLUGIN_SLUG . '_basics', $default_options );
		}	
	}

}