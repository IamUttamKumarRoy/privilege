<?php
if(!defined('WPINC')) {
    die();
}

class UWebDev_Admin_PostType {
    private static $instance;
    
    public static function getInstance() {
        if(self::$instance==null) {
            self::$instance = new self;
            self::$instance->actions();
        }
        
        return self::$instance;
    }
    
    private function __construct() {
        ;
    }
    
    private function actions() {
        add_action( 'init', array( $this, 'projects' ));  
    }
 
    
    public function projects() {
        register_post_type(UWebDev_Portfolio::PROJECT,
            array(
                'label'                     => 'Projects',
                'labels' => array (
                    'name'                  => __( 'Projects', UWebDev_Portfolio::TD ),
                    'singular_name'         => __( 'Project', UWebDev_Portfolio::TD ),
                    'menu_name'             => _x( 'Projects', 'Admin menu name', UWebDev_Portfolio::TD ),
                    'add_new'               => __( 'Add Project', UWebDev_Portfolio::TD ),
                    'add_new_item'          => __( 'Add New Project', UWebDev_Portfolio::TD ),
                    'edit'                  => __( 'Edit', UWebDev_Portfolio::TD ),
                    'edit_item'             => __( 'Edit Project', UWebDev_Portfolio::TD ),
                    'new_item'              => __( 'New Project', UWebDev_Portfolio::TD ),
                    'view'                  => __( 'View Project', UWebDev_Portfolio::TD ),
                    'view_item'             => __( 'View Project', UWebDev_Portfolio::TD ),
                    'search_items'          => __( 'Search Projects', UWebDev_Portfolio::TD ),
                    'not_found'             => __( 'No Projects found', UWebDev_Portfolio::TD ),
                    'not_found_in_trash'    => __( 'No Projects found in trash', UWebDev_Portfolio::TD ),
                    'parent'                => __( 'Parent Project', UWebDev_Portfolio::TD )
                ),

                'description'               => __( 'This is where you can add new courses.', UWebDev_Portfolio::TD ),
                'show_in_menu'              => UWebDev_Portfolio::PLUGIN_PAGE,
                //'capability_type'         => 'ustc_course',
                //'map_meta_cap'            => true,
                //'publicly_queryable'      => false,
                'public'                    => true,
                'show_ui'                   => true,
                'exclude_from_search'       => true,
                'hierarchical'              => false, // Hierarchical causes memory issues - WP loads all records!
                //'rewrite'                 => array('slug'=>'rps_result_course'),
                'supports'                  => array('title'),
                'has_archive'               => false,
                'show_in_nav_menus'         => false,
                'menu_icon'                 => '<div id="icon-edit" class="icon32 icon32-posts-post"></div>'
            )
        );
    }
    
}

