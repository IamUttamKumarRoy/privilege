<?php

if(!defined('WPINC')) {
    die();
}

class UWebDev_Admin_Menu_Settings {
    private static $instance, $slug = array(), $page_hook;
    private $TD;
    private $role;

    public static function getInstance() {
        if(self::$instance==null){
            self::$instance = new self;
            self::$slug = array();
            self::$instance->TD = UWebDev_Portfolio::TD;
            self::$instance->actions();
        }
        
        return self::$instance;
    }
    
    private function __construct() {
        ;
    }

    private function actions() { 
         add_action('admin_menu', array($this, 'settingsMenu'));
    }

    public function settingsMenu() {
        add_submenu_page(UWebDev_Portfolio::PLUGIN_PAGE, __('Settings', $this->TD) . ' - ' . __("Settings", $this->TD), __("Settings", $this->TD), 'administrator', UWebDev_Portfolio::PLUGIN_SLUG . '_settings',array($this,'showContent'));
    }
    
    public function showContent() 
    {
      // Form Submission handle
      if( isset( $_POST['general_form'] ) ) {
          

          if ( wp_verify_nonce( $_POST['udev_nonce_general_form'], 'udev_nonce_general_form_action' ) ) 
          { 
              $udev_setting = $_POST['udev_settings'];

              if( !empty($udev_setting) )
              {
                  foreach ($udev_setting as $option_key => $option_value) 
                  {
                      if ( !empty($option_value) ) {
                          update_option($option_key, $option_value);
                      }
                  }
              }
              if($_POST['udev_desc'] ) {
                  update_option('udev_desc', $_POST['udev_desc']);
              }
              /*if ( !empty($udev_setting['udev_website_name']) ) {
                  update_option('udev_website_name', $udev_setting['udev_website_name']);
              }
              if ( !empty($udev_setting['udev_contact_number']) ) {
                  update_option('udev_contact_number', $udev_setting['udev_contact_number']);
              }*/

              /*echo "<pre>";
                  print_r($_POST['udev_settings[udev_website_name]']);
                  print_r($_POST['udev_settings[udev_contact_number]']);
                  print_r($_POST['udev_desc']);
                  print_r($_POST['udev_settings']);
              echo "</pre>";*/
              
          }     
      }

    

    $website_name   = get_option('udev_website_name', 'uttam.com');
    $contact_number = get_option('udev_contact_number', '01737137704');
    $udev_site_logo = get_option('udev_site_logo');
    

    ?>
    <div class="wrap">        
        <h2><i id="icon-edit" class="dashicons dashicons-admin-generic" style="line-height: 1.5em;"></i>&nbsp;Settings</h2>
        
        <!-- <div class="updated notice">
            <p>Something has been updated, awesome</p>
        </div>
        <div class="error notice">
            <p>There has been an error. Bummer</p>
        </div>
        <div class="update-nag notice">
            <p>You should really update to achieve some awesome instad of bummer</p>
        </div> -->
        <br class="clear">
        <h2 class="nav-tab-wrapper">
            <a href="#udev-general-tab" class="nav-tab nav-tab-active" id="udev-general-tab-tab">General Settings</a>
            <a href="#udev-shortcode-tab" class="nav-tab" id="udev-shortcode-tab-tab">Shortcode</a>
            <a href="#udev-api-tab" class="nav-tab" id="udev-api-tab-tab">API</a>
            <a href="#udev-license-tab" class="nav-tab" id="udev-license-tab-tab">License</a>
        </h2>
        <div class="metabox-holder">
           <div id="udev-general-tab" class="group" style="display: block;">
                        
                <form method="post" action="<?php admin_url( 'admin.php?page=udev_plugin_setting' ); ?>">

                    <?php wp_nonce_field('udev_nonce_general_form_action','udev_nonce_general_form'); ?>
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Privillege:', 'udev' ) ?></th>
                            <td> 
                                <select class="regular" name="udev_settings_udev_user_role" id="udev_settings[udev_settings_udev_user_role]">
                                    <option value="manage_options">Administrator</option>
                                    <option value="edit_pages">Editor</option>
                                    <option value="publish_posts">Author</option>
                                    <option value="edit_posts">Contributor</option>
                                    <option value="read">Subscriber</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Website Name:', 'udev' ) ?></th>
                            <td> 
                                <input type="text" class="regular-text" id="udev_settings_udev_website_name" name="udev_settings[udev_website_name]" value="<?php echo $website_name; ?>">                                                          
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Contact Number:', 'udev' ) ?></th>
                            <td>  
                                <input type="text" class="regular-text" id="udev_settings_udev_contact_number" name="udev_settings[udev_contact_number]" value="<?php echo $contact_number; ?>">                
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Color:', 'udev' ) ?></th>
                            <td>  
                                <input type="text" class="regular-text wp-color-picker-field" id="udev_settings_udev_color" name="udev_settings[udev_settings_udev_color]" value="<?php echo $contact_number; ?>">              
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Password:', 'udev' ) ?></th>
                            <td>  
                                <input type="password" class="regular-text" id="udev_password" name="udev_settings[udev_password]" value="<?php echo $udev_password; ?>">               
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Site Logo:', 'udev' ) ?></th>
                            <td>  
                                <img class="udev_site_logo_holder" src="<?php echo get_option('udev_site_logo'); ?>" height="100" width="100"/><br/>
                                <input type="text" class="regular-text" id="udev_site_logo" name="udev_settings[udev_site_logo]">
                                <a href="#" class="udev_site_logo_btn">Upload</a>               
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Site On/Off:', 'udev' ) ?></th>
                            <td>                                
                                <fieldset>
                                    <label for="udev_site_on_off">                                      
                                        <input type="checkbox" class="checkbox" id="udev_site_on_off" name="udev_settings[udev_site_on_off]" value="on">
                                        Check this box if you want to Site Online.
                                    </label>
                                </fieldset>         
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Sex:', 'udev' ) ?></th>
                            <td>                                
                                <fieldset>
                                    <label for="udev_owner_sex">                                                                                
                                        <input type="radio" id="udev_owner_sex_female" name="udev_settings[udev_owner_sex]" value="1" />Female
                                        <input type="radio" id="udev_owner_sex_male" name="udev_settings[udev_owner_sex]" value="0" />Male
                                    </label>
                                </fieldset>         
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e( 'Description:', 'udev' ) ?></th>
                            <td>  
                            <?php   
                            $settings = array(
                                'teeny' => true,
                                'textarea_rows' => 10,
                                'tabindex' => 1
                            );
                            //wp_editor(esc_html( __(get_option('udev_desc'))), 'udev_desc', $settings);
                            wp_editor(__(get_option('udev_desc')), 'udev_desc', $settings);
                            ?>
                            </td>
                        </tr>
                        <tr>
                            <th></th>
                            <td> 
                                <!-- <input type="reset" value="Reset" class="button-primary"> -->
                                <input type="submit" name="general_form" value="Save" class="button button-primary button-large">                                   
                            </td>
                        </tr>
                </form>                 
           </div>
           <div id="udev-shortcode-tab" class="group" style="display: none;">
                Shortcode Student
           </div>
           <div id="rps_result_results" class="group" style="display: none;">
                Shortcode Result
           </div>
           <div id="udev-api-tab" class="group" style="display: none;">
                API
           </div>
           <div id="udev-license-tab" class="group" style="display: none;">
                License
           </div>
        </div>
        <script>
           jQuery(document).ready(function($) {
               //Initiate Color Picker
               $('.wp-color-picker-field').wpColorPicker();
           
               // Switches option sections
               $('.group').hide();
               var activetab = '';
               if (typeof(localStorage) != 'undefined' ) {
                   console.log(localStorage);
                   activetab = localStorage.getItem("activetab");
               }
               //console.log(activetab);
               if (activetab != '' && $(activetab).length ) {
                   $(activetab).fadeIn();
               } else {
                   $('.group:first').fadeIn();
               }
               $('.group .collapsed').each(function(){
                   $(this).find('input:checked').parent().parent().parent().nextAll().each(
                   function(){
                       if ($(this).hasClass('last')) {
                           $(this).removeClass('hidden');
                           return false;
                       }
                       $(this).filter('.hidden').removeClass('hidden');
                   });
               });
           
               if (activetab != '' && $(activetab + '-tab').length ) {
                   $(activetab + '-tab').addClass('nav-tab-active');
               }
               else {
                   $('.nav-tab-wrapper a:first').addClass('nav-tab-active');
               }
               $('.nav-tab-wrapper a').click(function(evt) {
                console.log($(this).attr('href'));
                   $('.nav-tab-wrapper a').removeClass('nav-tab-active');
                   $(this).addClass('nav-tab-active').blur();
                   var clicked_group = $(this).attr('href');
                   if (typeof(localStorage) != 'undefined' ) {
                       localStorage.setItem("activetab", $(this).attr('href'));
                   }
                   $('.group').hide();
                   $(clicked_group).fadeIn();
                   evt.preventDefault();
               });
           
               
           });
        </script>
        <style type="text/css">
           /** WordPress 3.8 Fix **/
           .form-table th { padding: 20px 10px; }
           #wpbody-content .metabox-holder { padding-top: 5px; }
        </style>
        <script>
            jQuery(document).ready(function($) {
                $('.udev_site_logo_btn').click(function(e) {
                    e.preventDefault();

                    var custom_uploader = wp.media({
                        title: 'Custom Image',
                        button: {
                            text: 'Upload Image'
                        },
                        multiple: false  // Set this to true to allow multiple files to be selected
                    })
                    .on('select', function() {
                        var attachment = custom_uploader.state().get('selection').first().toJSON();
                        $('.udev_site_logo_holder').attr('src', attachment.url);
                        $('#udev_site_logo').val(attachment.url);

                    })
                    .open();
                });
            });
        </script>
    </div>
    <?php 
    }
}

