<?php
/*
Plugin Name: UWebDev Portfolio Management
Plugin URI: https://www.uwebdev.com/wp/plugin/uwebdev-portfolio
Description: UWebDev Portfolio Management
Text Domain: uwebdev-portfolio
Version: 1.0.0
Author: Uttam Kumar Roy
Author URI: https://www.uttamkumarroy.com/
*/

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Required PHP version.
define( 'BP_REQUIRED_PHP_VERSION', '5.3.0' );

define( 'WPPM_VERSION', '1.0.0' );

define( 'WPPM_REQUIRED_WP_VERSION', '5.2' );

define( 'WPPM_PLUGIN', __FILE__ );

define( 'WPPM_PLUGIN_BASENAME', plugin_basename( WPPM_PLUGIN ) );

define( 'WPPM_PLUGIN_NAME', trim( dirname( WPPM_PLUGIN_BASENAME ), '/' ) );

define( 'WPPM_PLUGIN_DIR', untrailingslashit( dirname( WPPM_PLUGIN ) ) );

define( 'WPPM_PLUGIN_MODULES_DIR', WPPM_PLUGIN_DIR . '/modules' );


if( !class_exists( 'UWebDev_Portfolio' ) ) {

	final class UWebDev_Portfolio 
	{
		private static $instance;
        private $dir, $url; 

        const VER = 2.7;

		//do not change below constant
        const DS = '/';
        const PLUGIN_SLUG = 'uwebdev_portfolio';
        const PLUGIN_PAGE = 'uwebdev_portfolio_page';
        const TD = 'uwebdev-portfolio';
        const TABLE_PREFIX = 'uwebdev_';
        const FILE = __FILE__;

        //Post type constant
        const STUDENT = 'uwebdev_result_student';
        const COURSE = 'uwebdev_result_course';
        const PROJECT = 'uwebdev_project';

		public static function getInstance() {

            if (self::$instance == null) {
                self::$instance = new self;
                self::$instance->dir = dirname(__FILE__);
                self::$instance->setDbTables();
                self::$instance->autoload();
                self::$instance->actions();

            } else {
                throw new BadFunctionCallException(sprintf('Plugin %s already instantiated', __CLASS__));
            }
            return self::$instance;
        }

        public function autoload() {
            require_once ( $this->dir . self::DS . "UWebDev" . self::DS . "Autoloader" . self::DS . "LoaderClass.php" );

            // Add the Autoloader
            $loader = new UWebDev_Autoloader_LoaderClass( "UWebDev", dirname( __FILE__ ) );
            $loader->register( );


        }

        /**
         * Return prefix for plugin database tables
         * @return string
         */
        public static function getTablePrefix() {
            global $wpdb;
            return $wpdb->prefix . self::TABLE_PREFIX;
        }

         private function check_for_updates() {
         	$db_class = UWebDev_InstallDb::getInstance();
	        $db_class->createDB();
         }
        /**
         * call all actions/filters here
         */
        private function actions() {
        	register_activation_hook(__FILE__, array($this, 'activate'));
            register_deactivation_hook(__FILE__, array($this, 'deactivate'));

            //load plugin text domain
            add_action( 'plugins_loaded', array($this,'loadTextdomain') );
            
            //multisite install tables after adding a new blog
            add_action( 'wpmu_new_blog', array( $this, 'onCreateBlog'), 10, 6 );
            //delete tables after blog is deleted
            add_filter( 'wpmu_drop_tables', array($this, 'onDeleteBlog'), 10, 2 );

	        //add_action('admin_menu', array($this,'uwebdev_plugin_settings'));

            //load all post type here
            UWebDev_Admin_PostType::getInstance();

	        if ( is_admin() ) { 
	            //check for updates
	            //$this->check_for_updates();

                //register menus
                UWebDev_Admin_Menu_AdminPanel::getInstance();

                //settings page
                UWebDev_Admin_Menu_Settings::getInstance();

                add_action( 'admin_init', array($this, 'actionAdminInit') );
            }  
    
            add_action( "wp_enqueue_scripts", array($this,"js_enqueue_scripts" ));        
        }
        function js_enqueue_scripts() {
            $phpvariable = "This is from PHP";
            global $phpvariable; 
            wp_register_script( "hendlerskripte", "/mojaskriptax.js" );
            wp_enqueue_script( "hendlerskripte" );
            wp_localize_script( "hendlerskripte", "JS_object_php_var",  $phpvariable);

            $uwebdev_portfolio_js_variables = array(
                'string'      => array(
                    'wait_var'         => __( 'Please wait...'),
                    'copied_var'       => __( 'Copied' )
                )
            );
            wp_localize_script( 'uwebdev_portfolio', 'UwebdevPortfolio', $uwebdev_portfolio_js_variables );
            // Enqueued script with localized data.
            wp_enqueue_script( 'uwebdev_portfolio' );
        }

        public function actionAdminInit() {
            global $typenow;

            // when editing pages, $typenow isn't set until later!
            if (empty($typenow)) {
                // try to pick it up from the query string
                if (!empty($_GET['post'])) {
                    $post = get_post($_GET['post']);
                    $typenow = $post->post_type;
                }
                // try to pick it up from the quick edit AJAX post
                elseif (!empty($_POST['post_ID'])) {
                    $post = get_post($_POST['post_ID']);
                    $typenow = $post->post_type;
                }
            }

            // check for one of our custom post types,
            // and start admin handling for that type
            switch ($typenow) {
                case self::PROJECT:
                    //RPS_Admin_Init_PostFilters_Student::getInstance();
                    UWebDev_Admin_Metaboxes_Project::getInstance();
                    break; 
            }
        }


        public function loadTextdomain() {
            //http://codex.wordpress.org/I18n_for_WordPress_Developers
            load_plugin_textdomain( self::TD, false, dirname( plugin_basename( __FILE__ ) ) . '/lang' ); 
        }

        public function activate( $network_wide ) {
            // uncaught exception doesn't prevent plugin from being activated, therefore replace it with fatal error so it does
            set_exception_handler(create_function('$e', 'trigger_error($e->getMessage(), E_USER_ERROR);'));

            global $wpdb;

            if ( is_multisite() && $network_wide ) {

                // Get all blogs in the network and activate plugin on each one
                $blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );

                foreach ( $blog_ids as $blog_id ) {
                    switch_to_blog( $blog_id );
                    //install/update all required database
                    $db_class = UWebDev_InstallDb::getInstance();
                    $db_class->createDB(); 

                    //predefine all options
                    $option_class = UWebDev_DefaultOptions::getInstance();
                    $option_class->createOptions();

                    restore_current_blog();
                }

            } else {
                //install/update all required database
                $db_class = UWebDev_InstallDb::getInstance();
                $db_class->createDB(); 

                //predefine all options
                $option_class = UWebDev_DefaultOptions::getInstance();
                $option_class->createOptions();
            }
        }

        public function deactivate() {

        }

        public function onCreateBlog( $blog_id, $user_id, $domain, $path, $site_id, $meta ) {
            $plugin = plugin_basename( __FILE__ );

            if ( is_plugin_active_for_network( $plugin ) ) {
                switch_to_blog( $blog_id );

                //install/update all required database
                $db_class = UWebDev_InstallDb::getInstance();
                $db_class->createDB();
                $db_class->insertGPA();

                //predefine all options
                $option_class = UWebDev_DefaultOptions::getInstance();
                $option_class->createOptions();

                restore_current_blog();
            }
        }

        private function setDbTables () {
            global $wpdb;
            $wpdb->uwebdev_department   = self::getTablePrefix() . 'departments';
            $wpdb->uwebdev_batch        = self::getTablePrefix() . 'batches';
            $wpdb->uwebdev_exam         = self::getTablePrefix() . 'exams';
            $wpdb->uwebdev_grade        = self::getTablePrefix() . 'grade';
            $wpdb->uwebdev_exam_record  = self::getTablePrefix() . 'exam_records';
            $wpdb->uwebdev_exam_record_meta = self::getTablePrefix() . 'exam_record_meta';
            $wpdb->uwebdev_marks        = self::getTablePrefix() . 'marks'; 
        }

        function onDeleteBlog( $tables, $blog_id ) {

            $tables[]   = self::getTablePrefix() . 'departments';
            $tables[]   = self::getTablePrefix() . 'batches';
            $tables[]   = self::getTablePrefix() . 'exams';
            $tables[]   = self::getTablePrefix() . 'grade';
            $tables[]   = self::getTablePrefix() . 'exam_records';
            $tables[]   = self::getTablePrefix() . 'exam_record_meta';
            $tables[]   = self::getTablePrefix() . 'marks';

            return $tables;
        }

		function uwebdev_plugin_settings() {
		    $page_title = 'UWebDev Basic ';
		    $menu_title = 'UWebDev Basic ';
		    $capability = 'edit_posts';
		    $menu_slug  = 'uwebdev_basic_plugin';
		    $function   = 'uwebdev_basic_plugin_display';
		    $icon_url   = '';
		    $position   = 25;

		    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,$function), $icon_url, $position );
		}
		function uwebdev_basic_plugin_display()
		{
			$db_class = UWebDev_InstallDb::getInstance();
			//$db_class->createDB();
	            
	        $admin_class = UWebDev_Admin_AdminPanel::getInstance();
			//$admin_class->getMenu();

			?>
			<div class="wrap">        
			<h2><i id="icon-edit" class="dashicons dashicons-admin-generic" style="line-height: 1.5em;"></i>&nbsp;Settings</h2>
			
				
		    </div>
			<?php 
		}

	}

	UWebDev_Portfolio::getInstance();
}
