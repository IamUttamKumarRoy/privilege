<?php

namespace App\Http\Controllers;

use App\PrivilegeMenu;
use Illuminate\Http\Request;

class PrivilegeMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $privilege_menus = PrivilegeMenu::all();
        return view('privilege_menus.index', compact('privilege_menus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('privilege_menus.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'privilege_name' => 'required', 
            'uri' => 'required',            
            'controller' => 'required' 
        ]);
        $submitted_data['ordering']  = 1;
        $submitted_data['status']  = 1;
       // dd($submitted_data);
                
        $privilege_menu = PrivilegeMenu::create($submitted_data);
        dd($submitted_data);
        if($privilege_menu){
            return redirect('/privilege_menus')->with('success', 'Privilege Menu is successfully saved');
        }
        else {
            return redirect('/privilege_menus/create')->with('success', 'Privilege Menu save unsuccessfull');
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function show(PrivilegeMenu $privilegeMenu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function edit(PrivilegeMenu $privilegeMenu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PrivilegeMenu $privilegeMenu)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function destroy(PrivilegeMenu $privilegeMenu)
    {
        //
    }
}
