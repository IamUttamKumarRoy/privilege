@extends('layouts.sb_admin')

@section('content')
            <h1>Tournament {{ $tournament->tournament_name }}</h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Tournament Team:</strong> {{ $tournament->team_number }}<br> 
        </p>
        <p>
            <strong>Started Date:</strong> {{ $tournament->started_date }}<br> 
        </p>
        <p>
            <strong>Ended Date:</strong> {{ $tournament->ended_date }}<br> 
        </p> 
    </div>
@endsection