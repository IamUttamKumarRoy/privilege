@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Match
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('matches.store') }}" enctype="multipart/form-data" >
                    @csrf 
                    <div class="form-group">
                        <label>Tournament</label>
                        <select class="form-control" name="tournament_id">
                        @if(!empty($tournament_list) )
                            @foreach($tournament_list as $tournament_id=> $tournament)
                                <option value="{{ $tournament_id }}">{{ $tournament }}</option>
                            @endforeach
                        @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="match_no">Match No:</label>
                        <input type="text" class="form-control" name="match_no"/>
                    </div>
                    <div class="form-group">
                        <label for="city_id">City Id:</label>
                        <input type="text" class="form-control" name="city_id"/>
                    </div> 
                    <div class="form-group">
                        <label for="venu">Venu:</label>
                        <input type="text" class="form-control" name="venu"/>
                    </div> 
                    <div class="form-group">
                        <label for="time_of_play">Time Of Play:</label>
                        <input type="text" class="form-control datePicCls" name="time_of_play"/>
                    </div> 
                    <div class="form-group">
                        <label for="time_zone">Time Zone:</label>
                        <input type="text" class="form-control datePicCls" name="time_zone"/>
                    </div>
                    <div class="form-group">
                        <label>Team 1</label>
                        <select class="form-control" name="team_one_id">
                        @if(!empty($team_list) )
                            @foreach($team_list as $team_id=> $team_name)
                                <option value="{{ $team_id }}">{{ $team_name }}</option>
                            @endforeach
                        @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Team 2</label>
                        <select class="form-control" name="team_two_id">
                        @if(!empty($team_list) )
                            @foreach($team_list as $team_id=> $team_name)
                                <option value="{{ $team_id }}">{{ $team_name }}</option>
                            @endforeach
                        @endif
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection