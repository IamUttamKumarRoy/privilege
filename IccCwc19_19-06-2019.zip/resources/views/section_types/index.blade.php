@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Section Type
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            <a href="{{ route('section_types.create')}}" class="btn btn-outline btn-primary">Add New</a>
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                        <td>Section Name</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $inc = 1;
                      $odd_even = "even";
                      @endphp
  
                      @if(!empty($section_types))
                        @foreach($section_types as $section_type)                          
                          @if($inc%2 == 0)                              
                            @php
                            $odd_even = "even"  
                            @endphp                                                    
                          @else 
                            @php
                            $odd_even = "odd"  
                            @endphp
                          @endif
                        <tr class="{{ $odd_even }}">
                            <td>{{$section_type->id}}</td>
                            <td>{{$section_type->section_type}}</td> 
                            <td>
                              <a href="{{ route('section_types.show',$section_type->id)}}" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="{{ route('section_types.edit',$section_type->id)}}" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="{{ route('section_types.destroy', $section_type->id)}}" method="post">
                                  @csrf
                                  @method('DELETE')
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        @php
                        $inc += 1; 
                        @endphp
                        @endforeach
                      @endif  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
@endsection