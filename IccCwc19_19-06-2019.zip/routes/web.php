<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('portfolio_sections', 'PortfolioSectionController');
Route::resource('privilege_menu_categories', 'PrivilegeMenuCategoryController');
Route::resource('privilege_menus', 'PrivilegeMenuController');
Route::resource('section_types', 'SectionTypeController');
Route::resource('user_roles', 'UserRoleController');
Route::resource('settings', 'SettingController');
Route::resource('role_privileges', 'UserRolePrivilegeMenuController');
Route::resource('teams', 'TeamController');
Route::resource('tournaments', 'TournamentController');
Route::resource('matches', 'MatchController');

Route::resource('posts', 'PostController');
Route::resource('books', 'BookController');

Route::group(['middleware' => 'CheckPrivilege'], function()
{
	
});