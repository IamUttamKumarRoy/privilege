<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResultList extends Model
{
    //
}
