<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tournament extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'tournament_name',
        'team_number',
        'started_date',
        'ended_date',
        'status'
    ];
 
    public function match()
    {
       return $this->hasOne('App\Match');
    }
}
