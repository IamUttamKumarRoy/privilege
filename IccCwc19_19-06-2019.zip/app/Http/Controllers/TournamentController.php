<?php

namespace App\Http\Controllers;

use App\Tournament;
use Illuminate\Http\Request;

class TournamentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tournaments = Tournament::all();

        return view('tournaments.index', compact('tournaments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tournaments.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'tournament_name' => 'required', 
            'team_number'     => 'required',  
            'started_date'    => 'required',  
            'ended_date'      => 'required'  
        ]);
         
        $submitted_data['started_date']  = date("Y-m-d H:i:s", strtotime($submitted_data['started_date']));
        $submitted_data['ended_date']  = date("Y-m-d H:i:s", strtotime($submitted_data['ended_date']));
        $submitted_data['status']  = 1;


        if(Tournament::create($submitted_data)){
            return redirect('/tournaments')->with('success', 'Tournament is successfully saved');
        }
        else {
            return redirect('/tournaments/create')->with('success', 'Tournament save unsuccessfull');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tournament  $tournament
     * @return \Illuminate\Http\Response
     */
    public function show( $id)
    {
        $tournament = Tournament::findOrFail($id);
        return view('tournaments.show',compact('tournament'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tournament  $tournament
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tournament = Tournament::findOrFail($id);
        return view('tournaments.edit',compact('tournament'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tournament  $tournament
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validated_data = $request->validate([
            'tournament_name' => 'required', 
            'team_number'     => 'required',  
            'started_date'    => 'required',  
            'ended_date'      => 'required'  
        ]);
        $validated_data['started_date']  = date("Y-m-d H:i:s", strtotime($validated_data['started_date']));
        $validated_data['ended_date']  = date("Y-m-d H:i:s", strtotime($validated_data['ended_date']));
                
        Tournament::whereId($id)->update($validated_data);
        return redirect('/tournaments')->with('success', 'Tournament is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tournament  $tournament
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
        $tournament = Tournament::findOrFail($id);
        $tournament->delete();

        return redirect('/tournaments')->with('success', 'Tournament is successfully deleted');
    }
}
