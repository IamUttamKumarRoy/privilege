<?php

namespace App\Http\Controllers;

use App\Team;
use App\Tournament;
use App\Match;
use Illuminate\Http\Request;

class MatchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $matches = Match::all();

        return view('matches.index', compact('matches'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
        $team_list = Team::where('status', 1)->pluck('team_name', 'id');
        $tournament_list = Tournament::where('status', 1)->pluck('tournament_name', 'id');
        
        return view('matches.create',compact('team_list','tournament_list'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'tournament_id' => 'required', 
            'match_no' => 'required', 
            'venu'     => 'required',  
            'time_of_play'    => 'required',  
            'time_zone'    => 'required',  
            'city_id'    => 'required',  
            'team_one_id'    => 'required',  
            'team_two_id'      => 'required'  
        ]); 
        $submitted_data['status']  = 1;
        $submitted_data['time_of_play']  = date("Y-m-d H:i:s", strtotime($submitted_data['time_of_play']));
        $submitted_data['time_zone']  = date("Y-m-d H:i:s", strtotime($submitted_data['time_zone']));
        
        if(Match::create($submitted_data)){
            return redirect('/matches')->with('success', 'Match is successfully saved');
        }
        else {
            return redirect('/matches/create')->with('success', 'Match save unsuccessfull');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function show(Match $match)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function edit(Match $match)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Match $match)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Match  $match
     * @return \Illuminate\Http\Response
     */
    public function destroy(Match $match)
    {
        //
    }
}
