<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMatchesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('matches', function (Blueprint $table) {
            $table->mediumInteger('id')->unsigned()->autoIncrement();
            $table->mediumInteger('tournament_id')->unsigned()->nullable();
            $table->tinyInteger('match_no')->unsigned()->nullable();
            $table->tinyInteger('country_id')->unsigned()->nullable();
            $table->smallInteger('city_id')->unsigned()->nullable();
            $table->string('venu',100);
            $table->dateTime('time_of_play');
            $table->dateTime('time_zone');
            $table->smallInteger('team_one_id')->unsigned()->nullable();
            $table->smallInteger('team_two_id')->unsigned()->nullable();
            $table->tinyInteger('status')->unsigned()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('matches');
    }
}
