<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit Tournament
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('tournaments.update', $tournament->id)); ?>" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?> 
            <div class="form-group">
                <label for="tournament_name">tournament Name:</label>
                <input type="text" class="form-control" name="tournament_name" value="<?php echo e($tournament->tournament_name); ?>"/>
            </div>
            <div class="form-group">
                <label for="team_number">Team Number:</label>
                <input type="text" class="form-control" name="team_number"  value="<?php echo e($tournament->team_number); ?>"/>
            </div> 
            <div class="form-group">
                <label for="started_date">Started Date:</label>
                <input type="text" class="form-control datePicCls" name="started_date"  value="<?php echo e(date("m/d/Y", strtotime($tournament->started_date))); ?>"/>
            </div>
            <div class="form-group">
                <label for="ended_date">Ended Date:</label>
                <input type="text" class="form-control datePicCls" name="ended_date"  value="<?php echo e(date("m/d/Y", strtotime($tournament->ended_date))); ?>"/>
            </div>    
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7\htdocs\laravel_projects\IccCwc19\resources\views/tournaments/edit.blade.php ENDPATH**/ ?>