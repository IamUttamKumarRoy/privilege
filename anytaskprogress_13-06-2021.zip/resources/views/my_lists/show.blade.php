@extends('layouts.adminlte')

  

@section('content')

    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2> Show Product</h2>

            </div>

            <div class="pull-right">

                <a class="btn btn-primary" href="{{ route('my_lists.index') }}"> Back</a>

            </div>

        </div>

    </div>

   

    <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Name:</strong>

                {{ $my_list->list_name }}

            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Description:</strong>

                {{ $my_list->description }}

            </div>

        </div>

    </div>
    <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12">

            
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th style="width: 10px">#</th>
                  <th>List Name</th>
                  <th>List Desc</th>      
                  
                  @if(!empty($list_options) )
                    @foreach($list_options as $id=> $option_name)
                    <th> {{ $option_name }} </th>
                    @endforeach
                  @endif

                </tr>
              </thead>
              <tbody>
                @if(!empty($child_list) )
                    @foreach($child_list as $key=> $list_info)
                    <tr>
                        <td>{{ $key++}}</td>
                        <td>{{ $list_info->list_name }}</td>
                        <td>{{ $list_info->list_description}}</td>
                      @if(!empty($option_value_arr[$list_info->id]) )
                        @foreach($option_value_arr[$list_info->id] as $option_value )
                            <td>{{ $option_value}}</td>
                        @endforeach
                      @endif
                    </tr> 
                    @endforeach
                @endif
              </tbody>
            </table>


        </div> 

    </div>


@endsection