@extends('layouts.adminlte')

 

@section('content')

    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                 

            </div>

            <div class="pull-right">

                <a class="btn btn-success" href="{{ route('my_lists.create') }}"> Create New my_list</a>

            </div>

        </div>

    </div>

   

    @if ($message = Session::get('success'))

        <div class="alert alert-success">

            <p>{{ $message }}</p>

        </div>

    @endif

   

    <table class="table table-bordered">

        <tr>

            <th>No</th>

            <th>List Name</th>

            <th>Details</th>
            <th>Body</th>

            <th width="280px">Action</th>

        </tr>

        @foreach ($my_lists as $my_list)

        <tr>

            <td>{{ ++$i }}</td>

            <td>{{ $my_list->list_name }}</td>

            <td>{{ $my_list->description }}</td>
            <td>{{ $my_list->list_body }}</td>

            <td>

                <form action="{{ route('my_lists.destroy',$my_list->id) }}" method="POST">

   

                    <a class="btn btn-info" href="{{ route('my_lists.add_child',$my_list->id) }}">Add Child</a>
                    <a class="btn btn-info" href="{{ route('my_lists.show',$my_list->id) }}">Show</a>

    

                    <a class="btn btn-primary" href="{{ route('my_lists.edit',$my_list->id) }}">Edit</a>

   

                    @csrf

                    @method('DELETE')

      

                    <button type="submit" class="btn btn-danger">Delete</button>

                </form>

            </td>

        </tr>

        @endforeach

    </table>

  

    {!! $my_lists->links() !!}

      

@endsection