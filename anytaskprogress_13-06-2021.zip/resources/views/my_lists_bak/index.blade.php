@extends('layouts.adminlte')

 

@section('content')

    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2>Laravel 8 CRUD Example from scratch - ItSolutionStuff.com</h2>

            </div>

            <div class="pull-right">

                <a class="btn btn-success" href="{{ route('my_lists.create') }}"> Create New Product</a>

            </div>

        </div>

    </div>

   

    @if ($message = Session::get('success'))

        <div class="alert alert-success">

            <p>{{ $message }}</p>

        </div>

    @endif

   

    <table class="table table-bordered">

        <tr>

            <th>No</th>

            <th>Name</th>

            <th>Details</th>

            <th width="280px">Action</th>

        </tr>

        @foreach ($my_lists as $m_list)

        <tr>

            <td>{{ ++$i }}</td>

            <td>{{ $m_list->name }}</td>

            <td>{{ $m_list->detail }}</td>

            <td>

                <form action="{{ route('my_lists.destroy',$m_list->id) }}" method="POST">

   

                    <a class="btn btn-info" href="{{ route('my_lists.show',$m_list->id) }}">Show</a>

    

                    <a class="btn btn-primary" href="{{ route('my_lists.edit',$m_list->id) }}">Edit</a>

   

                    @csrf

                    @method('DELETE')

      

                    <button type="submit" class="btn btn-danger">Delete</button>

                </form>

            </td>

        </tr>

        @endforeach

    </table>

  

    {!! $my_lists->links() !!}

      

@endsection