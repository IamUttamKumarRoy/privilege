<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ProductController;
use App\Http\Controllers\MyListController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::resource('products', ProductController::class);
Route::resource('my_lists', MyListController::class);

// Create options for list
Route::get('/my_lists/create_list_options/{id}', [MyListController::class, 'createListOptions']);
Route::post('my_lists/save_list_options', [MyListController::class, 'saveListOptions'])->name('my_lists.save_list_options');

// Create options for list
Route::get('/my_lists/add_child/{id}', [MyListController::class, 'addChild'])->name('my_lists.add_child');
Route::post('my_lists/save_child', [MyListController::class, 'saveChild'])->name('my_lists.save_child');


Route::get('/demo', function () {
   return view('demo');
});
Route::get('/starter', function () {
   return view('starter');
});