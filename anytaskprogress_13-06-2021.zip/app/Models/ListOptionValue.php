<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ListOptionValue extends Model
{
    use HasFactory;

    protected $fillable = [
        'list_id', 'list_option_id', 'option_value'
    ]; 
}
