<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ListOption extends Model
{
    use HasFactory;

    protected $fillable = [
        'list_parent_id', 'list_id', 'option_name'
    ];
}
