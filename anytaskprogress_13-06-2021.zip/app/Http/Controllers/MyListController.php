<?php

namespace App\Http\Controllers;

use App\Models\MyList;
use App\Models\ListOption;
use App\Models\ListOptionValue;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class MyListController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $my_lists = MyList::latest()->paginate(5);
        return view('my_lists.index',compact('my_lists'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $list_lists = MyList::all()->pluck('list_name', 'id');
        return view('my_lists.create',compact('list_lists'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {        
        $request->validate([
            'list_name' => 'required',
            'description' => 'required',
            'list_body' => 'required',
        ]);
        MyList::create($request->all());
        return redirect()->route('my_lists.index')
                        ->with('success','List created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(MyList $my_list)
    {
        // variable declaration
        $child_list_ids   = array();
        $list_option_ids  = array();
        $option_value_arr = array();

        $child_list = MyList::where('parent_id',$my_list->id)->get();
        $list_options = ListOption::where('list_parent_id',$my_list->id)->pluck('option_name', 'id');


        if( !empty($child_list) ) 
        {
            foreach ($child_list as $key => $list_info ) 
            {
                $child_list_ids[] = $list_info->id; 
            }
        }

        if( !empty($list_options) ) 
        {
            foreach ($list_options as $list_option_id => $option_name ) 
            {
                $list_option_ids[] = $list_option_id; 
            }
        }

        $option_value_data = ListOptionValue::whereIn('list_id',$child_list_ids)->orWhereIn('list_id',$list_option_ids)->get();
        
        if( !empty($option_value_data) )
        {
            $inc = 0;
            foreach ($option_value_data as $key => $option_value_info ) 
            {
                $option_value_arr[$option_value_info->list_id][$option_value_info->list_option_id] = $option_value_info->option_value;
            }
        }


        echo "<pre>";
        print_r($child_list_ids);
        print_r($list_option_ids);
        print_r($option_value_arr);
        //print_r($option_value_data);
        echo "</pre>";

        return view('my_lists.show',compact('my_list','child_list','list_options','option_value_arr'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(MyList $my_list)
    {
        return view('my_lists.edit',compact('my_list'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MyList $my_list )
    {
        $request->validate([
            'list_name' => 'required',
            'description' => 'required',
            'list_body' => 'required',
        ]);

        $my_list->update($request->all());
        return redirect()->route('my_lists.index')
                        ->with('success','List updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createListOptions($id)
    {
        $list_lists = MyList::all()->pluck('list_name', 'id');
        return view('my_lists.create_list_options',compact('list_lists'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveListOptions(Request $request)
    {        
        //dd($request->all());
        $request->validate([
            'option_name' => 'required', 
        ]);
        ListOption::create($request->all());
        return redirect()->route('my_lists.index')
                        ->with('success','List Option created successfully.');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addChild($id)
    {
       $my_list = MyList::where('id', $id)->first();
       $list_options = ListOption::where('list_parent_id',$my_list->id)->pluck('option_name', 'id');

        echo "<pre>";
        print_r($id);
        print_r($my_list->id);
        print_r($list_options);
        echo "</pre>";
       return view('my_lists.add_child',compact('list_options','my_list'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveChild(Request $request)
    {        
        $option_value_record = array();
        //dd($request->all());
        
        $request->validate([
            'list_name' => 'required', 
            'parent_id' => 'required', 
        ]);
        
        $inserted_child_list_id =  MyList::create($request->all())->id;
        
       // $inserted_child_list_id = 8;

        $option_values = $request->input('addmore');

        if( !empty($option_values) )
        {
            $inc = 0;
            foreach ($option_values as $option_list_id => $option_value) 
            {
                $option_value_record[$inc]['list_id']        = $inserted_child_list_id;
                $option_value_record[$inc]['list_option_id'] = $option_list_id;
                $option_value_record[$inc]['option_value']   = $option_value['option_list_id'];

                $inc++;
            }
        }

        echo "<pre>"; 
        print_r($inserted_child_list_id);
        print_r($option_values);
        print_r($option_value_record);
        echo "</pre>";
        //die;
       
        ListOptionValue::insert($option_value_record);
        return redirect()->route('my_lists.index')
                        ->with('success','List Option created successfully.');
    }
    
}
