<?php

namespace Database\Factories;

use App\Models\MyList;
use Illuminate\Database\Eloquent\Factories\Factory;

use Faker\Generator as Faker;


class MyListFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = MyList::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'parent_id'   =>  '100',
            'list_name'   =>  $this->faker->sentences($nb = 20, $asText = false)  ,
            'description' =>  $this->faker->text($maxNbChars = 200),
            'list_body'   =>  $this->faker->text($maxNbChars = 200),
            'user_id'     =>  100,
        ];
    }
}
