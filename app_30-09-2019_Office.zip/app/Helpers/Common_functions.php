<?php
if (! function_exists('get_result')) {
    function get_result($result_id, $result_key = null) 
    {
        if( $result_id == $result_key ) {
        	return 1;
        } else {
        	return 0;
        }
    }
}


if (!function_exists('pr')) {

/**
 */
    function pr($var) {
        if (config('app.debug')== true) {
            $template = php_sapi_name() !== 'cli' ? '<pre>%s</pre>' : "\n%s\n";
            printf($template, print_r($var, true));
        }
    }

}