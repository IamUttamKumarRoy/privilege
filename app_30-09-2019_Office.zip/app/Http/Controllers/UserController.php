<?php

namespace App\Http\Controllers;

use App\Listing ;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('index');
    }
 
    public function profile()
    {
        return view('user.profile');
    } 

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Listing  $listing
     * @return \Illuminate\Http\Response
     */
    public function myDoList(Listing $list)
    {
        return view('user.mydolist',compact('list'));
    }
}
