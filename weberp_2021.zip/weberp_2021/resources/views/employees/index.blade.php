@extends('layouts.basic')

@section('content')

    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2>Employee</h2>

            </div>

            <div class="pull-right">

                <a class="btn btn-success" href="{{ route('employees.create') }}"> Create New employee</a>

            </div>

        </div>

    </div>

   

    @if ($message = Session::get('success'))

        <div class="alert alert-success">

            <p>{{ $message }}</p>

        </div>

    @endif

   

    <table class="table table-bordered">

        <tr>

            <th>No</th>

            <th>Name</th>

            <th>Department</th>
            <th>Current Post</th>
            <th>Date of Birth</th>
            <th>Joining Sate</th>
            <th>Prl date</th>

            <th width="280px">Action</th>

        </tr>

        @foreach ($employees as $employee)

        <tr>

            <td>{{ ++$i }}</td>

            <td>{{ $employee->employee_name }}</td>
            <td>{{ $employee->department }}</td>
            <td>{{ $employee->current_post }}</td>
            <td>{{ $employee->date_of_birth }}</td>
            <td>{{ $employee->joining_date }}</td>
            <td>{{ $employee->prl_date }}</td>

            <td>

                <form action="{{ route('employees.destroy',$employee->id) }}" method="POST">

   

                    <a class="btn btn-info" href="{{ route('employees.show',$employee->id) }}">Show</a>

    

                    <a class="btn btn-primary" href="{{ route('employees.edit',$employee->id) }}">Edit</a>

   

                    @csrf

                    @method('DELETE')

      

                    <button type="submit" class="btn btn-danger">Delete</button>

                </form>

            </td>

        </tr>

        @endforeach

    </table>

  

    {!! $employees->links() !!}

      

@endsection