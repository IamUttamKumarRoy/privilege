<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PostRank extends Model
{
    use HasFactory;

     protected $fillable = [
        'rank_value', 'rank_name','rank_shortname'
    ];
    
}
