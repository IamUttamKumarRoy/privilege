<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_name', 'date_of_birth','department','rank_id','rank_shortname','current_post','joining_date','prl_date'
    ];
}
