<?php

if (!function_exists( 'getPostRanks'))
{

	function getPostRanks( $post_name_list =null, $post_name = null )
	{
		$post_rank = '';
		if( !empty($post_name_list ) )
		{
			foreach ($post_name_list as $post_rank_key => $post_name_str ) 
			{
				if( trim($post_name) == ($post_name_str ) )
				{
					$post_rank = $post_rank_key;
				}	
			}
		}
		return $post_rank;
	}

}