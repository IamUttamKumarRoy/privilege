<?php

if (!function_exists( 'getPostRankByPostName'))
{

	function getPostRankByPostName( $post_name_list = null , $post_name = null )
	{
		$post_rank_id = '';

		if( !empty($post_name_list ) )
		{
			foreach ($post_name_list as $post_rank_key => $list_post_name ) 
			{
				if( trim($post_name) == trim($list_post_name) )
				{
					$post_rank_id = $post_rank_key;
					break;
				}
			}
		}
		return $post_rank_id;
	}

}

if (!function_exists( 'getTobePromotedRank'))
{

	function getTobePromotedRank( $post_rank_list = null , $post_rank = null )
	{
		$promoted_post_rank = array();

		if( !empty($post_rank_list ) )
		{
			foreach ($post_rank_list as $post_rank_key => $list_post_name ) 
			{
				if( $post_rank <= $post_rank_key )
					break;
				$promoted_post_rank[$post_rank_key] = $list_post_name;
				//$promoted_post_rank[$post_rank_key] = $post_rank_key;
			}
		}
		return $promoted_post_rank;
	}

}

if (!function_exists( 'getUpperRankEmployee'))
{

	function getUpperRankEmployee( $employee_list = null , $current_employee_id = null )
	{
		$new_employee_list = array();

		if( !empty($employee_list ) )
		{
			$inc = 0; 
			foreach ($employee_list as $key => $employee_row ) 
			{
				if( $current_employee_id == $employee_row['id'] )
					break;
				$new_employee_list[] = $employee_row; 
				$inc++;
			}
		}
		return $new_employee_list;
	}

}