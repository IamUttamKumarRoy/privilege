<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\PostRank;
use Illuminate\Http\Request;

use Carbon\Carbon;


class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees = Employee::orderBy('id')->paginate(10);

        return view('employees.index',compact('employees'))
            ->with('i', (request()->input('page', 1) - 1) * 10);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $employee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Employee $employee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update_ranks()
    {
        // Declaration of variable

        $employee_update_arr = array();

       /* $employees = Employee::where('active', 1)
           ->orderBy('id')
           //->take(10)
           ->get();*/
        $employees = Employee::orderBy('id')
                   ->get();

        $post_rank_arr = PostRank::all()->pluck('rank_name', 'id');

        ///dd($post_rank_arr);

        if( !empty($employees))
        {
            $inc = 0;
            foreach ($employees as $key => $emp_row ) 
            {
                $employee_update_arr[$inc]['id']   = $emp_row->id;
                $employee_update_arr[$inc]['name'] = $emp_row->employee_name;
                $employee_update_arr[$inc]['current_post'] = $emp_row->current_post;
                $employee_update_arr[$inc]['rank_id'] = getPostRankByPostName($post_rank_arr,$emp_row->current_post);
                $inc++;

                /*$employee = Employee::find($emp_row->id);
                $employee->rank_id = getPostRankByPostName($post_rank_arr,$emp_row->current_post);
                $employee->save();*/
            }
        }

        echo "<pre>";
            print_r($employee_update_arr);
        echo "</pre>";
        return view('employees.update_ranks',compact('employees'));
    }    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function get_merit_position()
    {
        // Declaration of variable
        $post_allotment  = array(
            1 => 1,
            2 => 3,
            3 => 12,
            4 => 37,
            5 => 32,
            6 => 100
        );
        $employee_arr    = array();
        $employee_mp_arr = array();

        $employees    = Employee::orderBy('id')
                   ->get();

        $post_rank_arr = PostRank::all()->pluck('rank_name', 'id');

        ///dd($post_rank_arr);

        if( !empty($employees))
        {
            $inc = 0;
            foreach ($employees as $key => $emp_row ) 
            {
                $employee_arr[$inc]['id']           = $emp_row->id;
                $employee_arr[$inc]['name']         = $emp_row->employee_name;
                $employee_arr[$inc]['current_post'] = $emp_row->current_post;
                $employee_arr[$inc]['date_of_birth']= $emp_row->date_of_birth;
                $employee_arr[$inc]['joining_date'] = $emp_row->joining_date;
                $employee_arr[$inc]['prl_date']     = $emp_row->prl_date;
                $employee_arr[$inc]['rank_id']      = $emp_row->rank_id;
                $inc++;
            }
        }

  
        $inc = 0;
        if( !empty($employee_arr ) )
        {
            
            $current_emp_id      = '';
            $promoted_rank_ids   = array();
            
            
            foreach ($employee_arr as $key => $emp_row ) 
            {
                $temp_promoted_arr                        = array();
                $current_emp_id                           = $emp_row['id'];
                $current_emp_rank_id                      = $emp_row['rank_id'];
                $temp_post_allotment                      = $post_allotment;

                $employee_mp_arr[$inc]['id']              = $emp_row['id'];
                $employee_mp_arr[$inc]['name']            = $emp_row['name'];
                $employee_mp_arr[$inc]['joining_date']    = $emp_row['joining_date'];
                $employee_mp_arr[$inc]['prl_date']        = $emp_row['prl_date'];
                $employee_mp_arr[$inc]['current_rank_id'] = $emp_row['rank_id'];

                $promoted_rank_ids                        = getTobePromotedRank($post_rank_arr,$emp_row['rank_id']);
                //$promoted_rank_ids                        = array_reverse($promoted_rank_ids,true);
                $employee_mp_arr[$inc]['might_promoted']  = $promoted_rank_ids;
                
                $new_employee_list = getUpperRankEmployee($employee_arr,$current_emp_id);
                //$employee_mp_arr[$inc]['upper_employee']  = $new_employee_list;

                //$current_emp_prl = Carbon::parse($emp_row['prl_date']);
                $current_emp_prl = $emp_row['prl_date'];

                if( !empty( $promoted_rank_ids) )
                {
                    foreach ($promoted_rank_ids as $rank_id => $rank_nmae ) 
                    {
                        // Get upper rank employee
                        
                       /* echo "<pre>";
                        print_r($rank_nmae);
                        echo "</pre>";*/
                        if( !empty($new_employee_list) )
                        {
                           // $inc = 0;
                            $temp_prl_date = 0;
                            foreach ($new_employee_list as $key => $emp_row ) 
                            { 
                                $temp_prl_date = Carbon::parse($emp_row['prl_date']); 
                                if( $current_emp_prl > $emp_row['prl_date'] && $rank_id < $emp_row['rank_id'])
                                {
                                    //echo $emp_row['prl_date'];
                                    if( $temp_post_allotment[$rank_id] > 0 )
                                    {
                                        $temp_post_allotment[$rank_id] = $temp_post_allotment[$rank_id] -1; 

                                        $temp_promoted_arr[$rank_id]['promoted_date']    = $emp_row['prl_date']; 
                                        $temp_promoted_arr[$rank_id]['promoted_from_id'] = $emp_row['id']; 

                                        unset($new_employee_list[$key]);
                                    }
                                    else{
                                         //echo "E-2";
                                    }                                    
                                }  
                                else
                                {
                                    //echo $current_emp_rank_id ."-". $emp_row['rank_id'];
                                    //echo "E-1";
                                }                              
                            }
                        }
                    }
                }

                $employee_mp_arr[$inc]['will_promoted']        = $temp_promoted_arr;

                $inc++;
            }
        }

        echo "<pre>";
            print_r($post_rank_arr);
            print_r($employee_mp_arr);
            //print_r($employee_arr);
        echo "</pre>";
        return view('employees.get_merit_position',compact('employees'));
    }  
}
