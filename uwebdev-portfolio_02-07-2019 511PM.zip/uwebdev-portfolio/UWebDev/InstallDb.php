<?php
if(!defined('WPINC')) {
    die();
}

if( !class_exists( 'UWebDev_InstallDb' ) ) {

	final class UWebDev_InstallDb 
	{
		private static $instance;
    
	    public static function getInstance() {
	        if(self::$instance==null) {
	            self::$instance = new self; 
	        }
	        
	        return self::$instance;
	    }
	    
	    private function __construct() {
	        ;
	    }

	     public function createDB() 
	     {	     	
	     	global $wpdb;
	        $sqls = array();

	        $rps_department      = UWebDev_Portfolio::getTablePrefix() . 'departments';
	        $rps_batch           = UWebDev_Portfolio::getTablePrefix() . 'batches';
	        $rps_exam            = UWebDev_Portfolio::getTablePrefix() . 'exams';
	        $rps_grade           = UWebDev_Portfolio::getTablePrefix() . 'grade';
	        $rps_exam_record     = UWebDev_Portfolio::getTablePrefix() . 'exam_records';
	        $rps_exam_record_meta = UWebDev_Portfolio::getTablePrefix() . 'exam_record_meta';
	        $rps_marks           = UWebDev_Portfolio::getTablePrefix() . 'marks';

	        if ( method_exists( $wpdb, 'get_charset_collate' ) ) {
	            $charset_collate = $wpdb->get_charset_collate();
	        } else {
	            if (!empty ($wpdb->charset))
	                $charset_collate = "DEFAULT CHARACTER SET {$wpdb->charset}";
	            if (!empty ($wpdb->collate))
	                $charset_collate .= " COLLATE {$wpdb->collate}";
	        }
 
	        $sqls[] = "CREATE TABLE {$rps_department} (
	                    id bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	                    name varchar(50) NOT NULL,
	                    slug varchar(28) NOT NULL,
	                    full_name varchar(150) NOT NULL,
	                    description text NOT NULL,
	                    credit decimal(5,2) unsigned NOT NULL DEFAULT '0',
	                    active tinyint(1) unsigned NOT NULL DEFAULT '1',
	                    added int(10) unsigned NOT NULL,
	                    updated timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	                  ) $charset_collate;";
	         

	        $sqls[] = "CREATE TABLE {$rps_grade} (
	                    id bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	                    grade varchar(250) NOT NULL,
	                    marks varchar(250) NOT NULL,
	                    grade_point numeric (5,2) NOT NULL,
	                    grade_classification varchar(250) NOT NULL,
	                    active tinyint(1) unsigned NOT NULL DEFAULT '1',
	                    added int(10) unsigned NOT NULL,
	                    updated timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	                  ) $charset_collate ;";

	        $sqls[] = "CREATE TABLE {$rps_exam} (
	                    id bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	                    name varchar(250) NOT NULL,
	                    exam_month enum('01','02','03','04','05','06','07','08','09','10','11','12') NOT NULL,
	                    exam_year year(4) NOT NULL,
	                    display tinyint(1) unsigned NOT NULL DEFAULT '1',
	                    active tinyint(1) unsigned NOT NULL DEFAULT '1',
	                    added int(10) unsigned NOT NULL,
	                    updated timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	                  ) $charset_collate ;"; 



	        //new table for highest marks/grade subject wise, will do it later
	        

	        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	        foreach ($sqls as $key => $sql) {
	            dbDelta( $sql );
	        }
	     }
	}
}