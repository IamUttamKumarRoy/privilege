<?php
ini_set("user_agent","Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0");

include('../simplehtmldom_1_9/simple_html_dom.php');

// Create DOM from URL or file
$html = file_get_html('https://en.wikipedia.org/wiki/Hinduism_by_country');

$images_arr = array();

  
// Find all article blocks
/*foreach($html->find('div.article') as $article) {
    $item['title']     = $article->find('div.title', 0)->plaintext;
    $item['intro']    = $article->find('div.intro', 0)->plaintext;
    $item['details'] = $article->find('div.details', 0)->plaintext;
    $articles[] = $item;
}*/


// get the table. Maybe there's just one, in which case just 'table' will do
//$table = $html->find('table.wikitable');

// initialize empty array to store the data array from each row
//$theData = array();

// loop over rows
/*foreach($table->find('tr') as $row) {

    // initialize array to store the cell data from each row
    $rowData = array();
    foreach($row->find('td.text') as $cell) {

        // push the cell's text to the array
        $rowData[] = $cell->innertext;
    }

    // push the row's data array to the 'big' array
    $theData[] = $rowData;
}*/
//print_r($theData);

$country_info = array();
$inc = 0;
/*foreach($html->find('table tr') as $row) 
{
	$region_name      = $row->find('td', 0)->innertext;
	$country_name     = $row->find('td', 1)->innertext;
	$percentage       = $row->find('td', 2)->innertext;
	$total_population = $row->find('td', 3)->innertext;
	$hindu_total      = $row->find('td', 4)->innertext;

	$country_info[$inc]['region_name']      = $region_name;
	$country_info[$inc]['country_name']     = $country_name;
	$country_info[$inc]['percentage']       = $percentage;
	$country_info[$inc]['total_population'] = $total_population;
	$country_info[$inc]['hindu_total']      = $hindu_total;

    $inc++;

    echo "<pre>";
		print_r($row);
	echo "</pre>";
	break;
}*/

/*foreach($html->find('table tr td') as $e){
    $arr[] = trim($e->innertext);
}*/

/*$pct = array();
$pcu = array();
foreach ($html->find('table') as $div_element){
      
	foreach ($div_element->find('th') as $pcts){
	     $pct[] = $pcts->plaintext;
	}


	foreach ($div_element->find('td[align=center]') as $pcus){
	     $pcu[] = $pcus->plaintext;
	}

	foreach ($div_element->find('td') as $pcus){
	     $pcu[] = $pcus->plaintext;
	}
}*/
$hindu_by_country = array();
$inc = 1;
foreach ($html->find('table.wikitable') as $table_element){
    $get_record = false;  
    foreach ($table_element->find('th') as $pcts){
	     $th_cell = $pcts->plaintext;
	     //echo "[{$th_cell}]<br/>";
	     if( strtolower(trim($th_cell)) == "country" ) {
	     	$get_record = true;
	     	break;
	     }
	}

	if( $get_record ) 
	{
		foreach ( $table_element->find('tr') as $tr_element ) 
		{
			$region           = $tr_element->children(0)->plaintext;
			$country          = $tr_element->children(1)->plaintext;
			$percentage       = $tr_element->children(2)->plaintext;
			$total_population = $tr_element->children(3)->plaintext;
			$hindu_total      = $tr_element->children(4)->plaintext;

			$region           = strip_tags($region);


		     $hindu_by_country[$inc]['region']           = $region;
		     $hindu_by_country[$inc]['country']          = $country;
		     $hindu_by_country[$inc]['percentage']       = $percentage;
		     $hindu_by_country[$inc]['total_population'] = $total_population;
		     $hindu_by_country[$inc]['hindu_total']      = $hindu_total;

		     $inc++; 
		}		
	}
}

/*echo "<pre>"; 
	print_r($hindu_by_country);
echo "</pre>";*/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    echo $sql . "<br>" . $e->getMessage();
}


//$stmt = $pdo->prepare("INSERT INTO attendees (name, twitter_handle, url) VALUES (:name,:twitter_handle,:url)");
$stmt = $pdo->prepare("INSERT INTO hinduism_by_country (region, country, percentage, total_population, hindu_total) VALUES (:region, :country, :percentage, :total_population, :hindu_total);");

try {
    $pdo->beginTransaction();
    foreach ($hindu_by_country as $key=> $row)
    {
        $stmt->execute([':region' => $row['region'],':country' => $row['country'],':percentage' => $row['percentage'],':total_population' => $row['total_population'],':hindu_total' => $row['hindu_total']]) ;
    }
    $pdo->commit();
}catch (Exception $e){
    $pdo->rollback();
    throw $e;
}

$conn = null;