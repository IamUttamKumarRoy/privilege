<?php
ini_set("user_agent","Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0");

include('../simplehtmldom_1_9/simple_html_dom.php');

if( !function_exists('clean_data') )
{
	function clean_data($param = null )
	{
		$param = trim($param);	
		$param = html_entity_decode($param);
		$param = str_replace("â€“", "-", $param);
		$param = str_replace("<", "", $param);

		$param = preg_replace('/\[[\s\S]+?\]/', '', $param);
		$param = preg_replace('/\([\s\S]+?\)/', '', $param);

		$param = trim($param);
		$param = str_replace("â€“", "-", $param);
		$param = strip_tags($param);

		return $param;
	}
}
if( !function_exists('empty_check') )
{
	function empty_check($param = null )
	{
		if( !empty($param) ) {
			return $param;
		} else {
			return null;
		}
		
	}
}
// Create DOM from URL or file
$html = file_get_html('https://en.wikipedia.org/wiki/Hinduism_by_country');

$hindu_by_region = array();
$inc = 1;

foreach ($html->find('table.wikitable') as $table_element)
{
    $get_record = false;  
    foreach ($table_element->find('th') as $pcts){
	     $th_cell = $pcts->plaintext;	     
	     if( strtolower(trim($th_cell)) == "hindus" ) {
	     	$get_record = true;
	     	break;
	     }
	}

	if( $get_record ) 
	{
		foreach ( $table_element->find('tr') as $tr_element ) 
		{
			$region               = empty_check($tr_element->children(0)->plaintext);
			$total_population     = empty_check($tr_element->children(1)->plaintext);
			$hindus               = empty_check($tr_element->children(2)->plaintext);
			$percentage_of_hindus = empty_check($tr_element->children(3)->plaintext);
			$hindu_total          = empty_check($tr_element->children(4)->plaintext);

			$region               = clean_data($region);
			$total_population     = clean_data($total_population);
			$hindus               = clean_data($hindus);
			$percentage_of_hindus = clean_data($percentage_of_hindus);
			$hindu_total          = clean_data($hindu_total);


		     $hindu_by_region[$inc]['region']               = $region;
		     $hindu_by_region[$inc]['total_population']     = $total_population;
		     $hindu_by_region[$inc]['hindus']               = $hindus;
		     $hindu_by_region[$inc]['percentage_of_hindus'] = $percentage_of_hindus;
		     $hindu_by_region[$inc]['hindu_total']          = $hindu_total;

		     $inc++; 
		}		
	}
}



echo "<pre>"; 
	print_r($hindu_by_region);
echo "</pre>";

/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    echo $sql . "<br>" . $e->getMessage();
}
  
$stmt = $pdo->prepare("INSERT INTO hinduism_by_region (region, total_population, hindus, percentage_of_hindus, percentage_of_hindu_total) VALUES (:region, :total_population, :hindus, :percentage_of_hindus, :percentage_of_hindu_total);");

try {
    $pdo->beginTransaction();
    foreach ($hindu_by_region as $key=> $row)
    {
        $stmt->execute([':region' => $row['region'],':total_population' => $row['total_population'],':hindus' => $row['hindus'],':percentage_of_hindus' => $row['percentage_of_hindus'],':percentage_of_hindu_total' => $row['hindu_total']]) ;
    }
    $pdo->commit();
}catch (Exception $e){
    $pdo->rollback();
    throw $e;
}

$conn = null;
*/