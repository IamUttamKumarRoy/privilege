<?php
ini_set("user_agent","Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0");

include('../simplehtmldom_1_9/simple_html_dom.php');

if( !function_exists('clean_data') )
{
	function clean_data($param = null )
	{
		$param = trim($param);	
		$param = html_entity_decode($param);
		$param = str_replace("â€“", "-", $param);
		$param = str_replace("<", "", $param);

		$param = preg_replace('/\[[\s\S]+?\]/', '', $param);
		$param = preg_replace('/\([\s\S]+?\)/', '', $param);

		$param = trim($param);
		$param = str_replace("â€“", "-", $param);
		$param = strip_tags($param);

		return $param;
	}
}
if( !function_exists('empty_check') )
{
	function empty_check($param = null )
	{
		if( !empty($param) ) {
			return $param;
		} else {
			return null;
		}
		
	}
}
// Create DOM from URL or file
$html = file_get_html('https://en.wikipedia.org/wiki/Nepal');

$table_header    = array();
$hindu_by_region = array();
$inc             = 1;
$religion        = "";
$gdp_element     = array();

$start_gdp = false;
$gdp_index = 0;
foreach ($html->find('table.infobox') as $table_element)
{
    $get_record = false;  
    foreach ($table_element->find('th') as $table_header) {
	     $th_cell = $table_header->plaintext;	
	     $table_head[] = $th_cell;  
	     if( strtolower(trim($th_cell)) == "religion" ) {
	     	$religion = $table_header->next_sibling()->plaintext;	     	
	     	//$get_record = true;
	     	//break;
	     }

	     	     	
	     if (strpos(strtolower(trim($th_cell)), 'gdp') !== false) { 	     	
	     	$start_gdp = true;
	     	$gdp_index = 1; 
	     }

	     if( $start_gdp && $gdp_index ) {
	     	$gdp = $table_header->next_sibling()->plaintext;
	     	$gdp_element[] = $gdp;
	     	$gdp_index++;
	     	if( $gdp_index > 3 ) {
	     		$start_gdp = false;
	     		$gdp_index = 0;
	     	}
	     }
	     
	}


	if( 0 ) 
	{
		foreach ( $table_element->find('tr') as $tr_element ) 
		{
			$region               = empty_check($tr_element->children(0)->plaintext);
			$total_population     = empty_check($tr_element->children(1)->plaintext);
			$hindus               = empty_check($tr_element->children(2)->plaintext);
			$percentage_of_hindus = empty_check($tr_element->children(3)->plaintext);
			$hindu_total          = empty_check($tr_element->children(4)->plaintext);

			$region               = clean_data($region);
			$total_population     = clean_data($total_population);
			$hindus               = clean_data($hindus);
			$percentage_of_hindus = clean_data($percentage_of_hindus);
			$hindu_total          = clean_data($hindu_total);


		     $hindu_by_region[$inc]['region']               = $region;
		     $hindu_by_region[$inc]['total_population']     = $total_population;
		     $hindu_by_region[$inc]['hindus']               = $hindus;
		     $hindu_by_region[$inc]['percentage_of_hindus'] = $percentage_of_hindus;
		     $hindu_by_region[$inc]['hindu_total']          = $hindu_total;

		     $inc++; 
		}		
	}
}

$religion_arr = explode("%", $religion) ;

$religion_percent  = array();
$inc_i = 1;
if( !empty($religion_arr) )
{
	foreach ($religion_arr as $key => $rel_info ) {
		$religion_percent[$inc_i][] = $rel_info;
		$inc_i++;
	}
}
echo "<pre>"; 
	//print_r($table_header);
	print_r($gdp_element);
	//print_r($religion);
	print_r($religion_percent);
	print_r($religion_arr);
echo "</pre>";

/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    echo $sql . "<br>" . $e->getMessage();
}
  
$stmt = $pdo->prepare("INSERT INTO hinduism_by_region (region, total_population, hindus, percentage_of_hindus, percentage_of_hindu_total) VALUES (:region, :total_population, :hindus, :percentage_of_hindus, :percentage_of_hindu_total);");

try {
    $pdo->beginTransaction();
    foreach ($hindu_by_region as $key=> $row)
    {
        $stmt->execute([':region' => $row['region'],':total_population' => $row['total_population'],':hindus' => $row['hindus'],':percentage_of_hindus' => $row['percentage_of_hindus'],':percentage_of_hindu_total' => $row['hindu_total']]) ;
    }
    $pdo->commit();
}catch (Exception $e){
    $pdo->rollback();
    throw $e;
}

$conn = null;
*/