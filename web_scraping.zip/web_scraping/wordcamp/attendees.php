<?php
ini_set("user_agent","Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0");

include('../simplehtmldom_1_9/simple_html_dom.php');

// Create DOM from URL or file
$html = file_get_html('https://2019.dhaka.wordcamp.org/attendees/');

$images_arr = array();
$url_arr    = array();
$name_arr   = array();

$img_inc    = 1;   
$url_inc    = 1;   
$name_inc   = 1;   
// Find all images
foreach($html->find('img') as $element) {
	//echo $element->src . '<br>';
	$images_arr[$img_inc] = $element->src;
	$img_inc++;
}
       

// Find all links
foreach($html->find('a') as $element) {
	//echo $element->href . '<br>'; 
	$url_arr[$url_inc] = $element->href;
	$url_inc++;
}
   
foreach($html->find('div.tix-attendee-name') as $e) {
    
	//echo $element->href . '<br>'; 
	$name_arr[$name_inc] = $e->innertext;
	$name_inc++;
}    



foreach($html->find('div.tix-attendee-name') as $e) {
    
	//echo $element->href . '<br>'; 
	$name_arr[$name_inc] = $e->innertext;
	$name_inc++;
} 

$inc  = 1;
$attendees_info = array();
$attendees_data = array();

foreach($html->find('ul.tix-attendee-list li') as $elem ) {
    $attendees_info[$inc]['name']    = $elem->children(1)->innertext;
    $attendees_info[$inc]['twitter'] = !empty($elem->children(2)->innertext) ? $elem->children(2)->innertext :'';
    $attendees_info[$inc]['url']     = !empty($elem->children(3)->href) ? $elem->children(3)->href :'';

	$attendees_data[$inc]    = $elem->children(1)->innertext;
    $attendees_data[$inc]    = !empty($elem->children(2)->innertext) ? $elem->children(2)->innertext :'';
    $attendees_data[$inc]    = !empty($elem->children(3)->href) ? $elem->children(3)->href :'';
	$inc++;
} 

echo "<pre>";
	print_r($attendees_info);
	print_r($name_arr);
echo "</pre>";


/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    echo $sql . "<br>" . $e->getMessage();
}


$stmt = $pdo->prepare("INSERT INTO attendees (name, twitter_handle, url) VALUES (:name,:twitter_handle,:url)");

try {
    $pdo->beginTransaction();
    foreach ($attendees_info as $key=> $row)
    {
        $stmt->execute([':name' => strip_tags($row['name']),':twitter_handle' => $row['twitter'],':url' => $row['url']]) ;
    }
    $pdo->commit();
}catch (Exception $e){
    $pdo->rollback();
    throw $e;
}

$conn = null;

*/