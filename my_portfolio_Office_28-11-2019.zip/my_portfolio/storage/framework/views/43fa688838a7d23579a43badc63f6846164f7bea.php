<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Update User Role
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('privilege_menus.update', $privilege_menu->id)); ?>">
          <div class="form-group">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PATCH'); ?>
              <label for="name">privilege_menu_category_id:</label>
              <input type="text" class="form-control" name="privilege_menu_category_id" value="<?php echo e($privilege_menu->privilege_menu_category_id); ?>"/>
          </div>
          <div class="form-group">
              <label for="price">Privilege Name :</label>
              <input type="text" class="form-control" name="privilege_name" value="<?php echo e($privilege_menu->privilege_name); ?>"/>
          </div> 
          <div class="form-group">
              <label for="price">Uri :</label>
              <input type="text" class="form-control" name="uri" value="<?php echo e($privilege_menu->uri); ?>"/>
          </div> 
          <div class="form-group">
              <label for="price">Route Name :</label>
              <input type="text" class="form-control" name="route_name" value="<?php echo e($privilege_menu->route_name); ?>"/>
          </div> 
          <div class="form-group">
              <label for="price">Method :</label>
              <input type="text" class="form-control" name="methods" value="<?php echo e($privilege_menu->methods); ?>"/>
          </div> 
          <div class="form-group">
              <label for="price">Controller :</label>
              <input type="text" class="form-control" name="controller" value="<?php echo e($privilege_menu->controller); ?>"/>
          </div> 
          <div class="form-group">
              <label for="price">action :</label>
              <input type="text" class="form-control" name="action" value="<?php echo e($privilege_menu->action); ?>"/>
          </div> 
          <div class="form-group">
              <label for="price">ordering :</label>
              <input type="text" class="form-control" name="ordering" value="<?php echo e($privilege_menu->ordering); ?>"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update Privilege Menu</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/privilege_menus/edit.blade.php ENDPATH**/ ?>