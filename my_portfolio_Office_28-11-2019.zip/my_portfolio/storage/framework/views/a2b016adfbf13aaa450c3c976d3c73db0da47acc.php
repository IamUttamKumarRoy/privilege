<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 6 CRUD</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('privilege_menus.create')); ?>"> Create New Privilege Menu</a>
            </div>
        </div>
    </div>

  
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Category</th>
            <th>Privilege Name</th>
            <th>Uri</th>
            <th>Route Name</th>
            <th>Controller</th>
            <th>Action</th> 
            <th>Ordering</th> 
            <th width="280px">Action</th>
        </tr> 
        <?php $__currentLoopData = $privilege_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilege_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($privilege_menu->privilege_menu_category_id); ?></td>
            <td><?php echo e($privilege_menu->privilege_name); ?></td>
            <td><?php echo e($privilege_menu->uri); ?></td> 
            <td><?php echo e($privilege_menu->route_name); ?></td> 
            <td><?php echo e($privilege_menu->methods); ?></td> 
            <td><?php echo e($privilege_menu->controller); ?></td> 
            <td><?php echo e($privilege_menu->action); ?></td> 
            <td><?php echo e($privilege_menu->ordering); ?></td> 
            <td>
                <form action="<?php echo e(route('privilege_menus.destroy',$privilege_menu->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('privilege_menus.show',$privilege_menu->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('privilege_menus.edit',$privilege_menu->id)); ?>">Edit</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $privilege_menus->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/privilege_menus/index.blade.php ENDPATH**/ ?>