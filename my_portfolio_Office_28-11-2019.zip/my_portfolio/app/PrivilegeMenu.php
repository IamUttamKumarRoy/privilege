<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrivilegeMenu extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        //'privilege_menu_category_id',
        'privilege_menu_category_id',
        'privilege_name',
        'uri',
        'route_name',
        'methods',
        'action',
        'controller',
        'ordering',
        'status'
    ]; 
}
