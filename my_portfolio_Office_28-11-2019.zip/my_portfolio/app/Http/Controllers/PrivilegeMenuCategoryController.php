<?php

namespace App\Http\Controllers;

use App\PrivilegeMenuCategory;
use Illuminate\Http\Request;

class PrivilegeMenuCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $privilege_menu_categories = PrivilegeMenuCategory::latest()->paginate(5);
        return view('privilege_menu_categories.index',compact('privilege_menu_categories'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('privilege_menu_categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_name' => 'required'  
        ]);

        PrivilegeMenuCategory::create($request->all());

        return redirect()->route('privilege_menu_categories.index')
                        ->with('success','Privilege Menu Category created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $privilege_menu_category = PrivilegeMenuCategory::findOrFail($id);

        return view('privilege_menu_categories.show', compact('privilege_menu_category'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $privilege_menu_category = PrivilegeMenuCategory::findOrFail($id);

        return view('privilege_menu_categories.edit', compact('privilege_menu_category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([ 
            'category_name' => 'required' ,
            'precedence' => '' 
        ]);
        PrivilegeMenuCategory::whereId($id)->update($validatedData);

        return redirect()->route('privilege_menu_categories.index')->with('success', 'Privilege Menu Category is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $privilege_menu_category = PrivilegeMenuCategory::findOrFail($id);
        $privilege_menu_category->delete();
 
        return redirect()->route('privilege_menu_categories.index')->with('success', 'Privilege Menu Category is successfully deleted');
    }
}
