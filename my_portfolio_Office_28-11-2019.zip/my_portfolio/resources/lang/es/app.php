<?php

return [
    'title' =>  'Ejemplo de localización'
];