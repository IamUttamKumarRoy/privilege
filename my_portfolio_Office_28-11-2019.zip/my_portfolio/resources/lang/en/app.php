<?php

return [
    'title' =>  'Localization Exmaple'
];