@extends('layouts.admin_lte')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Employee (Programming Side)</h2>
                <h4> {{ $desire_date }}</h4>
            </div> 
        </div>
    </div>

  
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif   

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Date of Birth</th>
            <th>Department</th>            
            <th>Joining Date</th>
            <th>PRL Date</th>
            <th>Current Post</th>
            <th>New Post</th>
        </tr>
        <?php $employee_key = 0; ?>
        @foreach( $current_post as $post_rank => $post_count)            
            <?php $inc = 0; ?>
            <?php $inc_to = $post_count; ?>

            @for ($inc = 0; $inc < $inc_to; $inc++)
                @php $current_emp_key = key($employee_list_arr);@endphp            
                @if ( !empty($employee_list_arr[$employee_key]) )
                    <tr>
                        <td>{{ ($employee_key+1) }}</td>
                        <td>{{ $employee_list_arr[$employee_key]['employee_name'] }}</td>
                        <td>{{ $employee_list_arr[$employee_key]['date_of_birth'] }}</td>
                        <td>{{ $employee_list_arr[$employee_key]['department'] }}</td>                        
                        <td>{{ $employee_list_arr[$employee_key]['joining_date'] }}</td>
                        <td>{{ $employee_list_arr[$employee_key]['prl_date'] }}</td>
                        <td>{{ $employee_list_arr[$employee_key]['current_post'] }}</td>
                        <td>
                            {{ $post_rank }} - {{ ($inc+1) }}
                        </td>
                    </tr>
                @else
                    <tr>
                        <td>{{ ($employee_key+1) }}</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>
                            {{ $post_rank }} - {{ ($inc+1) }}
                        </td>
                    </tr>
                @endif
                
                @php $employee_key++; @endphp
            @endfor
        @endforeach
    </table>

    
<style type="text/css"> 

.table td, .table th {
  border: 1px solid #4CAF50 !important;
  padding: 5px;
}
  
</style>

@endsection