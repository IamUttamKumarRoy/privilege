@extends('layouts.admin_lte')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Update User Role
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
    <form method="post" action="{{ route('privilege_menus.update', $user_role->id) }}">
          <div class="form-group">
              @csrf
              @method('PATCH')
              <label for="name">privilege_menu_category_id:</label>
              <input type="text" class="form-control" name="privilege_menu_category_id" value="{{ $user_role->privilege_menu_category_id }}"/>
          </div>
          <div class="form-group">
              <label for="price">Privilege Name :</label>
              <input type="text" class="form-control" name="privilege_name" value="{{ $user_role->privilege_name }}"/>
          </div> 
          <div class="form-group">
              <label for="price">Uri :</label>
              <input type="text" class="form-control" name="uri" value="{{ $user_role->uri }}"/>
          </div> 
          <div class="form-group">
              <label for="price">Route Name :</label>
              <input type="text" class="form-control" name="route_name" value="{{ $user_role->route_name }}"/>
          </div> 
          <div class="form-group">
              <label for="price">Method :</label>
              <input type="text" class="form-control" name="methods" value="{{ $user_role->methods }}"/>
          </div> 
          <div class="form-group">
              <label for="price">Controller :</label>
              <input type="text" class="form-control" name="controller" value="{{ $user_role->controller }}"/>
          </div> 
          <div class="form-group">
              <label for="price">action :</label>
              <input type="text" class="form-control" name="action" value="{{ $user_role->action }}"/>
          </div> 
          <div class="form-group">
              <label for="price">ordering :</label>
              <input type="text" class="form-control" name="ordering" value="{{ $user_role->ordering }}"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update Privilege Menu</button>
      </form>
  </div>
</div>
@endsection