@extends('layouts.admin_lte')

@section('content')



<ul data-role="tree_view" data-role-tree_view="true" class="tree_view">
   <li class="tree-node expanded current">
      <label class="checkbox transition-on" for="checkbox-1576387533040246">
      <input type="checkbox" data-role="checkbox" data-caption="Play video" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533040246" class="">
      <span class="check"></span><span class="caption">Play video</span></label>
      <ul>
         <li class="">
            <label class="checkbox transition-on" for="checkbox-1576387533041757">
            <input type="checkbox" data-role="checkbox" data-caption="AVI" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533041757" class="">
            <span class="check"></span><span class="caption">AVI</span></label>
         </li>
         <li class="">
            <label class="checkbox transition-on" for="checkbox-157638753304214">
            <input type="checkbox" data-role="checkbox" data-caption="MPEG" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-157638753304214" class=""><span class="check"></span><span class="caption">MPEG</span></label>
         </li>
         <li class="">
            <label class="checkbox transition-on" for="checkbox-1576387533042661">
            <input checked="" type="checkbox" data-role="checkbox" data-caption="VIDX" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533042661" class=""><span class="check"></span><span class="caption">VIDX</span></label>
         </li>
         <li class="">
            <label class="checkbox transition-on" for="checkbox-157638753304220">
            <input type="checkbox" data-role="checkbox" data-caption="MP4" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-157638753304220" class=""><span class="check"></span><span class="caption">MP4</span></label>
         </li>
         <li class="">
            <label class="checkbox transition-on" for="checkbox-1576387533043433">
            <input checked="" type="checkbox" data-role="checkbox" data-caption="XVID" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533043433" class=""><span class="check"></span><span class="caption">XVID</span></label>
         </li>
      </ul>
   </li>
   <li>
      <label class="checkbox transition-on" for="checkbox-1576387533044589">
      <input type="checkbox" data-role="checkbox" data-caption="Play audio" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533044589" class=""><span class="check"></span><span class="caption">Play audio</span></label>
   </li>
   <li class="tree-node expanded">
      <label class="checkbox transition-on" for="checkbox-1576387533044531">
      <input type="checkbox" data-role="checkbox" data-caption="Subtitles" title="" data-indeterminate="true" data-role-checkbox="true" id="checkbox-1576387533044531" class=""><span class="check"></span><span class="caption">Subtitles</span></label>
      <ul>
         <li>
            <label class="checkbox transition-on" for="checkbox-1576387533045295">
            <input type="checkbox" data-role="checkbox" data-caption="English" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533045295" class=""><span class="check"></span><span class="caption">English</span></label>
         </li>
         <li class="">
            <label class="checkbox transition-on" for="checkbox-1576387533045375">
            <input checked="" type="checkbox" data-role="checkbox" data-caption="Ukrainian" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533045375" class=""><span class="check"></span><span class="caption">Ukrainian</span></label>
         </li>
         <li>
            <label class="checkbox transition-on" for="checkbox-1576387533046128">
            <input type="checkbox" data-role="checkbox" data-caption="Dutch" title="" data-indeterminate="false" data-role-checkbox="true" id="checkbox-1576387533046128" class=""><span class="check"></span><span class="caption">Dutch</span></label>
         </li>
      </ul>
   </li>
</ul>

@endsection