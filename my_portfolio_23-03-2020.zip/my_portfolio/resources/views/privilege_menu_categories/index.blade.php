@extends('layouts.admin_lte')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Privilege Menu Category</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('privilege_menu_categories.create') }}"> Create New Privilege Menu Categories</a>
            </div>
        </div>
    </div>

  
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Category Name</th>
            <th>Precedence</th> 
            <th width="280px">Action</th>
        </tr>
        @foreach ($privilege_menu_categories as $privilege_menu_category)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $privilege_menu_category->category_name }}</td>
            <td>{{ $privilege_menu_category->precedence }}</td> 
            <td>
                <form action="{{ route('privilege_menu_categories.destroy',$privilege_menu_category->id) }}" method="POST">
                    <a class="btn btn-info" href="{{ route('privilege_menu_categories.show',$privilege_menu_category->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('privilege_menu_categories.edit',$privilege_menu_category->id) }}">Edit</a>
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $privilege_menu_categories->links() !!}

@endsection