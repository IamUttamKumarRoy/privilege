<?php

return [
    'title' =>  'Lokalisierungsbeispiel'
];