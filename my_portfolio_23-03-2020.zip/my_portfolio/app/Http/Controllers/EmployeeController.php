<?php

namespace App\Http\Controllers;

use App\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $employees = Employee::orderBy('id', 'ASC')->orderBy('joining_date', 'asc')->paginate(10);
        //$employees = Employee::orderBy('joining_date', 'asc')->paginate(10);
        return view('employees.index',compact('employees'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employees.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $request->validate([
            'employee_name' => 'required', 
            'prl_date' => 'required'  
        ]);

        Employee::create($request->all());

        return redirect()->route('employees.index')
                        ->with('success','Employee created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $employee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Employee $employee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Employee $employee)
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function searchPost()
    {
        $current_post = array(
            'ED' => 1,
            'GM' => 3,
            'DGM'=> 10,
            'JD' => 30,
            'DD' => 40
        );
        return view('employees.search_post',compact('current_post'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function searchPostResult(Request $request)
    { 
        $request->validate([
            'desire_date' => 'required' 
        ]);
        $desire_date = $request->input('desire_date');

        $employees = Employee::where('prl_date', '>=', $desire_date)->where('status', '=', null)->orderBy('id', 'ASC')->orderBy('joining_date', 'asc')->get();

        $employee_list_arr = array();

        $current_post = array(
            'ED' => 1,
            'GM' => 3,
            'DGM'=> 10,
            'JD' => 35,
            'DD' => 40
        );
        $inc = 0;
        foreach ($employees as $employee)
        {
            $employee_list_arr[$inc]['employee_name'] = $employee->employee_name;
            $employee_list_arr[$inc]['date_of_birth'] = $employee->date_of_birth;
            $employee_list_arr[$inc]['department'] = $employee->department;
            $employee_list_arr[$inc]['current_post'] = $employee->current_post;
            $employee_list_arr[$inc]['joining_date'] = $employee->joining_date;
            $employee_list_arr[$inc]['prl_date'] = $employee->prl_date;
            $inc++;            
        }
        //echo "<pre>";        
        //print_r($employee_list_arr);
        //echo "</pre>";   
        //dd($employees);
        return view('employees.search_post_result',compact('employees','desire_date','current_post','employee_list_arr'));
    }
}
