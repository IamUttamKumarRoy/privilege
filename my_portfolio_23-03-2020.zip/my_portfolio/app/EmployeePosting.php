<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeePosting extends Model
{
    protected $fillable = [
    	'employee_id', 
    	'department_from', 
    	'department_to', 
    	'current_post', 
    	'new_post', 
    	'promotion_date', 
    	'status' 
    ]; 
}
