<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Employee (Programming Side)</h2>
                <h4> <?php echo e($desire_date); ?></h4>
            </div> 
        </div>
    </div>

  
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>   

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Date of Birth</th>
            <th>Department</th>            
            <th>Joining Date</th>
            <th>PRL Date</th>
            <th>Current Post</th>
            <th>New Post</th>
        </tr>
        <?php $employee_key = 0; ?>
        <?php $__currentLoopData = $current_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_rank => $post_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
            <?php $inc = 0; ?>
            <?php $inc_to = $post_count; ?>

            <?php for($inc = 0; $inc < $inc_to; $inc++): ?>
                <?php $current_emp_key = key($employee_list_arr);?>            
                <?php if( !empty($employee_list_arr[$employee_key]) ): ?>
                    <tr>
                        <td><?php echo e(($employee_key+1)); ?></td>
                        <td><?php echo e($employee_list_arr[$employee_key]['employee_name']); ?></td>
                        <td><?php echo e($employee_list_arr[$employee_key]['date_of_birth']); ?></td>
                        <td><?php echo e($employee_list_arr[$employee_key]['department']); ?></td>                        
                        <td><?php echo e($employee_list_arr[$employee_key]['joining_date']); ?></td>
                        <td><?php echo e($employee_list_arr[$employee_key]['prl_date']); ?></td>
                        <td><?php echo e($employee_list_arr[$employee_key]['current_post']); ?></td>
                        <td>
                            <?php echo e($post_rank); ?> - <?php echo e(($inc+1)); ?>

                        </td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td><?php echo e(($employee_key+1)); ?></td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>
                            <?php echo e($post_rank); ?> - <?php echo e(($inc+1)); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                
                <?php $employee_key++; ?>
            <?php endfor; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    
<style type="text/css"> 

.table td, .table th {
  border: 1px solid #4CAF50 !important;
  padding: 5px;
}
  
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/employees/search_post_result.blade.php ENDPATH**/ ?>