<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Employee (Programming Side)</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('employees.create')); ?>"> Create New employee</a>
            </div>
        </div>
    </div>

  
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>   

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Date of Birth</th>
            <th>Department</th>
            <th>Current Post</th>
            <th>Joining Date</th>
            <th>PRL Date</th>
            <th width="280px">Action</th>
        </tr>
        <?php $inc = 0;?>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$inc); ?></td>
            <td><?php echo e($employee->employee_name); ?></td>
            <td><?php echo e($employee->date_of_birth); ?></td>
            <td><?php echo e($employee->department); ?></td>
            <td><?php echo e($employee->current_post); ?></td>
            <td><?php echo e($employee->joining_date); ?></td>
            <td><?php echo e($employee->prl_date); ?></td>
            <td>
                <form action="<?php echo e(route('employees.destroy',$employee->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('employees.show',$employee->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('employees.edit',$employee->id)); ?>">Edit</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $employees->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/employees/index.blade.php ENDPATH**/ ?>