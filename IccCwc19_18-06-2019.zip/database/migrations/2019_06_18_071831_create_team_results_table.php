<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTeamResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('team_results', function (Blueprint $table) {
            $table->increments('id');
            $table->smallInteger('team_id')->unsigned()->nullable();
            $table->smallInteger('team_two_id')->unsigned()->nullable();
            $table->tinyInteger('result_id')->unsigned()->nullable();
            $table->smallInteger('win_by_run')->unsigned()->nullable();
            $table->smallInteger('win_by_wicket')->unsigned()->nullable();
            $table->smallInteger('team_one_run')->unsigned()->nullable();
            $table->smallInteger('team_two_run')->unsigned()->nullable();
            $table->float('team_one_over', 8, 2)->unsigned()->nullable();
            $table->float('team_two_over', 8, 2)->unsigned()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('team_results');
    }
}
