@extends('layouts.admin_lte')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Role Privilege</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('role_privileges.index') }}"> Back</a>
        </div>
    </div>
</div>

@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('role_privileges.store') }}" method="POST">
    @csrf
     <div class="row">
         
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
              <label for="user_role_id">Category:</label>
              <select class="form-control" name="user_role_id" id="user_role_id">
                <option>Select Privillege Menu Category</option>                         
                @if( !empty($user_roles) )     
                    @foreach ($user_roles as $user_role_id =>$user_role_name )    
                      <option value="{{ $user_role_id }}">{{ $user_role_name }}</option>
                    @endforeach
                @endif
            </select>
            </div> 
        </div>   
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>


    
    <div id="tree" data-type="tree" data-guid="9e4b3f64-fc45-7933-bbad-5296676f6d8b" class="gj-unselectable gj-tree-bootstrap-4">
       <ul class="gj-list gj-list-bootstrap">
          <li data-id="1" data-role="node" class="list-group-item">
             <div data-role="wrapper"><span data-role="spacer" style="width: 0px;"></span><span data-role="expander" data-mode="open" class="gj-tree-material-icons-expander"><i class="gj-icon minus"></i></span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="ec1f13fa-c3e4-0bac-1247-4aed9d69ba67" data-checkbox="true"><span class="gj-icon"></span></label>
                </span><span data-role="display">Asia</span>
             </div>
             <ul class="gj-list gj-list-bootstrap gj-hidden" style="display: block;">
                <li data-id="2" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="97759496-4ef3-d95b-0347-2c14b6676e5d" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">China</span>
                   </div>
                </li>
                <li data-id="3" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="37c7fa1e-eb41-0ca0-5bda-a3ad8757f7c8" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Japan</span>
                   </div>
                </li>
                <li data-id="4" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="97e25bd0-41b8-9881-1aa8-14bdf34b4677" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Mongolia</span>
                   </div>
                </li>
             </ul>
          </li>
          <li data-id="5" data-role="node" class="list-group-item">
             <div data-role="wrapper"><span data-role="spacer" style="width: 0px;"></span><span data-role="expander" data-mode="open" class="gj-tree-material-icons-expander"><i class="gj-icon minus"></i></span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="1a4e1a86-a505-b6b4-a56e-d9152069b899" data-checkbox="true"><span class="gj-icon"></span></label>
                </span><span data-role="display">North America</span>
             </div>
             <ul class="gj-list gj-list-bootstrap gj-hidden" style="display: block;">
                <li data-id="6" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander"><i class="gj-icon plus"></i></span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="9aa8e904-3b13-198e-a600-adbe6e4c5a5a" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">USA</span>
                   </div>
                   <ul class="gj-list gj-list-bootstrap gj-hidden">
                      <li data-id="7" data-role="node" class="list-group-item">
                         <div data-role="wrapper"><span data-role="spacer" style="width: 48px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="f79deedf-800e-c9f6-f272-2b679cffb155" data-checkbox="true"><span class="gj-icon"></span></label>
                            </span><span data-role="display">California</span>
                         </div>
                      </li>
                      <li data-id="8" data-role="node" class="list-group-item">
                         <div data-role="wrapper"><span data-role="spacer" style="width: 48px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="a994cd94-e56d-aa60-1ca1-37f6b3337bbb" data-checkbox="true"><span class="gj-icon"></span></label>
                            </span><span data-role="display">Florida</span>
                         </div>
                      </li>
                   </ul>
                </li>
                <li data-id="9" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="03942aa3-1c19-8d63-5b42-a33c8f23b528" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Canada</span>
                   </div>
                </li>
                <li data-id="10" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="4abd897d-7c8c-0593-a195-9307115465f7" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Mexico</span>
                   </div>
                </li>
             </ul>
          </li>
          <li data-id="11" data-role="node" class="list-group-item">
             <div data-role="wrapper"><span data-role="spacer" style="width: 0px;"></span><span data-role="expander" data-mode="open" class="gj-tree-material-icons-expander"><i class="gj-icon minus"></i></span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="085fb056-50ac-d7be-582e-0fe53c12f642" data-checkbox="true"><span class="gj-icon"></span></label>
                </span><span data-role="display">South America</span>
             </div>
             <ul class="gj-list gj-list-bootstrap gj-hidden" style="display: block;">
                <li data-id="12" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="a5c76a3b-c68b-0c91-4a38-d2be7c056363" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Brazil</span>
                   </div>
                </li>
                <li data-id="13" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="64c1dfeb-773f-9b17-3e68-b677306afe50" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Argentina</span>
                   </div>
                </li>
                <li data-id="14" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="29365871-ebd9-4558-af4c-0fc4f9b66d85" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Colombia</span>
                   </div>
                </li>
             </ul>
          </li>
          <li data-id="15" data-role="node" class="list-group-item">
             <div data-role="wrapper"><span data-role="spacer" style="width: 0px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander"><i class="gj-icon plus"></i></span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="48eec805-757b-4577-0cfd-b8cd30b64ce0" data-checkbox="true"><span class="gj-icon"></span></label>
                </span><span data-role="display">Europe</span>
             </div>
             <ul class="gj-list gj-list-bootstrap gj-hidden">
                <li data-id="16" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="53af957a-845b-dfdd-63fa-8c5eed2eba78" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">England</span>
                   </div>
                </li>
                <li data-id="17" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="1726bb05-553b-fa77-5f4c-39c46b630a75" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Germany</span>
                   </div>
                </li>
                <li data-id="18" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="bda9ea69-8a83-02ee-5a2b-3891db1917b1" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Bulgaria</span>
                   </div>
                </li>
                <li data-id="19" data-role="node" class="list-group-item">
                   <div data-role="wrapper"><span data-role="spacer" style="width: 24px;"></span><span data-role="expander" data-mode="close" class="gj-tree-material-icons-expander">&nbsp;</span><span data-role="checkbox"><label class="gj-checkbox-bootstrap gj-checkbox-bootstrap-4 gj-checkbox-material-icons"><input type="checkbox" data-type="checkbox" data-guid="e74fd498-8124-c5be-bfd0-357598f13288" data-checkbox="true"><span class="gj-icon"></span></label>
                      </span><span data-role="display">Poland</span>
                   </div>
                </li>
             </ul>
          </li>
       </ul>
    </div>
    
</form>



@endsection