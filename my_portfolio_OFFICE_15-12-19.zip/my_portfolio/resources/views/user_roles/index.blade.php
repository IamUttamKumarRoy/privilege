@extends('layouts.admin_lte')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 6 CRUD</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('user_roles.create') }}"> Create New User Role</a>
            </div>
        </div>
    </div>

  
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Role Name</th>
            <th>Precedence</th> 
            <th width="280px">Action</th>
        </tr>
        @foreach ($user_roles as $user_role)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $user_role->role_name }}</td>
            <td>{{ $user_role->precedence }}</td> 
            <td>
                <form action="{{ route('user_roles.destroy',$user_role->id) }}" method="POST">
                    <a class="btn btn-info" href="{{ route('user_roles.show',$user_role->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('user_roles.edit',$user_role->id) }}">Edit</a>
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $user_roles->links() !!}

@endsection