<section class="content-header">
	
	@if(!empty($page_header) )         
      <h1>
	    {{ $page_header }}
	    <small>{{ !empty($page_header_desc) ? $page_header_desc : '' }}</small>
	  </h1>
	@else       
	@endif

  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
    <li class="active">Here</li>
  </ol>
  
</section>