@extends('layouts.admin_lte')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Update Setting
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
    <form method="post" action="{{ route('settings.update', $setting->id) }}">
          <div class="form-group">
              @csrf
              @method('PATCH')
              <label for="name">Variable_group:</label>
              <input type="text" class="form-control" name="variable_group" value="{{ $setting->variable_group }}"/>
          </div>
          <div class="form-group">
              <label for="price">Variable Name :</label>
              <input type="text" class="form-control" name="variable_name" value="{{ $setting->variable_name }}"/>
          </div>
          <div class="form-group">
              <label for="price">variable_value :</label>
              <input type="text" class="form-control" name="variable_value" value="{{ $setting->variable_value }}"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update Setting</button>
      </form>
  </div>
</div>
@endsection