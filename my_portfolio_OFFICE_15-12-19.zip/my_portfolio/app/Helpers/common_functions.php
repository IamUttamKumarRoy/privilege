<?php

if(!function_exists('pr')){

	function pr( $to_be_dumped_var  = null )
	{
		echo "<pre>";
			print_r($to_be_dumped_var);
		echo "</pre>";
	}
}

if( !function_exists('show_setting_option')) {
    function show_setting_option( $setting_options= null, $website_setting_values =null )
	{
		
		if( !empty($setting_options) )
		{
			foreach ( $setting_options as $option_value ) 
			{ 			
				if ( empty( $option_value['type'] ) ) {
					continue;
				}

				if ( empty( $option_value['title'] ) ) {
					$option_value['title'] = empty( $option_value['title'] ) ? $option_value['title'] : '';
				}
				if (  empty( $option_value['class'] ) ) {
					$option_value['class'] = '';
				}
				if (  empty( $option_value['css'] ) ) {
					$option_value['css'] = '';
				}
				if (  empty( $option_value['default'] ) ) {
					$option_value['default'] = '';
				}
				if (  empty( $option_value['desc'] ) ) {
					$option_value['desc'] = '';
				}
				if (  empty( $option_value['desc_tip'] ) ) {
					$option_value['desc_tip'] = false;
				}
				if (  empty( $option_value['placeholder'] ) ) {
					$option_value['placeholder'] = '';
				}
				if (  empty( $option_value['suffix'] ) ) {
					$option_value['suffix'] = '';
				}

				$setting_db_value = '';
				if( !empty($website_setting_values[$option_value['id']]) ) {
					$setting_db_value = $website_setting_values[$option_value['id']];
				}
				
				switch ( $option_value['type'] )  {

					// Section Titles.
					case 'title':
						if ( ! empty( $option_value['title'] ) ) {
							echo '<h2>' .$option_value['title'] . '</h2>';
						}
						if ( ! empty( $option_value['desc'] ) ) {
							//echo '<div id="' .$option_value['id']. '-description">';
							echo $option_value['desc'] ;
							echo '</div>';
						} 
						break;
					case 'hidden':												 						
						$validation_arr = get_all_validation($option_value);
						$validation_string = '';
						if( !empty($validation_arr) ) 
						{
							foreach ($validation_arr as $v_key => $val_val ) {
								$validation_string .= $v_key.'="'.$val_val.'" ';
							} 
						}
						?> 
					    <input type="hidden"
							name="<?php echo $option_value['id']; ?>"
							value="<?php echo $option_value['default']; ?>"	 
							/>												
						<?php
						break;	
					case 'text':
					case 'password':
					case 'datetime':
					case 'datetime-local':
					case 'date':
					case 'month':
					case 'time':
					case 'week':
					case 'number':
					case 'email':
					case 'url':
					case 'tel':
						$option_value['value'] = !empty($option_value['value']) ? $option_value['value'] : '';
						?>
						<div class="form-group">

							<?php 							
							$validation_arr = get_all_validation($option_value);
							$validation_string = '';
							if( !empty($validation_arr) ) 
							{
								foreach ($validation_arr as $v_key => $val_val ) {
									$validation_string .= $v_key.'="'.$val_val.'" ';
								} 
							}
							?>
						    <label for="<?php echo $option_value['id']; ?>"><?php echo $option_value['title']; ?></label>
						    <input type="<?php echo $option_value['type']; ?>"
								name="<?php echo $option_value['id']; ?>"
								id="<?php echo $option_value['id']; ?>"								
								style="<?php echo $option_value['css']; ?>" 
								class="form-control <?php echo $option_value['class']; ?>"
								placeholder="<?php echo $option_value['placeholder']; ?>"
								value="<?php echo $setting_db_value; ?>"
								<?php echo $validation_string; ?> 
								/>
							
						</div> 
						<?php
						break;
					case 'image':
						$option_value['value'] = !empty($option_value['value']) ? $option_value['value'] : '';
						?>
						<div class="form-group">

							<?php 							
							$validation_arr = get_all_validation($option_value);
							$validation_string = '';
							if( !empty($validation_arr) ) 
							{
								foreach ($validation_arr as $v_key => $val_val ) {
									$validation_string .= $v_key.'="'.$val_val.'" ';
								} 
							}
							?>
							
							<img src="<?php echo asset('public/storage/setting_images/'.$setting_db_value); ?>" alt="" width="200" height="200"/>
						
						    <label for="<?php echo $option_value['id']; ?>"><?php echo $option_value['title']; ?></label>						    
							<input 
								type="file" 
								name="<?php echo $option_value['id']; ?>"
								id="<?php echo $option_value['id']; ?>"	
								style="<?php echo $option_value['css']; ?>" 
								class="form-control <?php echo $option_value['class']; ?>"
								placeholder="<?php echo $option_value['placeholder']; ?>"
								<?php echo $validation_string; ?> >
						</div> 
						<?php
						break;
					case 'checkbox':
						?>
							
							<div class="form-check">
						    	<input type="checkbox" 
						    	class="form-check-input" 
						    	id="<?php echo $option_value['id'] ; ?>"
						    	name="<?php echo $option_value['id'] ; ?>"
						    	>
						    	<label class="form-check-label" for="<?php echo $option_value['id'] ; ?>"><?php echo $option_value['title']; ?></label>
						 	</div>
						<?php
						break;
				}
			}
		}
	}
}


if(!function_exists('get_all_validation')){

	function get_all_validation( $option_value  = null )
	{
		$validation_arr      = array();
		$validation_arr_wkey = array();

		if( !empty($option_value['validation']) ) {
			$validation_arr = explode("|", $option_value['validation']);
		}
		

		if( !empty($validation_arr) )
		{
			foreach ($validation_arr as $key => $validation_row ) 
			{
				$temp_val_arr  = explode(":", $validation_row);	
					
				if( count($temp_val_arr) > 1 ) {
					$validation_arr_wkey[$temp_val_arr[0]] = $temp_val_arr[1];
				} else {
					$validation_arr_wkey[$temp_val_arr[0]] = $temp_val_arr[0];
				}		
			}
		}
		return $validation_arr_wkey;
	}
}