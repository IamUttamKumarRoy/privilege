<?php

namespace App\Http\Controllers;

use App\UserRole;
use Illuminate\Http\Request;

class UserRoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_roles = UserRole::latest()->paginate(5);
        return view('user_roles.index',compact('user_roles'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('user_roles.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'role_name' => 'required'  
        ]);

        UserRole::create($request->all());

        return redirect()->route('user_roles.index')
                        ->with('success','User Role created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UserRole  $userRole
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user_role = UserRole::findOrFail($id);

        return view('user_roles.show', compact('user_role'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserRole  $userRole
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user_role = UserRole::findOrFail($id);

        return view('user_roles.edit', compact('user_role'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserRole  $userRole
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $validatedData = $request->validate([ 
            'role_name' => 'required' ,
            'precedence' => '' 
        ]);
        UserRole::whereId($id)->update($validatedData);

        return redirect()->route('user_roles.index')->with('success', 'User Role is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserRole  $userRole
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user_role = UserRole::findOrFail($id);
        $user_role->delete();
 
        return redirect()->route('user_roles.index')->with('success', 'User Role is successfully deleted');
    }
}
