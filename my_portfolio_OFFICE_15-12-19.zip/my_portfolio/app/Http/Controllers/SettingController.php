<?php

namespace App\Http\Controllers;

use App\Setting;
use App\CommonClass\SettingOption;
use Illuminate\Http\Request;

class SettingController extends Controller
{

    public function __construct(SettingOption $setting_option) {
        $this->setting_option = $setting_option;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $settings = Setting::latest()->paginate(5);
        return view('settings.index',compact('settings'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('settings.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'variable_name' => 'required'  
        ]);

        Setting::create($request->all());

        return redirect()->route('settings.index')
                        ->with('success','Setting created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $setting = Setting::findOrFail($id);

        return view('settings.show', compact('setting'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $setting = Setting::findOrFail($id);

        return view('settings.edit', compact('setting'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([ 
            'variable_group' => '', 
            'variable_name' => 'required' ,
            'variable_value' => '' 
        ]);
        Setting::whereId($id)->update($validatedData);

        return redirect()->route('settings.index')->with('success', 'Setting is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $setting = Setting::findOrFail($id);
        $setting->delete();
 
        return redirect()->route('settings.index')->with('success', 'Setting is successfully deleted');
    }


        /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function siteSetting()
    {
        
        $website_settings = array(
            array(
                'title'    => 'group',
                'desc'     => 'Settings group', 
                'id'       => 'variable_group',                
                'default'  => 'basic_setting',
                'type'     => 'hidden', 
            ),
            array(
                'title'    => 'Username',
                'desc'     => 'Username to access private data', 
                'id'       => 'username',                
                'default'  => '',
                'type'     => 'text',
                'desc_tip' => true,
                'validation' => 'required|maxlength:5',
            ),
            array(
                'title'    => 'Password',
                'desc'     => 'Password to access private data', 
                'id'       => 'password',                
                'default'  => '',
                'type'     => 'password',
                'desc_tip' => true,
                'validation' => 'required|maxlength:10',
            ),
            array(
                'title'    => 'Name',
                'desc'     => 'Name of the user', 
                'id'       => 'name',                
                'default'  => '',
                'type'     => 'text',
                'desc_tip' => true,
                'validation' => 'required|maxlength:15',
            ),
            array(
                'title'    => 'Age',
                'desc'     => 'Name of the user', 
                'id'       => 'user_age',                
                'default'  => '',
                'type'     => 'number',
                'desc_tip' => true,
                'validation' => 'required|max:10',
            ),
            array(
                'title'         => 'Logged In',
                'desc'          => 'Allow user to logged in',
                'id'            => 'is_logged_in',                
                'default'       => 'yes',
                'type'          => 'checkbox',
                'checkboxgroup' => 'start',
                'autoload'      => false,
                'validation' => 'required|max:255',
            ),
            
        ); 

        
        $this->website_settings  = $website_settings;
        $this->setting_option->showForm($website_settings);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveSiteSetting(Request $request)
    {        
        $validation_arr = array();
        if( !empty($this->website_settings) )
        {
            foreach ($this->website_settings as $arr_key => $option_value) 
            {
                if( !empty($option_value['validation'])) {
                   $validation_arr[$option_value['id']] = $option_value['validation']; 
               }                
            }
        }

        $validatedData = $request->validate($validation_arr);

        $this->setting_option->saveFormInput($request);
        return redirect('/settings')->with('success', 'Setting  save unsuccessfull');
    }
}
