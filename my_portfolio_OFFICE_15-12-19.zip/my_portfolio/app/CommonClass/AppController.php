<?php
namespace App\CommonClass;
 
use DB;
use App\SectionType;
use App\PrivilegeMenuCategory;

class AppController{
 
	public function __construct() 
	{ 
	}

	public static function getUserRoleList() 
	{
	    return DB::table('user_roles')->where('status', 1)->pluck('role_name','id');
	}
 
 	public static function getPrivilegeMenuCategory() 
	{
	    $privilege_menu_category_list     = array(); 
	    $privilege_menu_category = PrivilegeMenuCategory::where('status', 1)->pluck('category_name', 'id'); 
        
        if( !empty($privilege_menu_category ) ) {
            foreach ($privilege_menu_category as $category_id => $category_name ) {
               $privilege_menu_category_list[$category_id]  = $category_name;
            }
        }
        return $privilege_menu_category_list;
	}
}
?>