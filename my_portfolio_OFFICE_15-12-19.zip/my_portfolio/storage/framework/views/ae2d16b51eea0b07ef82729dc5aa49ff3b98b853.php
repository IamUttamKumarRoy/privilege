<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Role Privilege</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('role_privileges.index')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('role_privileges.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
     <div class="row">

        <?php if( !empty($privilege_menus) ): ?>
            <ul class="tree_view">
                <?php
                $inc = 1;
                ?>
                <?php $__currentLoopData = $privilege_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_cat_id =>$pm_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <li class="tree-node expanded <?php echo e(($inc==1) ? 'current':''); ?> ">
                        <label class="checkbox" for="PrivilegeMenuCategory<?php echo e($menu_cat_id); ?>">
                        <input type="checkbox" name="privilege_menu_category[]" id="PrivilegeMenuCategory<?php echo e($menu_cat_id); ?>">
                        <span class="check"></span><span class="caption"><?php echo e(!empty($privilege_menu_category_list[$menu_cat_id]) ? $privilege_menu_category_list[$menu_cat_id]:''); ?></span></label>
                        
                        <?php if( !empty($pm_data) ): ?>
                        <ul>
                            <?php $__currentLoopData = $pm_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <li>
                                <label class="checkbox" for="PrivilegeMenu<?php echo e($pm_row['id']); ?>">
                                <input type="checkbox" name="privilege_menu[]" id="PrivilegeMenu<?php echo e($pm_row['id']); ?>">
                                <span class="check"></span><span class="caption"><?php echo e($pm_row['privilege_name']); ?></span></label>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>    
                    </li>
                    <?php
                    $inc++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>     
    </div> 
    
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/role_privileges/create.blade.php ENDPATH**/ ?>