<?php

$basic = 23100;
$basic = 27500;
$house_allowance_rate = 55;
$provident_fund_rate = 25;

$medical_allowance = 1500;
$mobile_allowance = 500;
$internet_allowance = 1000;

$other_allowance = array($medical_allowance,$mobile_allowance,$internet_allowance);

function get_salary($basic = NULL, $house_allowance_rate = NULL , $provident_fund_rate = NULL, $other_allowance = array())
{
	$grand_total = 0;
	$house_allowance = 0; 
	$provident_fund = 0; 
	$lunch_bill_per_day = 0; 
	$lunch_bill = 0; 

	if( trim($basic) > 0 ) {
		$house_allowance = ($basic * $house_allowance_rate)/100;
	}

	if( trim($basic) > 0 ) {
		$provident_fund = ($basic * $provident_fund_rate )/100;
	}
	 
	$lunch_bill = $lunch_bill_per_day * 20; 

	$grand_total = $basic + $house_allowance + $lunch_bill - $provident_fund;

	if( !empty($other_allowance) )
	{
		foreach ( $other_allowance as $oa_key => $allowance ) 
		{
			$grand_total += $allowance;
		}
	}
	return $grand_total;	
}

function day_based_salary($basic = NULL, $house_allowance_rate = NULL , $provident_fund_rate = NULL, $other_allowance = array(), $working_day= NULL )
{
	$grand_total = 0;
	$house_allowance = 0; 
	$provident_fund = 0; 
	$lunch_bill_per_day = 0; 
	$lunch_bill = 0; 

	if( trim($basic) > 0 ) {
		$house_allowance = ($basic * $house_allowance_rate)/100;
	}

	if( trim($basic) > 0 ) {
		$provident_fund = ($basic * $provident_fund_rate )/100;
	}
	 
	$lunch_bill = $lunch_bill_per_day * 20; 

	$grand_total = $basic + $house_allowance + $lunch_bill - $provident_fund;

	if( !empty($other_allowance) )
	{
		foreach ( $other_allowance as $oa_key => $allowance ) 
		{
			$grand_total += $allowance;
		}
	}
	return $grand_total;	
}

echo get_salary($basic,$house_allowance_rate,$provident_fund_rate,$other_allowance);

$employee_dob = '25-06-1990';
$date_of_joining = '08-06-2017';
$date_of_prl = '';
$today_date = date('d-m-Y');
$job_time_age = '';
$service_time = '';


$joining_date =date('d', strtotime($date_of_joining));
$joining_month =date('m', strtotime($date_of_joining));
$joining_month_string =date('M', strtotime($date_of_joining));
$joining_year =date('Y', strtotime($date_of_joining));

if( !empty($employee_dob))
	$job_time_age = date('Y', strtotime($date_of_joining)) - date('Y', strtotime($employee_dob));

$service_time = 59-$job_time_age;

$prl_year = $joining_year + $service_time;

echo "<br/>";
echo $service_time; 
echo "<br/>";
echo $job_time_age;
echo "<br/>";
echo $prl_year;
echo "<br/>";
echo $joining_month;

$date1 = '2017-06-08';
$date2 = '2018-05-31';
 

$year1 = date('Y', strtotime($date1));
$year2 = date('Y', strtotime($date2));

$month1 = date('m', strtotime($date1));
$month2 = date('m', strtotime($date2));

$diff = (($year2 - $year1) * 12) + ($month2 - $month1);
echo "<br/>";
echo $diff;

echo "<br/>";
echo date("F, d Y", strtotime("+12 months", strtotime("June 8, 2017")));
echo "<br/>";

$grand_total_salary = 0;
$first_basic = 23100;
$current_basic = 23100;
$house_allowance_rate = 55;
$provident_fund_rate = 25;

$medical_allowance = 1500;
$mobile_allowance = 500;
$internet_allowance = 1000;
$other_allowance = array($medical_allowance,$mobile_allowance,$internet_allowance);


$month_start = 06;
$start_year = 2018;
$current_month_string = date("M", mktime(0, 0, 0, $month_start, 10));

echo $current_month_string;
echo "<br/>";

for( $start_year = $joining_year; $start_year <= $prl_year; $start_year++ )
{
	
	if( $start_year == $joining_year )
	{
		for( $month_start = $joining_month; $month_start <= 12; $month_start++ )
		{
			echo $month_start." ";
		}
		echo "<br/>";
	}
	else
	{
		for( $month_start = 1; $month_start <= 12; $month_start++ )
		{
			$inc_month = date('01-M-Y',strtotime("{$joining_month_string} , {$start_year}"));
			$current_month_string =  date("M", mktime(0, 0, 0, $month_start, 10));
			$current_month = date('01-M-Y',strtotime("{$current_month_string} , {$start_year}"));
			
			if( strtolower($inc_month) === strtolower($current_month) )
			{
				echo "[Increment Month]";
				echo $month_start." ";
				if( $start_year == $prl_year )
					break;
			} 
			else
			{
				echo $month_start." ";
			}				
		}
		echo "<br/>";
	}
	
	
	echo $start_year."<br/>";
}
