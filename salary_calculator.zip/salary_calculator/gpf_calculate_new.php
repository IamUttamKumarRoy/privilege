<?php
$basic = 23100; 
$provident_fund_rate = 25;

if ( ! function_exists('number_format_fn'))
{
    function number_format_fn( $number = NULL ,$after_dot=0)
    {
        return number_format($number, $after_dot,'',',');
    }
}
function get_gpf($basic = NULL, $provident_fund_rate = NULL )
{
	$provident_fund = 0;  
 
	if( trim($basic) > 0 ) {
		$provident_fund = ($basic * $provident_fund_rate )/100;
	} 
	return $provident_fund;	
}

echo get_gpf($basic,$provident_fund_rate);

echo "<br/>";
//echo get_salary($basic,$house_allowance_rate,$provident_fund_rate,$other_allowance);

$employee_dob = '25-06-1990';
$date_of_joining = '08-06-2017';
//$date_of_joining = '01-01-2017';
$today_date = date('d-m-Y');
$date_of_prl = '';
$job_time_age = '';
$service_time = '';


$joining_date =date('d', strtotime($date_of_joining));
$joining_month =date('m', strtotime($date_of_joining));
$joining_month_string =date('M', strtotime($date_of_joining));
$joining_year =date('Y', strtotime($date_of_joining));

if( !empty($employee_dob))
	$job_time_age = date('Y', strtotime($date_of_joining)) - date('Y', strtotime($employee_dob));

$service_time = 59-$job_time_age;
//$service_time = 1;

$prl_year = $joining_year + $service_time;

$gpf_percentage = 13;
$grand_total_pf = 0;
$max_basic = 74400;
$current_basic = 23100;
$house_allowance_rate = 55;
$provident_fund_rate = 25;

$sl_inc = 1;
for( $start_year = $joining_year; $start_year <= $prl_year; $start_year++ )
{
	echo $sl_inc.". ". $start_year."  " ;
	$temp_sub_total_pf = 0;
	if( $start_year == $joining_year )
	{
		for( $month_start = $joining_month+1; $month_start <= 12; $month_start++ )
		{				
			$reporting_month = "01-{$month_start}-{$start_year}";	
			$day_num_count = date('t', strtotime($reporting_month));

			$temp_sub_total_pf = 0;
			for($dinc = 1; $dinc <= $day_num_count;$dinc++)
			{
				$temp_pf = 0;
				if( $grand_total_pf > 0 )
				{
					$temp_pf = (($gpf_percentage * $grand_total_pf)/100)/365;					
				}
				else
				{
					continue;
				}
				//echo $dinc." ";
				//echo $dinc." [".$grand_total_pf."] ";
				//echo " [".$temp_sub_total_pf."] ";
				$temp_sub_total_pf += $temp_pf;
			}
			//echo "<br/>";
			$grand_total_pf += $temp_sub_total_pf;
			$grand_total_pf += get_gpf($current_basic,$provident_fund_rate);
			//echo $month_start." [".number_format_fn($temp_sub_total_pf)."] ";
			echo ($month_start-1)." (".round($temp_sub_total_pf) .") ";
		}		
		echo " [".number_format_fn($grand_total_pf)."] ";
		//echo " [".number_format_fn($current_basic)."] ";
	}
	else
	{
		for( $month_start = 1; $month_start <= 12; $month_start++ )
		{
			$inc_month = date('01-M-Y',strtotime("{$joining_month_string} , {$start_year}"));
			$current_month_string =  date("M", mktime(0, 0, 0, $month_start, 10));
			$current_month = date('01-M-Y',strtotime("{$current_month_string} , {$start_year}"));
			
			$reporting_month = "01-{$month_start}-{$start_year}";	
			$day_num_count = date('t', strtotime($reporting_month));
			$temp_sub_total_pf = 0;
			for($dinc = 1; $dinc <= $day_num_count;$dinc++)
			{
				$temp_pf = 0;
				if( $grand_total_pf > 0 )
				{
					$temp_pf = (($gpf_percentage * $grand_total_pf)/100)/365;					
				}
				
				//echo $dinc." ";
				//echo $dinc." [".$grand_total_pf."] ";
				//echo " [".$temp_sub_total_pf."] ";
				$temp_sub_total_pf += $temp_pf;
			}
			//echo "<br/>";
			$grand_total_pf += $temp_sub_total_pf;

			if( strtolower($inc_month) === strtolower($current_month) )
			{
				//echo "[IM]";
				echo $month_start."  ";
				//echo $month_start." [".number_format_fn($temp_sub_total_pf)."] ";
				$grand_total_pf += get_gpf($current_basic,$provident_fund_rate);
				$current_basic += (($current_basic * 5)/100); 
				if( $current_basic > $max_basic ) {
					$current_basic = $max_basic;
				}
				if( $start_year == 2019 ) {
					$current_basic = 28100;
				}
				if( $start_year == $prl_year )
					break;
			} 
			else
			{
				$grand_total_pf += get_gpf($current_basic,$provident_fund_rate);
				echo $month_start." (".round($temp_sub_total_pf) .") ";
				//echo $month_start." [".number_format_fn($temp_sub_total_pf)."] ";
			}	

			//echo $month_start." ";
		}
			
		echo " [".number_format_fn($grand_total_pf)."] ";
		//echo " [".number_format_fn($current_basic)."] ";
		//echo "<br/>";
	}
	echo "<br/>";	
	//echo $current_basic;	
	$sl_inc++;
}

echo "<br/>[ Total GPF:{$grand_total_pf}]";