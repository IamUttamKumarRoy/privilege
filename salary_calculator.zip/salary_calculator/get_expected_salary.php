<?php

$basic = 23100;
$basic = 27500;
$house_allowance_rate = 55;
$provident_fund_rate  = 25;

$medical_allowance    = 1500;
$mobile_allowance     = 500;
$internet_allowance   = 1000;

$other_allowance = array($medical_allowance,$mobile_allowance,$internet_allowance);

if ( ! function_exists('number_format_fn'))
{
    function number_format_fn( $number = NULL ,$after_dot=0)
    {
        return number_format($number, $after_dot,'',',');
    }
}

function get_salary($basic = NULL, $house_allowance_rate = NULL , $provident_fund_rate = NULL, $other_allowance = array())
{
	$grand_total = 0;
	$house_allowance = 0; 
	$provident_fund = 0; 
	$lunch_bill_per_day = 200; 
	$lunch_bill = 0; 

	if( trim($basic) > 0 ) {
		$house_allowance = ($basic * $house_allowance_rate)/100;
	}

	if( trim($basic) > 0 ) {
		$provident_fund = ($basic * $provident_fund_rate )/100;
	}
	 
	$lunch_bill = $lunch_bill_per_day * 20; 

	$grand_total = $basic + $house_allowance + $lunch_bill - $provident_fund;

	if( !empty($other_allowance) )
	{
		foreach ( $other_allowance as $oa_key => $allowance ) 
		{
			$grand_total += $allowance;
		}
	}
	return $grand_total;	
}



//echo get_salary($basic,$house_allowance_rate,$provident_fund_rate,$other_allowance);

$employee_dob = '25-06-1990';
$date_of_joining = '08-06-2018';
$date_of_prl = '';
$today_date = date('d-m-Y');
$job_time_age = '';
$service_time = '';


$joining_date =date('d', strtotime($date_of_joining));
$joining_month =date('m', strtotime($date_of_joining));
$joining_month_string =date('M', strtotime($date_of_joining));
$joining_year =date('Y', strtotime($date_of_joining));

if( !empty($employee_dob))
	$job_time_age = date('Y', strtotime($date_of_joining)) - date('Y', strtotime($employee_dob));

$service_time = 59-$job_time_age;

$prl_year = $joining_year + $service_time;

/*echo "<br/>";
echo $service_time; 
echo "<br/>";
echo $job_time_age;
echo "<br/>";
echo $prl_year;
echo "<br/>";
echo $joining_month;*/
$current_basic = 23100;
$current_basic += (($current_basic * 5)/100);



$grand_total_salary = 0;
$max_basic = 74400;
$current_basic = 25300;
$house_allowance_rate = 55;
$provident_fund_rate = 25;

$medical_allowance = 1500;
$mobile_allowance = 500;
$internet_allowance = 1000;
$other_allowance = array($medical_allowance,$mobile_allowance,$internet_allowance);

for( $start_year = $joining_year; $start_year <= $prl_year; $start_year++ )
{
	echo $start_year ;
	if( $start_year == $joining_year )
	{
		for( $month_start = $joining_month; $month_start <= 12; $month_start++ )
		{			
			$grand_total_salary += get_salary($current_basic,$house_allowance_rate,$provident_fund_rate,$other_allowance);
			
		}
		$grand_total_salary += $current_basic*2 + (($current_basic*20)/100);
		echo " [".number_format_fn($grand_total_salary)."] ";
		echo "<br/>";
	}
	else
	{
		for( $month_start = 1; $month_start <= 12; $month_start++ )
		{
			$inc_month = date('01-M-Y',strtotime("{$joining_month_string} , {$start_year}"));
			$current_month_string =  date("M", mktime(0, 0, 0, $month_start, 10));
			$current_month = date('01-M-Y',strtotime("{$current_month_string} , {$start_year}"));
			
			if( strtolower($inc_month) === strtolower($current_month) )
			{
				//echo "[IM]";
				//echo $month_start." ";
				$grand_total_salary += get_salary($current_basic,$house_allowance_rate,$provident_fund_rate,$other_allowance);
				$current_basic += (($current_basic * 5)/100); 
				if( $current_basic > $max_basic ) {
					$current_basic = $max_basic;
				}
				//echo $month_start." [".$grand_total_salary."] ";
				//echo " <".$current_basic."> ";
				if( $start_year == $prl_year )
					break;
			} 
			else
			{
				$grand_total_salary += get_salary($current_basic,$house_allowance_rate,$provident_fund_rate,$other_allowance);
				//echo $month_start." [".$grand_total_salary."] ";
			}	
		}
		$grand_total_salary += $current_basic*2 + (($current_basic*20)/100);			
		echo " [".number_format_fn($grand_total_salary)."] ";
		echo "<br/>";
	}
	echo "<br/>";	
}
