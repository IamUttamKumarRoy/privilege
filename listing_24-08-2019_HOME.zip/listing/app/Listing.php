<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'parent_id',
        'list_type', 
        'list_title', 
        'list_body', 
        'list_thumb',  
        'status'
    ];
}
