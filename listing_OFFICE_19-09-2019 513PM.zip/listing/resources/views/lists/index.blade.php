@extends('layouts.layout')
@section('content')

<script type="text/javascript">
  function confirmDelete() {
    return confirm('Are you sure you want to delete?');
  }
</script>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 5.8 CRUD</h2>
            </div>

            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('lists.create') }}"> Create New Product</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Details</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($lists as $list)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $list->list_title }}</td>
            <td>{{ $list->list_body }}</td>
            <td>
                <form onsubmit="return ConfirmDelete()" action="{{ route('lists.destroy',$list->id) }}" method="POST">
                    <a class="btn btn-info" href="{{ route('lists.show',$list->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('lists.edit',$list->id) }}">Edit</a>
                    @csrf
                    @method('DELETE')
                    <input type="submit" class="btn btn-danger" value="Delete"/>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $lists->links() !!}



@endsection