<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, SparkPost and others. This file provides a sane default
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'sparkpost' => [
        'secret' => env('SPARKPOST_SECRET'),
    ],
    'google' => [
        'client_id' => 'app id',
        'client_secret' => 'add secret', 
        'http://uttamkumarroy.com/projects/laravel_projects/listing/login/google/callback',
    ],
    'github' => [
        'client_id' => 'Iv1.c11f13323d972aa7',
        'client_secret' => 'df57c8a051f6f1ff79e84ee06eb25193c6418c13',
        'redirect' => 'http://uttamkumarroy.com/projects/laravel_projects/listing/login/github/callback',
    ],
];
