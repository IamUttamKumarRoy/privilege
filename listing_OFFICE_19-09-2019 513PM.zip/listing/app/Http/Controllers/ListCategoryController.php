<?php

namespace App\Http\Controllers;

use Auth;
use App\ListCategory;
use Illuminate\Http\Request;

class ListCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $list_category = ListCategory::latest()->paginate(5);

        return view('list_category.index',compact('list_category'))->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $category_list = array();
        $user_id       = Auth::user()->id;
        $category_data = ListCategory::where('user_id', $user_id)->pluck('category_name', 'id');
        if( !empty($category_data) ) {
            foreach ($category_data as $category_id => $category ) {
               $category_list[$category_id] = $category;
            }
        }
        
        return view('list_category.create',compact('category_list'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_name' => 'required'
        ]);
        $request['user_id']  = Auth::user()->id;
        $request['ordering'] = 1;
        $request['status']   = 1;

        ListCategory::create($request->all());
        return redirect()->route('list_category.index')
                        ->with('success','List category created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ListCategory  $listCategory
     * @return \Illuminate\Http\Response
     */
    public function show(ListCategory $list_category)
    {
        return view('list_category.show',compact('list_category'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ListCategory  $listCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(ListCategory $list_category)
    {
        $user_id       = Auth::user()->id;
        $category_list = ListCategory::where('user_id', $user_id)->pluck('category_name', 'id');

        return view('list_category.edit',compact('list_category','category_list'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ListCategory  $listCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ListCategory $list_category)
    {
        $request->validate([
            'category_name' => 'required', 
        ]);

        $list_category->update($request->all());
        return redirect()->route('list_category.index')
                        ->with('success','List Category updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ListCategory  $listCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(ListCategory $list_category)
    {
        $list_category->delete();

        return redirect()->route('list_category.index')
                        ->with('success','List Category deleted successfully');
    }
}
