<?php

namespace App\Http\Controllers;

use Auth;
use DB;
use App\Listing;
use App\ListItem;
use Illuminate\Http\Request;

class ListItemController extends Controller
{
    // Logged In User ID
    protected $user_id  = '';

    protected $user;
    /**
    * Constructor.
    *
    * @return void
    */
   public function __construct()
   {
        $this->middleware(function ($request, $next) {
            $this->user= Auth::user();
            $this->user_id  = Auth::user()->id;
            return $next($request);
        });            
   }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->user_id  = Auth::user()->id;
        $lists = Listing::where('user_id',$this->user_id)->paginate(5);
        //$lists = Listing::latest()->paginate(5);

        return view('list_items.index',compact('lists'))->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {        
        $list_data = Listing::where('user_id', $this->user_id)->pluck('list_title', 'id');
        return view('list_items.create',compact('list_data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $list_item_record = [];

        $list_record = Listing::find($request['listing_id']);

        DB::beginTransaction();

        if( !empty($request['rows'] ) )
        {
            $inc = 0;
            foreach ($request['rows'] as $key => $row_val ) 
            {
                $list_item_record[$inc]['user_id']    = $this->user_id;
                $list_item_record[$inc]['item_type']  = $row_val['item_type'];
                $list_item_record[$inc]['item_title'] = $row_val['item_title'];
                $list_item_record[$inc]['item_body']  = $row_val['item_body'];
                
                $list_item[] = new ListItem($list_item_record[$inc]);
                
                $inc++;
            }
        }
        try {
            $list_record->list_items()->saveMany($list_item);            
            DB::commit();
            echo "Record Save Successfully!";
            // all good
        } catch (\Exception $e) {
            DB::rollback();
            echo "Something Went Wrong!";
            // something went wrong
        }

       // pr($list_item_record);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ListItem  $listItem
     * @return \Illuminate\Http\Response
     */
    public function show(ListItem $listItem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ListItem  $listItem
     * @return \Illuminate\Http\Response
     */
    public function edit(ListItem $listItem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ListItem  $listItem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ListItem $listItem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ListItem  $listItem
     * @return \Illuminate\Http\Response
     */
    public function destroy(ListItem $listItem)
    {
        //
    }
}
