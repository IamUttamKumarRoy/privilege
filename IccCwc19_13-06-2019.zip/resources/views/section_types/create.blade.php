@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Section Type
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('section_types.store') }}">
                    <div class="form-group">
                        @csrf
                        <label for="name">Section:</label>
                        <input type="text" class="form-control" name="section_type"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection