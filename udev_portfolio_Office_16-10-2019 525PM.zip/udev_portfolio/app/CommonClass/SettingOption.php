<?php

namespace App\CommonClass;

use Illuminate\Http\Request; 

class SettingOption
{
	public function __construct() 
	{ 
	}

	public function showForm( $website_settings = null ) 
	{	   
	   echo view('settings.site_setting',compact('website_settings'));
	}
  	
  	public function saveFormInput(Request $request) 
	{
	   dd($request->all());
	}

}
?>