<?php
namespace App\CommonClass;
 
use DB;
use App\SectionType;

class AppController{
 
	public function __construct() 
	{ 
	}

	public function getSectionTypeList() 
	{
	    return DB::table('section_types')->where('status', 1)->pluck('section_type','id');

	}

	public static function getLastName() {
	    return 'PHP';
	}
 
 	public function getPrivilegeMenuCategory() 
	{
	    $privilege_menu_list     = array(); 
	    $privilege_menu_category = PrivilegeMenuCategory::where('status', 1)->pluck('category_name', 'id'); 
        
        if( !empty($privilege_menu_category ) ) {
            foreach ($privilege_menu_category as $category_id => $category_name ) {
               $privilege_menu_list[$category_id]  = $category_name;
            }
        }
        return $privilege_menu_list;
	}
}
?>