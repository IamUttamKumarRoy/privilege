<?php

if(!function_exists('pr')){

	function pr( $to_be_dumped_var  = null )
	{
		echo "<pre>";
			print_r($to_be_dumped_var);
		echo "</pre>";
	}
}

if( !function_exists('setting_output_fields')) {
    function setting_output_fields( $website_settings)
	{
		echo "<pre>";
			print_r($website_settings);
		echo "</pre>";
	}
}

