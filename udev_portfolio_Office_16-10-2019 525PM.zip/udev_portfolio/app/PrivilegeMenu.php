<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrivilegeMenu extends Model
{  
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        //'privilege_menu_category_id',
        'privilege_menu_category_id',
        'privilege_name',
        'uri',
        'route_name',
        'methods',
        'action',
        'controller',
        'ordering',
        'status'
    ]; 
    
    //public $timestamps = false;

    /**
     * The users that belong to the role.
     */
    public function user_roles()
    {
        return $this->belongsToMany(UserRole::class,'user_role_privilege_menu');
    }
    
    /**
     * The users that belong to the role.
     */
    public function privilege_menu_categories()
    {
        return $this->belongsToMany(PrivilegeMenuCategory::class,'user_role_privilege_menu');
    }

}
