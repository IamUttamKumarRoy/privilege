<?php
/*
Plugin Name: Custom REST API endpoint with authentication
Plugin URI: https://www.damiencarbery.com/2018/02/custom-rest-api-endpoint-with-authentication/
Description: A starting point for custom REST API endpoint with authentication.
Author: Damien Carbery
Version: 0.1
*/
 
// Code heavily based on: https://www.wpeka.com/make-custom-endpoints-wordpress-rest-api.html
class List_Product_Stock_Rest_Server extends WP_REST_Controller {
	private $api_namespace;
	private $base;
	private $api_version;
	private $required_capability;
	
	public function __construct() {
		$this->api_namespace = 'list_product_stock/v';
		$this->base = 'list-product-stock';
		$this->api_version = '1';
		$this->required_capability = 'read';  // Minimum capability to use the endpoint
		
		$this->init();
	}
	
	
	public function register_routes() {
		$namespace = $this->api_namespace . $this->api_version;
		
		register_rest_route( $namespace, '/' . $this->base, array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'update_stock_info' ), ),
		)  );
	}
	// Register our REST Server
	public function init(){
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}
	
	
	public function update_stock_info( WP_REST_Request $request ){
		$creds = array();
		$headers = getallheaders();
		// Get username and password from the submitted headers.
		if ( array_key_exists( 'username', $headers ) && array_key_exists( 'password', $headers ) ) {
			$creds['user_login'] = $headers["username"];
			$creds['user_password'] =  $headers["password"];
			$creds['remember'] = false;
			$user = wp_signon( $creds, false );  // Verify the user.
			
			// TODO: Consider sending custom message because the default error
			// message reveals if the username or password are correct.
			if ( is_wp_error($user) ) {
				echo $user->get_error_message();
				return $user;
			}
			
			wp_set_current_user( $user->ID, $user->user_login );
			
			// A subscriber has 'read' access so a very basic user account can be used.
			if ( ! current_user_can( $this->required_capability ) ) {
				return new WP_Error( 'rest_forbidden', 'You do not have permissions to view this data.', array( 'status' => 401 ) );
			}
			
			// TODO: Run real code here.
			return 'ok';
		}
		else {
			return new WP_Error( 'invalid-method', 'You must specify a valid username and password.', array( 'status' => 400 /* Bad Request */ ) );
		}
	}
}
 
$lps_rest_server = new List_Product_Stock_Rest_Server();




#Cron code

$request_url = 'http://localhost/wp-json/list_product_stock/v1/list-product-stock/';
$credentials = array();
$credentials = array( 'username: basic_user', 'password: password_for_the_user' );
$curl_handle = curl_init( );
curl_setopt( $curl_handle, CURLOPT_URL, $request_url );
curl_setopt( $curl_handle, CURLOPT_CONNECTTIMEOUT, 0 );
curl_setopt( $curl_handle, CURLOPT_TIMEOUT, 15 );
curl_setopt( $curl_handle, CURLOPT_HTTPHEADER, $credentials  );
curl_setopt( $curl_handle, CURLOPT_RETURNTRANSFER, TRUE );
$JsonResponse = curl_exec( $curl_handle );
$http_code = curl_getinfo( $curl_handle );
if ( 200 == $http_code[ 'http_code' ] ) {
	echo $JsonResponse, "\n";
}
else {
	echo 'ERROR: <pre>', var_export( $JsonResponse, true ), "</pre>\n";
}