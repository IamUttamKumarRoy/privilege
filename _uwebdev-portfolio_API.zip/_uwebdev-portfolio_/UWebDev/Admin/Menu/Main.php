<?php 

if(!defined('WPINC')) {
    die();
}

if( !class_exists( 'UWebDev_Admin_Menu_Main' ) ) {
	class UWebDev_Admin_Menu_Main {
	    private static $instance, $slug = array(), $page_hook;
	    private $TD;
	    private $role;

	    public static function getInstance() {
	        if(self::$instance==null){
	            self::$instance = new self;
	            self::$slug = array();
	            self::$instance->TD = RPS_Result_Management::TD;
	            self::$instance->actions();
	        }
	        
	        return self::$instance;
	    }
	    
	    private function __construct() {
	        ;
	    }

	    private function actions() { 

	        add_action('admin_menu',array($this,'mainMenu')); 
	    }

	    function mainMenu()
		{
			add_menu_page('UWebDev Page', 'UWebDev Page', 'manage_options', 'uwebdev_page', array($this,'displayDepartment') );
			add_submenu_page('uwebdev_page','My Page Title', 'My Menu Title', 'manage_options', 'uwebdev_page');
			

			/*add_menu_page('My Page Title', 'My Menu Title', 'manage_options', 'my-menu', 'my_menu_output' );
			add_submenu_page('my-menu', 'Submenu Page Title', 'Whatever You Want', 'manage_options', 'my-menu' );*/
			add_submenu_page( 'uwebdev_page', 'Submenu Page Title2', 'Submenu Menu Title2', 'manage_options', 'my_menu2', array($this,'my_menu2') );

		}
 
		function displayDepartment()
		{
			echo "displayDepartment";
		}

		function my_menu2()
		{
			echo "my_menu2";
		} 
	}
}
