<?php
if( !defined( 'WPINC' ) ) {
	die();
}

class UWebDev_API extends WP_REST_Controller {

    public function __construct() {
        $this->TD =  UWebDev_Portfolio::TD;
    }



    /**
     * Register the routes for the objects of the controller.
     */
    public function register_routes() {

        $namespace = 'uwebdev_result/v1';
        $base = 'route';

        //List of post 
        register_rest_route($namespace, '/' . $base . '/posts_list' , array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'posts_list'),
                'args' => array(),
            ),
        ));  

        register_rest_route($namespace, '/' . $base . '/list_results' , array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'list_results'),
                'args' => $this->get_result_search_params(),
            )
        )); 
    }

    public function posts_list( WP_REST_Request $request ){

        $creds = array();
        $headers = getallheaders();
        // Get username and password from the submitted headers.
        if ( array_key_exists( 'username', $headers ) && array_key_exists( 'password', $headers ) ) {
            $creds['user_login'] = $headers["username"];
            $creds['user_password'] =  $headers["password"];
            $creds['remember'] = false;
            $user = wp_signon( $creds, false );  // Verify the user.
            
            // TODO: Consider sending custom message because the default error
            // message reveals if the username or password are correct.
            if ( is_wp_error($user) ) {
                echo $user->get_error_message();
                return $user;
            }
            //return $user->ID."_".$user->user_login."_".$this->required_capability;
            wp_set_current_user( $user->ID, $user->user_login );
            
            // A subscriber has 'read' access so a very basic user account can be used.
            if ( ! current_user_can( 'read' ) ) {
                return new WP_Error( 'rest_forbidden', 'You do not have permissions to view this data.', array( 'status' => 401 ) );
            }
            
            // TODO: Run real code here.
            return 'ok';
        }
        else {
            return new WP_Error( 'invalid-method', 'You must specify a valid username and password.', array( 'status' => 400 /* Bad Request */ ) );
        }
    }

    public function list_results( $request ) {
        $params = $request->get_params();
        $this->exam_id = isset($params['exam_id']) ? $params['exam_id'] : null;
        $this->department_id = isset($params['department_id']) ? $params['department_id'] : null;
        $this->batch_id = isset( $params['batch_id'] ) ? $params['batch_id'] : null;
        $this->semester_id = isset( $params['semester_id'] ) ? $params['semester_id'] : null ;

         if ( !current_user_can('manage_options') )
         {
            $error = 'User does not has privillege to access';
            return new WP_Error('error-getting-data', $error, array('status' => 400));
         }
        $student_list = array('Uttam','Roy');
        /*if( UWebDev_Helper_Function::is_numeric( $this->exam_id ) && UWebDev_Helper_Function::is_numeric( $this->department_id )
            && UWebDev_Helper_Function::is_numeric( $this->batch_id ) )
        {
            $student_list = $this->result->getStudentIDsBySearchForm( $this->exam_id, $this->department_id, $this->batch_id, $this->semester_id );

        } else {
            //invalid request
            return new WP_Error('invalid-request', __('Invalid Request.', $this->TD), array('status' => 400));
        }*/

        if ( !is_wp_error($student_list) ) {
            return new WP_REST_Response($student_list, 200);

        } else {
            //print error message and return
            return new WP_Error('error-getting-data', $student_list->get_error_message(), array('status' => 400));
        }


    }
 
    public function send_response( $data ) {
        $response = rest_ensure_response( $data );

        $response->header("Access-Control-Allow-Origin", get_http_origin());
        $response->header("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE");
        $response->header("Access-Control-Allow-Credentials", true);

        $response->set_status( 200 );

        return $response;
    }

    public function get_student_search_params() {
        return array(
            'department_id' => array(
                'description' => 'Department ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'batch_id' => array(
                'description' => 'Batch ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'semester_id' => array(
                'description' => 'Semester ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),
            'per_page' => array(
                'description' => 'Maximum number of items to be returned in result set.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),
            'page' => array(
                'description' => 'Current page of the collection.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),

        );
    }

    public function get_show_result_params() {
        return array(
            'exam_record_id' => array(
                'description' => 'Exam Record ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'student_id' => array(
                'description' => 'Student ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'per_page' => array(
                'description' => 'Maximum number of items to be returned in result set.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),
            'page' => array(
                'description' => 'Current page of the collection.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),

        );
    }

    public function get_result_search_params() {
        return array(
            'exam_id' => array(
                'description' => 'Exam ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'department_id' => array(
                'description' => 'Department ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'batch_id' => array(
                'description' => 'Batch ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
                'required' => true,
            ),
            'semester_id' => array(
                'description' => 'Semester ID.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),
            'per_page' => array(
                'description' => 'Maximum number of items to be returned in result set.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),
            'page' => array(
                'description' => 'Current page of the collection.',
                'type' => 'integer',
                'default' => null,
                'sanitize_callback' => 'absint',
            ),

        );
    }
 

    public function get_public_item_schema() {
        return array();
    }
}