<?php
/*
Plugin Name: UWebDev Portfolio Management
Plugin URI: https://www.uwebdev.com/wp/plugin/uwebdev-portfolio
Description: UWebDev Portfolio Management
Text Domain: uwebdev-portfolio
Version: 1.0.0
Author: Uttam Kumar Roy
Author URI: https://www.uttamkumarroy.com/
*/

if( !defined( 'WPINC' ) ) {
    die();
}

//include "admin_menu_submenu.php";
if( !class_exists( 'UWebDev_Portfolio' ) ) {

	final class UWebDev_Portfolio 
	{
		private static $instance;
        private $dir, $url; 

        const VER = 2.7;

		//do not change below constant
        const DS = '/';
        const PLUGIN_SLUG = 'uwebdev_portfolio';
        const TD = 'uwebdev-portfolio';
        const TABLE_PREFIX = 'uwebdev_';
        const FILE = __FILE__;

		public static function getInstance() {

            if (self::$instance == null) {
                self::$instance = new self;
                self::$instance->dir = dirname(__FILE__);
                self::$instance->autoload();
                self::$instance->actions();
            } else {
                throw new BadFunctionCallException(sprintf('Plugin %s already instantiated', __CLASS__));
            }
            return self::$instance;
        }

        public function autoload() {
            require_once ( $this->dir . self::DS . "UWebDev" . self::DS . "Autoloader" . self::DS . "LoaderClass.php" );

            // Add the Autoloader
            $loader = new UWebDev_Autoloader_LoaderClass( "UWebDev", dirname( __FILE__ ) );
            $loader->register( );


        }

        /**
         * Return prefix for plugin database tables
         * @return string
         */
        public static function getTablePrefix() {
            global $wpdb;
            return $wpdb->prefix . self::TABLE_PREFIX;
        }

         private function check_for_updates() {
         	$db_class = UWebDev_InstallDb::getInstance();
	        $db_class->createDB();
         }
        /**
         * call all actions/filters here
         */
        private function actions() {
        	
	        add_action('admin_menu', array($this,'uwebdev_plugin_settings'));

            //this is for api access
            add_action( 'rest_api_init', array( $this, 'api' ) );

	        if ( is_admin() ) { 
	            //check for updates
                UWebDev_Admin_Menu_Main::getInstance();
	            $this->check_for_updates();
            }  
        }

        public function api() {
            //check api enabled or not
            /*$options = get_option( UWebDev_Portfolio::PLUGIN_SLUG . '_api', array() );
            if ( isset($options['enable_api']) && $options['enable_api'] == 'on' ) {
                if ( class_exists('WP_REST_Controller') ) {
                    $api = new RPS_API();
                    $api->register_routes();
                }
            }*/

            $api = new UWebDev_API();
            $api->register_routes();
        }

		function uwebdev_plugin_settings() {
		    $page_title = 'UWebDev Basic ';
		    $menu_title = 'UWebDev Basic ';
		    $capability = 'edit_posts';
		    $menu_slug  = 'uwebdev_basic_plugin';
		    $function   = 'uwebdev_basic_plugin_display';
		    $icon_url   = '';
		    $position   = 25;

		    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,$function), $icon_url, $position );
		}
		function uwebdev_basic_plugin_display()
		{
			$db_class = UWebDev_InstallDb::getInstance();
			//$db_class->createDB();
	            
	        $admin_class = UWebDev_Admin_AdminPanel::getInstance();
			//$admin_class->getMenu();

			?>
			<div class="wrap">        
			<h2><i id="icon-edit" class="dashicons dashicons-admin-generic" style="line-height: 1.5em;"></i>&nbsp;Settings</h2>
			
				
		    </div>
			<?php 
		}

	}

	UWebDev_Portfolio::getInstance();
}
