<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListCategory extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'parent_id',
        'user_id',
        'category_name', 
        'description', 
        'ordering', 
        'status'
    ];
 
    /**
     * Get the user that owns the list item progress
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    
    /**
     * Get the listings for the Listing Category.
     */
    public function listings()
    {
        return $this->hasMany(Listing::class);
    }
}
