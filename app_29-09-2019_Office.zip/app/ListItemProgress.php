<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListItemProgress extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'progress_status',
        'progress_note'
    ];

	/**
     * Get the user that owns the list item progress
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the list that owns the list item
     */
    public function list_item()
    {
        return $this->belongsTo(ListItem::class);
    }

    
}
