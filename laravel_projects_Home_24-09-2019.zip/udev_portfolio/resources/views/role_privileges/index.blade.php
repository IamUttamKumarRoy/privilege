@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
          Section Type
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            
            
            <div class="table-responsive">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <td>ID</td>
                        <td>Section Type</td>
                        <td>Section Name</td>
                        <td>Head Title</td>
                        <td>Description</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td> 
                        <td>&nbsp;</td>
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $inc = 1;
                      $odd_even = "even";
                      @endphp
  
                      @if(!empty($priv_category_list))
                        @foreach($priv_category_list as $priv_category)                          
                          @if($inc%2 == 0)                              
                            @php
                            $odd_even = "even"  
                            @endphp                                                    
                          @else 
                            @php
                            $odd_even = "odd"  
                            @endphp
                          @endif
                        <tr class="{{ $odd_even }}">
                            <td>{{ $priv_category}}</td> 
                            <td>
                              <a href="#" class="btn btn-primary">Show</a>
                            </td>
                            <td>
                              <a href="#" class="btn btn-primary">Edit</a>
                            </td>  
                            <td>  
                                <form action="#" method="post">
                                  @csrf
                                  @method('DELETE')
                                  <button class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        @php
                        $inc += 1; 
                        @endphp
                        @endforeach
                      @endif  
                    </tbody>
                </table>
            </div>
            <!-- /.table-responsive -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
  </div>
</div>
@endsection