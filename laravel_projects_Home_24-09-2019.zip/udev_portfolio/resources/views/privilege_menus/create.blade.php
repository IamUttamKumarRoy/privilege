@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Privilege Menu Category
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('privilege_menus.store') }}">
                    <div class="form-group">
                        @csrf
                        <label>Menu Category</label>
                        <select class="form-control" name="privilege_menu_category_id">
                        @if(!empty($privilege_menu_category_list) )
                            @foreach($privilege_menu_category_list as $category_id=> $category_name)
                                <option value="{{ $category_id }}">{{ $category_name }}</option>
                            @endforeach
                        @endif
                        </select>
                    </div>
                    <div class="form-group">                        
                        <label for="name">Privilege Name:</label>
                        <input type="text" class="form-control" name="privilege_name"/>
                    </div> 

                    <div class="form-group">
                        <label for="name">URI:</label>
                        <input type="text" class="form-control" name="uri"/>
                    </div> 
                    <div class="form-group">
                        <label for="name">Methods:</label>
                        <input type="text" class="form-control" name="methods"/>
                    </div>  
                    <div class="form-group">
                        <label for="name">Action:</label>
                        <input type="text" class="form-control" name="action"/>
                    </div> 
                    <div class="form-group">                        
                        <label for="name">Controller:</label>
                        <input type="text" class="form-control" name="controller"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection