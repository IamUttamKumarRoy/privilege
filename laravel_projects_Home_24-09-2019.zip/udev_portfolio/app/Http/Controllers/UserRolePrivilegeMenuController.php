<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserRole;
use App\PrivilegeMenuCategory;
use App\PrivilegeMenu;


class UserRolePrivilegeMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /*$data = [
            'role_id' => 1, 
            'privilege_menu_id' => 1 
        ];
        $role_privilege = UserRolePrivilegeMenu::create($data);        
        */

        /* // -- OK
        $privilege_menu = new PrivilegeMenu;
        $privilege_menu->privilege_name = 'Book View';
        $privilege_menu->uri = 'books';
        $privilege_menu->action = 'books';
        $privilege_menu->controller = 'BookController';

        $privilege_menu->save();

        $user_role = UserRole::find([1,2]);
        $privilege_menu->user_roles()->attach($user_role);
        */

        /*$user_role = new UserRole;
        $user_role->role_name = 'Subscriber'; 

        $user_role->save();

        $privilege_menu = PrivilegeMenu::find([1,2]);
        $user_role->privilege_menus()->attach($privilege_menu);
        */
        $privilege_menu_category = PrivilegeMenuCategory::where('status', 1)->pluck('category_name', 'id'); 
        

        $priv_category_list = array();
        if( !empty($privilege_menu_category ) ) {
            foreach ($privilege_menu_category as $category_id => $category_name ) {
               $priv_category_list[$category_id]  = $category_name;
            }
        }
        //pr($priv_category_list);
        return view('role_privileges.index', compact('priv_category_list'));
        //return 'Success';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $priv_category_list = array();
        $privilege_menu_arr = array();

        $privilege_menus = PrivilegeMenu::all(); 

        $privilege_menu_category = PrivilegeMenuCategory::where('status', 1)->pluck('category_name', 'id'); 
        
        if( !empty($privilege_menu_category ) ) {
            foreach ($privilege_menu_category as $category_id => $category_name ) {
               $priv_category_list[$category_id]  = $category_name;
            }
        }

        if( !empty($privilege_menus ) ) {
            foreach ($privilege_menus as $key => $privilege_menu ) {
               $temp_arr = array();
               $temp_arr['id']             = $privilege_menu->id;
               $temp_arr['privilege_name'] = $privilege_menu->privilege_name;
               $temp_arr['uri']            = $privilege_menu->uri;
               $temp_arr['methods']        = $privilege_menu->methods;
               $temp_arr['action']         = $privilege_menu->action;
               $temp_arr['controller']     = $privilege_menu->controller;
               $privilege_menu_arr[$privilege_menu->privilege_menu_category_id][]  = $temp_arr;
            }
        }
        //pr($privilege_menu_arr);
        return view('role_privileges.create_org', compact('priv_category_list','privilege_menu_arr'));
        //return view('role_privileges.create', compact('priv_category_list','privilege_menu_arr'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
             'privilege' => 'required' 
         ]);

        $privilege_ids  = array();
        if( !empty($validatedData['privilege']) )
        {
            foreach ($validatedData['privilege'] as $key => $privilege_id) {
                $privilege_ids[$privilege_id] = $privilege_id;
            }
        }
        pr($request->all());

        $user_role = UserRole::findOrFail(2);
        //$privilege_menu = PrivilegeMenu::find([3, 4]);
        $user_role->privilege_menus()->attach($privilege_ids);

        /*$user_role = UserRole::findOrFail(2);
        $privilege_menu = PrivilegeMenu::find([3, 4]);
        $user_role->privilege_menus()->attach($privilege_menu);*/

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function show(UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function edit(UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserRolePrivilegeMenu  $userRolePrivilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserRolePrivilegeMenu $userRolePrivilegeMenu)
    {
        //
    }
}
