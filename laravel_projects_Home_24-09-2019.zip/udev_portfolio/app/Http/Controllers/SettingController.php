<?php

namespace App\Http\Controllers;

use App\Setting;
use App\SettingValue;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $settings = Setting::all();
        return view('settings.index', compact('settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('settings.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'variable_name' => 'required', 
            'variable_value' => 'required',            
            'input_type_id' => 'required' 
        ]);
        
        $submitted_data['status']  = 1;
       // dd($submitted_data);
                
        $setting = Setting::create($submitted_data);
        
        $setting_val = new SettingValue;;
        $setting_val->variable_value = "Hi ItSolutionStuff.com";
        $post = $setting->setting_values()->save($setting_val);

        if($setting){
            return redirect('/settings')->with('success', 'Setting is successfully saved');
        }
        else {
            return redirect('/settings/create')->with('success', 'Setting  save unsuccessfull');
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function show(Setting $setting)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function edit(Setting $setting)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Setting $setting)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function destroy(Setting $setting)
    {
        //
    }
}
