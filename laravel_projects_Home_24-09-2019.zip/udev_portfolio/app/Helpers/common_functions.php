<?php

function pr( $to_be_dumped_var  = null )
{
	echo "<pre>";
		print_r($to_be_dumped_var);
	echo "</pre>";
}