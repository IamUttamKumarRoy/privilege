<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InputType extends Model
{
    //
}
