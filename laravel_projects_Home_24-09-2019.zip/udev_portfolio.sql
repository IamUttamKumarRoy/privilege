-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2019 at 07:58 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `udev_portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(10) UNSIGNED NOT NULL,
  `book_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isbn_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_product`
--

CREATE TABLE `category_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `input_types`
--

CREATE TABLE `input_types` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `input_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(64, '2019_06_11_095054_create_user_role_privilege_menus_table', 1),
(116, '2014_10_12_000000_create_users_table', 2),
(117, '2014_10_12_100000_create_password_resets_table', 2),
(118, '2019_03_27_175920_create_books_table', 2),
(119, '2019_03_30_215848_create_posts_table', 2),
(120, '2019_03_30_220857_create_comments_table', 2),
(121, '2019_03_30_224858_create_phones_table', 2),
(122, '2019_03_31_060012_create_portfolio_sections_table', 2),
(123, '2019_03_31_060404_create_section_types_table', 2),
(124, '2019_04_06_040940_create_settings_table', 2),
(125, '2019_06_04_150201_create_user_roles_table', 2),
(126, '2019_06_04_164426_create_privilege_menu_categories_table', 2),
(127, '2019_06_04_174153_create_privilege_menus_table', 2),
(128, '2019_06_12_183022_create_categories_table', 2),
(129, '2019_06_12_183256_create_products_table', 2),
(130, '2019_06_12_185832_create_category_product_table', 2),
(131, '2019_06_13_055516_create_user_role_privilege_menu_table', 2),
(132, '2019_06_13_064201_create_user_privilege_menu_table', 2),
(133, '2019_06_14_171720_create_input_types_table', 2),
(134, '2019_06_14_175617_create_setting_values_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE `phones` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_sections`
--

CREATE TABLE `portfolio_sections` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `section_type_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `section_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `head_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `ordering` tinyint(3) UNSIGNED DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `terminal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privilege_menus`
--

CREATE TABLE `privilege_menus` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `privilege_menu_category_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `privilege_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `methods` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` smallint(5) UNSIGNED DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `privilege_menus`
--

INSERT INTO `privilege_menus` (`id`, `privilege_menu_category_id`, `privilege_name`, `uri`, `methods`, `action`, `controller`, `ordering`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 'Book Listing', 'books', 'GET', 'books.index', 'BookController', 1, 1, '2019-07-05 00:13:25', '2019-07-05 11:37:21'),
(2, 1, 'Book Create', 'books/create', 'get', 'books.create', 'BookController', 1, 1, '2019-07-05 00:18:20', '2019-07-05 00:18:20'),
(3, 7, 'fuga', 'ipsa', 'illo', 'suscipit', 'harum', 29, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(4, 5, 'et', 'error', 'laborum', 'ut', 'laborum', 2, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(5, 11, 'et', 'aut', 'officiis', 'optio', 'delectus', 67, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(6, 3, 'perferendis', 'rerum', 'quidem', 'quas', 'quos', 32, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(7, 15, 'porro', 'sit', 'corrupti', 'praesentium', 'consectetur', 50, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(8, 6, 'et', 'voluptatem', 'delectus', 'dolores', 'corrupti', 25, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(9, 1, 'ut', 'eum', 'ut', 'nemo', 'quisquam', 60, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(10, 7, 'maxime', 'dolor', 'excepturi', 'amet', 'excepturi', 17, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(11, 13, 'voluptatibus', 'eos', 'ducimus', 'cum', 'consectetur', 77, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(12, 11, 'numquam', 'rem', 'est', 'amet', 'odit', 44, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(13, 2, 'dolores', 'ducimus', 'rerum', 'labore', 'qui', 80, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(14, 8, 'perspiciatis', 'sapiente', 'enim', 'est', 'illum', 91, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(15, 14, 'qui', 'accusamus', 'et', 'est', 'dolor', 73, 1, '2019-07-05 12:40:04', '2019-07-05 12:40:04'),
(16, 7, 'quaerat', 'beatae', 'libero', 'dolorum', 'animi', 23, 1, '2019-07-05 12:40:05', '2019-07-05 12:40:05'),
(17, 13, 'deserunt', 'tempore', 'ut', 'quo', 'dolores', 99, 1, '2019-07-05 12:40:05', '2019-07-05 12:40:05');

-- --------------------------------------------------------

--
-- Table structure for table `privilege_menu_categories`
--

CREATE TABLE `privilege_menu_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `precedence` tinyint(3) UNSIGNED DEFAULT NULL,
  `ordering` tinyint(3) UNSIGNED DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `privilege_menu_categories`
--

INSERT INTO `privilege_menu_categories` (`id`, `category_name`, `precedence`, `ordering`, `status`, `created_at`, `updated_at`) VALUES
(1, 'voluptatem', 57, 58, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(2, 'soluta', 40, 68, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(3, 'laboriosam', 87, 34, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(4, 'mollitia', 1, 15, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(5, 'illum', 40, 34, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(6, 'perferendis', 2, 55, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(7, 'laboriosam', 6, 60, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(8, 'voluptatem', 61, 19, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(9, 'natus', 36, 100, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(10, 'aut', 47, 76, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(11, 'et', 86, 84, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(12, 'pariatur', 69, 87, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(13, 'in', 99, 45, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(14, 'quia', 74, 96, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16'),
(15, 'ea', 78, 77, 1, '2019-07-05 12:25:16', '2019-07-05 12:25:16');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `section_types`
--

CREATE TABLE `section_types` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `section_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` tinyint(3) UNSIGNED DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `section_types`
--

INSERT INTO `section_types` (`id`, `section_type`, `ordering`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Introduction', NULL, NULL, '2019-07-12 09:12:48', '2019-07-12 09:12:48');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `input_type_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `variable_group` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variable_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variable_display_title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variable_value` text COLLATE utf8mb4_unicode_ci,
  `is_singular` tinyint(3) UNSIGNED DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `terminal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `input_type_id`, `variable_group`, `variable_name`, `variable_display_title`, `variable_value`, `is_singular`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`, `terminal`) VALUES
(1, 1, NULL, 'sitename', NULL, 'UKR.com', NULL, 1, NULL, '2019-06-14 12:27:37', NULL, '2019-06-14 12:27:37', NULL),
(2, 1, NULL, 'sitename', NULL, 'UKR', NULL, 1, NULL, '2019-06-14 12:43:45', NULL, '2019-06-14 12:43:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setting_values`
--

CREATE TABLE `setting_values` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `setting_id` smallint(5) UNSIGNED DEFAULT NULL,
  `variable_value` text COLLATE utf8mb4_unicode_ci,
  `ordering` smallint(5) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `setting_values`
--

INSERT INTO `setting_values` (`id`, `setting_id`, `variable_value`, `ordering`, `created_at`, `updated_at`) VALUES
(1, 2, 'Hi ItSolutionStuff.com', NULL, '2019-06-14 12:43:46', '2019-06-14 12:43:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_privilege_menu`
--

CREATE TABLE `user_privilege_menu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `precedence` tinyint(3) UNSIGNED DEFAULT NULL,
  `ordering` tinyint(3) UNSIGNED DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `role_name`, `precedence`, `ordering`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 1, 1, 1, '2019-07-18 10:31:50', '2019-07-18 10:31:50'),
(2, 'Viewer', 2, 2, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_role_privilege_menu`
--

CREATE TABLE `user_role_privilege_menu` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `user_role_id` smallint(5) UNSIGNED NOT NULL,
  `privilege_menu_id` smallint(5) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_role_privilege_menu`
--

INSERT INTO `user_role_privilege_menu` (`id`, `user_role_id`, `privilege_menu_id`, `created_at`, `updated_at`) VALUES
(1, 2, 3, NULL, NULL),
(2, 2, 4, NULL, NULL),
(3, 2, 1, NULL, NULL),
(4, 2, 13, NULL, NULL),
(5, 2, 2, NULL, NULL),
(6, 2, 9, NULL, NULL),
(7, 2, 3, NULL, NULL),
(8, 2, 10, NULL, NULL),
(9, 2, 16, NULL, NULL),
(10, 2, 4, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_product`
--
ALTER TABLE `category_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_post_id_foreign` (`post_id`);

--
-- Indexes for table `input_types`
--
ALTER TABLE `input_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `phones`
--
ALTER TABLE `phones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `phones_user_id_foreign` (`user_id`);

--
-- Indexes for table `portfolio_sections`
--
ALTER TABLE `portfolio_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privilege_menus`
--
ALTER TABLE `privilege_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privilege_menu_categories`
--
ALTER TABLE `privilege_menu_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section_types`
--
ALTER TABLE `section_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_values`
--
ALTER TABLE `setting_values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_privilege_menu`
--
ALTER TABLE `user_privilege_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role_privilege_menu`
--
ALTER TABLE `user_role_privilege_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_product`
--
ALTER TABLE `category_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `input_types`
--
ALTER TABLE `input_types`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `phones`
--
ALTER TABLE `phones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `portfolio_sections`
--
ALTER TABLE `portfolio_sections`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `privilege_menus`
--
ALTER TABLE `privilege_menus`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `privilege_menu_categories`
--
ALTER TABLE `privilege_menu_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `section_types`
--
ALTER TABLE `section_types`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting_values`
--
ALTER TABLE `setting_values`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_privilege_menu`
--
ALTER TABLE `user_privilege_menu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_role_privilege_menu`
--
ALTER TABLE `user_role_privilege_menu`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `phones`
--
ALTER TABLE `phones`
  ADD CONSTRAINT `phones_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
