<h1>My Awesome Settings Page</h1>
<p><?php echo isset($_GET['tab']) ? $_GET['tab'] :'homepage';?></p>
<form method="POST">
    <label for="awesome_text">Awesome Text</label>
    <input type="text" name="awesome_text" id="awesome_text" value="<?php echo $value; ?>">
    <input type="submit" value="Save" class="button button-primary button-large">
</form>