<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Section Type
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('role_privileges.store')); ?>">
                    <?php echo csrf_field(); ?>  

                    <?php if(!empty($privilege_menu_arr)): ?>
                        <?php $__currentLoopData = $privilege_menu_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_id=>$privilege_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <div class="row"> 
                                <div class="col-md-12">                                
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="Category<?php echo e($cat_id); ?>">
                                            <input type="checkbox" class="form-check-input parentPr" id="privilegeParent<?php echo e($cat_id); ?>" name="privilegeParent[]" value="<?php echo e($cat_id); ?>"> <?php echo e((!empty($priv_category_list[$cat_id])) ? ucfirst($priv_category_list[$cat_id]):''); ?>

                                        </label>
                                    </div>                                
                                    <div class="children">
                                    <?php if(!empty($privilege_menu)): ?>
                                        <?php $__currentLoopData = $privilege_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_id=>$privilege): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div class="form-check-inline">
                                          <label class="form-check-label" for="check<?php echo e($privilege['id']); ?>">
                                            <input type="checkbox" class="form-check-input" id="privilege<?php echo e($privilege['id']); ?>" name="privilege[]" value="<?php echo e($privilege['id']); ?>"><?php echo e($privilege['privilege_name']); ?>

                                          </label>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                                          
                                    </div>
                                </div>   
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?> 
                    
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<script type="text/javascript">

$(document).ready(function(){

    $(document).on("click", ".parentPr", function(event) {   
        var check_status;
        if( $(this).is(':checked') )
            check_status = true;  // checked
        else
            check_status = false;// unchecked

        $(this).parent().next().find("input[type='checkbox']").each(function() {             
            $(this).prop('checked',check_status);            
        });
    });
    
}); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>