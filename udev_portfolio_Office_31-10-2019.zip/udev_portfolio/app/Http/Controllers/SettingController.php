<?php

namespace App\Http\Controllers;

use App\CommonClass;
use App\CommonClass\SettingOption;
use App\Setting;
use App\SettingValue;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    protected $website_settings = array();

    public function __construct(SettingOption $setting_option) {
        $this->setting_option = $setting_option;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $settings = Setting::all();
        return view('settings.index', compact('settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('settings.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $submitted_data = $request->all();
        $validated_data = $request->validate([
            'variable_name' => 'required', 
            'variable_value' => 'required',            
            'input_type_id' => 'required' 
        ]);
        
        $submitted_data['status']  = 1;
       // dd($submitted_data);
                
        $setting = Setting::create($submitted_data);
        
        $setting_val = new SettingValue;;
        $setting_val->variable_value = "Hi ItSolutionStuff.com";
        $post = $setting->setting_values()->save($setting_val);

        if($setting){
            return redirect('/settings')->with('success', 'Setting is successfully saved');
        }
        else {
            return redirect('/settings/create')->with('success', 'Setting  save unsuccessfull');
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function show(Setting $setting)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function edit(Setting $setting)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Setting $setting)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function destroy(Setting $setting)
    {
        //
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function siteSetting()
    {
        
        $website_settings = array(
            array(
                'title'    => 'group',
                'desc'     => 'Settings group', 
                'id'       => 'variable_group',                
                'default'  => 'basic_setting',
                'type'     => 'hidden', 
            ),
            array(
                'title'    => 'Username',
                'desc'     => 'Username to access private data', 
                'id'       => 'username',                
                'default'  => '',
                'type'     => 'text',
                'desc_tip' => true,
                'validation' => 'required|maxlength:5',
            ),
            array(
                'title'    => 'Password',
                'desc'     => 'Password to access private data', 
                'id'       => 'password',                
                'default'  => '',
                'type'     => 'password',
                'desc_tip' => true,
                'validation' => 'required|maxlength:10',
            ),
            array(
                'title'    => 'Name',
                'desc'     => 'Name of the user', 
                'id'       => 'name',                
                'default'  => '',
                'type'     => 'text',
                'desc_tip' => true,
                'validation' => 'required|maxlength:15',
            ),
            array(
                'title'    => 'Age',
                'desc'     => 'Name of the user', 
                'id'       => 'user_age',                
                'default'  => '',
                'type'     => 'number',
                'desc_tip' => true,
                'validation' => 'required|max:10',
            ),
            array(
                'title'         => 'Logged In',
                'desc'          => 'Allow user to logged in',
                'id'            => 'is_logged_in',                
                'default'       => 'yes',
                'type'          => 'checkbox',
                'checkboxgroup' => 'start',
                'autoload'      => false,
                'validation' => 'required|max:255',
            ),
            
        ); 

        $this->website_settings  = $website_settings;
        $this->setting_option->showForm($website_settings);


        
        //return view('settings.site_setting',compact('website_settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveSiteSetting(Request $request)
    {        
        $validation_arr = array();
        if( !empty($this->website_settings) )
        {
            foreach ($this->website_settings as $arr_key => $option_value) 
            {
                if( !empty($option_value['validation'])) {
                   $validation_arr[$option_value['id']] = $option_value['validation']; 
               }                
            }
        }
        //pr($this->website_settings);
        //pr($validation_arr);

        $validatedData = $request->validate($validation_arr);

        
        
         
        $this->setting_option->saveFormInput($request);
        return redirect('/settings')->with('success', 'Setting  save unsuccessfull');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function basicSetting()
    {
        
        $website_settings = array(
            array(
                'title'    => 'group',
                'desc'     => 'Settings group', 
                'id'       => 'variable_group',                
                'default'  => 'site_setting',
                'type'     => 'hidden', 
            ),
            array(
                'title'    => 'Site Name',
                'desc'     => 'Site name to access private data', 
                'id'       => 'site_name',                
                'default'  => '',
                'type'     => 'text',
                'desc_tip' => true,
                'validation' => 'required|maxlength:5',
            ),
            array(
                'title'    => 'Site Address',
                'desc'     => 'site_address', 
                'id'       => 'site_address',                
                'default'  => '',
                'type'     => 'text',
                'desc_tip' => true,
                'validation' => 'required|maxlength:10',
            ), 
            
        ); 

        $this->website_settings  = $website_settings;
        $this->setting_option->showForm($website_settings);
    }
}
