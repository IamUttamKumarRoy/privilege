<?php

namespace App\CommonClass;

use Illuminate\Http\Request; 
use App\Setting;

class SettingOption
{
	public function __construct() 
	{ 
	}

	public function showForm( $website_settings = null ) 
	{	   
	   echo view('settings.site_setting',compact('website_settings'));
	}
  	
  	public function saveFormInput(Request $request) 
	{
	   dd($request->all());

	   if( !empty($request->all()) )
	   {
	      $variable_group = '';
	   	  // Get setting group if any with name  
	   	  foreach ($request->all() as $field_name => $field_value) 
	   	  {
	   	  	if( $field_name == 'variable_group' ) {
	   	  		$variable_group = $field_value;
	   	  		break;
	   	  	}
	   	  }

	   	  foreach ($request->all() as $field_name => $field_value) 
	   	  {
	   	  	if( $field_name == "_token" || $field_name == "variable_group")
	   	  		continue;
			$setting_option = Setting::firstOrNew(array('variable_name' => $field_name));
			$setting_option->variable_group = $variable_group;
			$setting_option->variable_value = $field_value;
			$setting_option->save();
	   	  }
	   }
	   
	}

}
?>