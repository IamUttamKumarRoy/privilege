<!DOCTYPE html>
<html>
<head>
    <title>L-5.8 CRUD</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>

	<div class="container">

	    @yield('content')

	</div>

</body>
</html>