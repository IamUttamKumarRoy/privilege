<?php
add_action('admin_menu', 'udev_plugin_settings');
function udev_plugin_settings() {
    $page_title = 'Udev Plugin Settings';
    $menu_title = 'Udev Plugin Setting';
    $capability = 'edit_posts';
    $menu_slug = 'udev_plugin_setting';
    $function = 'udev_plugin_settings_display';
    $icon_url = '';
    $position = 25;

    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
}

function udev_plugin_settings_display()
{
	// Form Submission handle
	if( isset( $_POST['general_form'] ) ) {
        

        if ( wp_verify_nonce( $_POST['udev_nonce_general_form_action'], 'udev_nonce_general_form' ) ) 
	    { 
		 	update_option( 'udev_website_name', $_POST['udev_settings[udev_website_name]'] );   
		 	update_option( 'udev_contact_number', $_POST['udev_settings[udev_contact_number]'] );

		 	echo "<pre>";
		 		print_r($_POST['udev_settings']);
		 	echo "</pre>";
		 	die;
		}  
		echo "<pre>::";
			print_r($_POST['udev_settings']);
		echo "</pre>";
		die;    
    }

    

	$website_name   = get_option('udev_website_name', 'uttam.com');
	$contact_number = get_option('udev_contact_number', '01737137704');
	?>
	<div class="wrap">        
		<h2><i id="icon-edit" class="dashicons dashicons-admin-generic" style="line-height: 1.5em;"></i>&nbsp;Settings</h2>
		<br class="clear">
		<h2 class="nav-tab-wrapper">
			<a href="#udev-general-tab" class="nav-tab nav-tab-active" id="udev-general-tab-tab">General Settings</a>
			<a href="#udev-shortcode-tab" class="nav-tab" id="udev-shortcode-tab-tab">Shortcode</a>
			<a href="#udev-api-tab" class="nav-tab" id="udev-api-tab-tab">API</a>
			<a href="#udev-license-tab" class="nav-tab" id="udev-license-tab-tab">License</a>
		</h2>
		<div class="metabox-holder">
		   <div id="udev-general-tab" class="group" style="display: block;">
		   				
		   		<form method="POST">
		   			<?php wp_nonce_field('udev_nonce_general_form_action','udev_nonce_general_form'); ?>
		   			<table class="form-table">
	                    <tr>
	                        <th><?php _e( 'Website Name:', 'udev' ) ?></th>
	                        <td> 
				    			<input type="text" class="regular-text" id="udev_settings_udev_website_name" name="udev_settings[udev_website_name]" value="<?php echo $website_name; ?>">				     										
							</td>
						</tr>
						<tr>
							<th><?php _e( 'Contact Number:', 'udev' ) ?></th>
	                        <td>  
						    	<input type="text" class="regular-text" id="udev_settings_udev_contact_number" name="udev_settings[udev_contact_number]" value="<?php echo $contact_number; ?>">				
							</td>
						</tr>
						<tr>
							<th></th>
	                        <td> 
	                        	<input type="submit" name="general_form" value="Save" class="button button-primary button-large">									
							</td>
						</tr>
				</form>					
		   </div>
		   <div id="udev-shortcode-tab" class="group" style="display: none;">
		   		Shortcode Student
		   </div>
		   <div id="rps_result_results" class="group" style="display: none;">
		   		Shortcode Result
		   </div>
		   <div id="udev-api-tab" class="group" style="display: none;">
		   		API
		   </div>
		   <div id="udev-license-tab" class="group" style="display: none;">
		   		License
		   </div>
		</div>
		<script>
		   jQuery(document).ready(function($) {
		       //Initiate Color Picker
		       $('.wp-color-picker-field').wpColorPicker();
		   
		       // Switches option sections
		       $('.group').hide();
		       var activetab = '';
		       if (typeof(localStorage) != 'undefined' ) {
		           console.log(localStorage);
		           activetab = localStorage.getItem("activetab");
		       }
		       //console.log(activetab);
		       if (activetab != '' && $(activetab).length ) {
		           $(activetab).fadeIn();
		       } else {
		           $('.group:first').fadeIn();
		       }
		       $('.group .collapsed').each(function(){
		           $(this).find('input:checked').parent().parent().parent().nextAll().each(
		           function(){
		               if ($(this).hasClass('last')) {
		                   $(this).removeClass('hidden');
		                   return false;
		               }
		               $(this).filter('.hidden').removeClass('hidden');
		           });
		       });
		   
		       if (activetab != '' && $(activetab + '-tab').length ) {
		           $(activetab + '-tab').addClass('nav-tab-active');
		       }
		       else {
		           $('.nav-tab-wrapper a:first').addClass('nav-tab-active');
		       }
		       $('.nav-tab-wrapper a').click(function(evt) {
		           $('.nav-tab-wrapper a').removeClass('nav-tab-active');
		           $(this).addClass('nav-tab-active').blur();
		           var clicked_group = $(this).attr('href');
		           if (typeof(localStorage) != 'undefined' ) {
		               localStorage.setItem("activetab", $(this).attr('href'));
		           }
		           $('.group').hide();
		           $(clicked_group).fadeIn();
		           evt.preventDefault();
		       });
		   
		       
		   });
		</script>
		<style type="text/css">
		   /** WordPress 3.8 Fix **/
		   .form-table th { padding: 20px 10px; }
		   #wpbody-content .metabox-holder { padding-top: 5px; }
		</style>

    </div>
	<?php 
}