<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Update Setting
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('settings.update', $setting->id)); ?>">
          <div class="form-group">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PATCH'); ?>
              <label for="name">Variable_group:</label>
              <input type="text" class="form-control" name="variable_group" value="<?php echo e($setting->variable_group); ?>"/>
          </div>
          <div class="form-group">
              <label for="price">Variable Name :</label>
              <input type="text" class="form-control" name="variable_name" value="<?php echo e($setting->variable_name); ?>"/>
          </div>
          <div class="form-group">
              <label for="price">variable_value :</label>
              <input type="text" class="form-control" name="variable_value" value="<?php echo e($setting->variable_value); ?>"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update Setting</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/settings/edit.blade.php ENDPATH**/ ?>