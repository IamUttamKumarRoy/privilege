<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New User Role</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('privilege_menus.index')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('privilege_menus.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">
              <label for="privilege_menu_category_id">Category:</label>
              <select class="form-control" name="privilege_menu_category_id" id="privilege_menu_category_id">
                <option>Select Privillege Menu Category</option>                         
                <?php if( !empty($menu_category) ): ?>     
                    <?php $__currentLoopData = $menu_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_cat_id =>$menu_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                      <option value="<?php echo e($menu_cat_id); ?>"><?php echo e($menu_cat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            </div> 
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Privilege Name:</strong>
                <input type="text" name="privilege_name" class="form-control" placeholder="Privilege Name">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Uri:</strong>
                <input type="text" name="uri" class="form-control" placeholder="uri">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Route Name:</strong>
                <input type="text" name="route_name" class="form-control" placeholder="route_name">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Method:</strong>
                <input type="text" name="methods" class="form-control" placeholder="Method">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Controller:</strong>
                <input type="text" name="controller" class="form-control" placeholder="Controller">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Action:</strong>
                <input type="text" name="action" class="form-control" placeholder="Action">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Ordering:</strong>
                <input type="text" name="ordering" class="form-control" placeholder="Ordering">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/privilege_menus/create.blade.php ENDPATH**/ ?>