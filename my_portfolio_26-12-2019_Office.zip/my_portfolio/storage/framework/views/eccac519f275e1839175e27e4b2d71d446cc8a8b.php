<!-- To the right -->
<div class="pull-right hidden-xs">
  Anything you want
</div>
<!-- Default to the left -->
<strong>Copyright &copy; 2016 <a href="#">Company</a>.</strong> All rights reserved.<?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/layouts/admin_lte/main-footer.blade.php ENDPATH**/ ?>