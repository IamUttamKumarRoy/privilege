<section class="content-header">
	
	<?php if(!empty($page_header) ): ?>         
      <h1>
	    <?php echo e($page_header); ?>

	    <small><?php echo e(!empty($page_header_desc) ? $page_header_desc : ''); ?></small>
	  </h1>
	<?php else: ?>       
	<?php endif; ?>

  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
    <li class="active">Here</li>
  </ol>
  
</section><?php /**PATH D:\xampp72\htdocs\laravel_projects\my_portfolio\resources\views/layouts/admin_lte/content-header.blade.php ENDPATH**/ ?>