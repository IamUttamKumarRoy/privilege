<?php

namespace App\Http\Controllers;

use App\CommonClass\AppController;
use App\PrivilegeMenu;
use Illuminate\Http\Request;

class PrivilegeMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $menu_category = AppController::getPrivilegeMenuCategory();

        $privilege_menus = PrivilegeMenu::latest()->paginate(5);
        return view('privilege_menus.index',compact('privilege_menus','menu_category'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $menu_category = AppController::getPrivilegeMenuCategory();

        return view('privilege_menus.create',compact('menu_category'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        //dd($request->all());
        $request->validate([
            'privilege_menu_category_id' => 'required',  
            'privilege_name' => 'required',  
            'route_name' => 'required'  
        ]);

        PrivilegeMenu::create($request->all());

        return redirect()->route('privilege_menus.index')
                        ->with('success','Privilege Menu created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $privilege_menu = PrivilegeMenu::findOrFail($id);

        return view('privilege_menus.show', compact('privilege_menu'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $privilege_menu = PrivilegeMenu::findOrFail($id);

       return view('privilege_menus.edit', compact('privilege_menu'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'privilege_menu_category_id' => 'required',  
            'privilege_name' => 'required',  
            'route_name' => 'required',  
            'uri' => '',  
            'methods' => '',  
            'action' => '',  
            'controller' => '',  
            'ordering' => ''  
        ]); 

        PrivilegeMenu::whereId($id)->update($validatedData);

        return redirect()->route('privilege_menus.index')->with('success', 'Privilege Menu is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PrivilegeMenu  $privilegeMenu
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $privilege_menu = PrivilegeMenu::findOrFail($id);
        $privilege_menu->delete();
 
        return redirect()->route('privilege_menus.index')->with('success', 'Privilege Menu is successfully deleted');
    }
}
