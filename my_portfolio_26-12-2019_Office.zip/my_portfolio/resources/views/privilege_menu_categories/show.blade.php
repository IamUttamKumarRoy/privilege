@extends('layouts.admin_lte')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show User Privilege Menu Category</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('privilege_menu_categories.index') }}"> Back</a>
            </div>
        </div>
    </div>

   

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Role Name:</strong>
                {{ $privilege_menu_category->category_name }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Precedence:</strong>
                {{ $privilege_menu_category->precedence }}
            </div>
        </div> 
    </div>

@endsection