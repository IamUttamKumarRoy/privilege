@extends('layouts.admin_lte')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Update User Role
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
    <form method="post" action="{{ route('privilege_menu_categories.update', $privilege_menu_category->id) }}">
          <div class="form-group">
              @csrf
              @method('PATCH')
              <label for="name">Category Name:</label>
              <input type="text" class="form-control" name="category_name" value="{{ $privilege_menu_category->category_name }}"/>
          </div>
          <div class="form-group">
              <label for="price">Precedence :</label>
              <input type="text" class="form-control" name="precedence" value="{{ $privilege_menu_category->precedence }}"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update User Role</button>
      </form>
  </div>
</div>
@endsection