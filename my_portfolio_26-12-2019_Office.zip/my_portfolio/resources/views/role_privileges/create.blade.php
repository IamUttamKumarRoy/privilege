@extends('layouts.admin_lte')

@section('content')

<div class="clearfix"></div>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Role Privilege</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('role_privileges.index') }}"> Back</a>
        </div>
    </div>
</div>

@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('role_privileges.store') }}" method="POST">
    @csrf
     <div class="row">

        @if( !empty($privilege_menus) )
            <ul class="tree_view">
                @php
                $inc = 1;
                @endphp
                @foreach ($privilege_menus as $menu_cat_id =>$pm_data )    
                    <li class="tree-node expanded {{ ($inc==1) ? 'current':''}} ">
                        <label class="checkbox" for="PrivilegeMenuCategory{{$menu_cat_id}}">
                        <input type="checkbox" name="privilege_menu_category[]" id="PrivilegeMenuCategory{{$menu_cat_id}}" value="{{$menu_cat_id}}">
                        <span class="check"></span><span class="caption">{{ !empty($privilege_menu_category_list[$menu_cat_id]) ? $privilege_menu_category_list[$menu_cat_id]:''}}</span></label>
                        
                        @if( !empty($pm_data) )
                        <ul>
                            @foreach ($pm_data as $pm_row ) 
                            <li>
                                <label class="checkbox" for="PrivilegeMenu{{$pm_row['id']}}">
                                <input type="checkbox" name="privilege_menu[]" id="PrivilegeMenu{{$pm_row['id']}}" value="{{$pm_row['id']}}">
                                <span class="check"></span><span class="caption">{{$pm_row['privilege_name']}}</span></label>
                            </li>
                            @endforeach
                        </ul>
                        @endif    
                    </li>
                    @php
                    $inc++;
                    @endphp
                @endforeach
            </ul>
        @endif     
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div> 
    
</form>

@endsection