@extends('layouts.admin_lte')

@section('content')

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Role Privilege</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('role_privileges.index') }}"> Back</a>
        </div>
    </div>
</div>

@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('role_privileges.store') }}" method="POST">
    @csrf
     <div class="row">
         
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
              <label for="user_role_id">Category:</label>
              <select class="form-control" name="user_role_id" id="user_role_id">
                <option>Select Privillege Menu Category</option>                         
                @if( !empty($user_roles) )     
                    @foreach ($user_roles as $user_role_id =>$user_role_name )    
                      <option value="{{ $user_role_id }}">{{ $user_role_name }}</option>
                    @endforeach
                @endif
            </select>
            </div> 
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                                       
                @if( !empty($privilege_menus) )     
                    @foreach ($privilege_menus as $privilege_menu )    
                      {{ $privilege_menu->privilege_name }}<br/>
                    @endforeach
                @endif

            </div> 
        </div>   
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>


    
    <div class="row">
       <ul>
                <li>HTML
                <ul>
                    <li data-value="table">HTML table</li>
                    <li data-value="links">HTML links</li>
                 </ul>
                </li>
                <li>PHP
                    <ul>
                        <li data-value="PHP if..else">PHP if..else</li>
                        <li>PHP Loops
                            <ul>
                                <li data-value="For loop">For loop</li>
                                <li data-value="While loop">While loop</li>
                                <li data-value="Do WHile loop">Do WHile loop</li>
                            </ul>
                        </li>
                        <li>PHP arrays</li>
                    </ul>
                </li>
                <li>jQuery
                    <ul>
                        <li data-value="jQuery append">jQuery append</li>
                        <li data-value="jQuery prepend">jQuery prepend</li>
                    </ul>
                </li>
            </ul>
    </div>
    <div class="row">
       <ul class="menu">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li>
              <a class="caret" href="javascript:void(0);"><i class="fa fa-graduation-cap"></i> Tutorial</a>
              <ul class="nested">
                <li>
                  <a class="caret" href="javascript:void(0);"><i class="fa fa-chrome"></i> Web Development</a>
                  <ul class="nested">
                    <li><a href="#">Blog Project</a></li>
                    <li><a href="#">CMS Project</a></li>
                    <li><a href="#">Shop Project</a></li>
                    <li><a href="#">E-learning Project</a></li>
                    <li><a href="#">Automasion Project</a></li>
                  </ul>
                </li>
                <li>
                  <a class="caret" href="javascript:void(0);"><i class="fa fa-server"></i> Network</a>
                  <ul class="nested">
                    <li><a href="#">Comptia</a></li>
                    <li><a href="#">Windows</a></li>
                    <li><a href="#">Linux</a></li>
                    <li><a href="#">CISCO</a></li>
                    <li><a href="#">MicroTik</a></li>
                    <li><a href="#">Virtualization</a></li>
                    <li><a href="#">Security</a></li>
                  </ul>
                </li>
                <li>
                  <a class="caret" href="javascript:void(0);"><i class="fa fa-microchip"></i> IOT</a>
                  <ul class="nested">
                    <li><a href="#">Concept</a></li>
                    <li><a href="#">Electronic</a></li>
                    <li><a href="#">Sensor</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li><a href="#"><i class="fa fa-archive"></i> Projects</a></li>
            <li><a href="#"><i class="fa fa-info-circle"></i> Resume</a></li>
            <li><a href="#"><i class="fa fa-envelope-open"></i> Contact me</a></li>
        </ul>
    </div>
    
</form>

<style type="text/css">
ul, .menu {
 list-style-type: none;
}
.menu {
  margin: 0;
  padding: 0;
}
.menu a {
  text-decoration: none;
}
.caret {
  cursor: pointer;
  user-select: none; /* Prevent text selection */
}
.caret::before {
  content: "\25B6";
  color: black;
  display: inline-block;
  margin-right: 6px;
}
.caret-down::before {
  transform: rotate(90deg);
}
.nested {
  display: none;
}
 .active {
  display: block;
}
</style>

@endsection