@extends('layouts.admin_lte')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 6 CRUD</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('settings.create') }}"> Create New Setting</a>
            </div>
        </div>
    </div>

  
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Variable Group</th>
            <th>Variable Name</th>
            <th>Variable Value</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($settings as $setting)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $setting->variable_group }}</td>
            <td>{{ $setting->variable_name }}</td>
            <td>{{ $setting->variable_value }}</td>
            <td>
                <form action="{{ route('settings.destroy',$setting->id) }}" method="POST">
                    <a class="btn btn-info" href="{{ route('settings.show',$setting->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('settings.edit',$setting->id) }}">Edit</a>
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $settings->links() !!}

@endsection