@extends('layouts.admin_lte')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New User Role</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('privilege_menus.index') }}"> Back</a>
        </div>
    </div>
</div>

@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('privilege_menus.store') }}" method="POST">
    @csrf
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">
              <label for="privilege_menu_category_id">Category:</label>
              <select class="form-control" name="privilege_menu_category_id" id="privilege_menu_category_id">
                <option>Select Privillege Menu Category</option>                         
                @if( !empty($menu_category) )     
                    @foreach ($menu_category as $menu_cat_id =>$menu_cat )    
                      <option value="{{ $menu_cat_id }}">{{ $menu_cat }}</option>
                    @endforeach
                @endif
            </select>
            </div> 
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Privilege Name:</strong>
                <input type="text" name="privilege_name" class="form-control" placeholder="Privilege Name">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Uri:</strong>
                <input type="text" name="uri" class="form-control" placeholder="uri">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Route Name:</strong>
                <input type="text" name="route_name" class="form-control" placeholder="route_name">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Method:</strong>
                <input type="text" name="methods" class="form-control" placeholder="Method">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Controller:</strong>
                <input type="text" name="controller" class="form-control" placeholder="Controller">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Action:</strong>
                <input type="text" name="action" class="form-control" placeholder="Action">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Ordering:</strong>
                <input type="text" name="ordering" class="form-control" placeholder="Ordering">
            </div>
        </div> 
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>

</form>

@endsection