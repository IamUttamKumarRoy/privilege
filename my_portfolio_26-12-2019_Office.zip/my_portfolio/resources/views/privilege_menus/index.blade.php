@extends('layouts.admin_lte')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Privilege Menu</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('privilege_menus.create') }}"> Create New Privilege Menu</a>
            </div>
        </div>
    </div>

  
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Category</th>
            <th>Privilege Name</th>
            <th>Uri</th>
            <th>Route Name</th>
            <th>Controller</th>
            <th>Action</th> 
            <th>Ordering</th> 
            <th width="280px">Action</th>
        </tr> 
        @foreach ($privilege_menus as $privilege_menu)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $privilege_menu->privilege_menu_category_id }}</td>
            <td>{{ $privilege_menu->privilege_name }}</td>
            <td>{{ $privilege_menu->uri }}</td> 
            <td>{{ $privilege_menu->route_name }}</td> 
            <td>{{ $privilege_menu->methods }}</td> 
            <td>{{ $privilege_menu->controller }}</td> 
            <td>{{ $privilege_menu->action }}</td> 
            <td>{{ $privilege_menu->ordering }}</td> 
            <td>
                <form action="{{ route('privilege_menus.destroy',$privilege_menu->id) }}" method="POST">
                    <a class="btn btn-info" href="{{ route('privilege_menus.show',$privilege_menu->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('privilege_menus.edit',$privilege_menu->id) }}">Edit</a>
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $privilege_menus->links() !!}

@endsection