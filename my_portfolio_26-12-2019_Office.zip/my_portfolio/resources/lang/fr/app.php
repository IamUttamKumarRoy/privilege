<?php

return [
    'title' =>  'Exemple de localisation'
];