﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
namespace ProjectDictionary
{
    class ClassUserWord
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        // Add or insert word to user table
        public string add_userWord(string username,string eng_word)
        {
            int has_id;
            has_id=get_userWord(username, eng_word);
            if (has_id == 0)
            {
                string msg = "";
                try
                {
                    string query;
                    con.Open();
                    query = "insert into memorize(user_id,word_id)";
                    query += " values((select id from [user] where user_name='" + username + "'),(select id from dictionary where english_word='" + eng_word + "'))";
                    SqlCommand com = new SqlCommand(query, con);
                    com.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    msg = Ex.Message.ToString();
                }
                finally
                {
                    con.Close();
                }
                return msg;
            }
            else
            {
                return "";
            }
        }

        public int get_userWord(string username, string eng_word)
        {
            string query;
            int stutus = 0;
            try
            {
                con.Open();
                query = "select * from memorize where user_id=(select id from [user] where user_name='"+username+"')";
                query += " and word_id=(select id from dictionary where english_word='" + eng_word + "')";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    stutus = 1;
                }
            }
            catch
            {
                stutus = -1;
            }
            finally
            {
                con.Close();                
            }
            return stutus;
        }
    }
}
