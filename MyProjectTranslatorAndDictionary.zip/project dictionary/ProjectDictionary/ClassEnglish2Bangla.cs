﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace ProjectDictionary
{
    class ClassEnglish2Bangla
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        //private english_word;
        // Get Details about Search Word int Main Form
        public string get_detailsByWord(string english_word)
        {
            try
            {
                string detail = "";
                con.Open();
                //string query = "select * from dictionary where english_word like '"+english_word+"%'";
                string query = "select * from dictionary where english_word ='" + english_word + "'";
                SqlDataReader reader;
                SqlCommand com = new SqlCommand(query,con);
                reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    detail += "" + reader.GetString(1).ToUpper().Trim() + " ";
                    detail += "(" + reader.GetString(2).Trim() + ")\n";
                    detail += "" + reader.GetString(3) + "\n\n";
                    /*
                    while(reader.Read())
                    {
                        detail += "" + reader.GetString(1).ToUpper().Trim() + " ";
                        detail += "(" + reader.GetString(2).Trim() + ")\n";
                        detail += "" + reader.GetString(3) + "\n\n";
                    }
                    */
                    return detail;
                }
                else
                {
                    return "";
                }
            }
            catch (Exception Ex)
            {
                return "~ERROR \n"+Ex.Message.ToString();
            }
            finally
            {                
                con.Close();
            }           
        }
        // Increment Word Views 
        public void increment_wordView(string english_word)
        {
            try
            {
                int temp;
                string query;
                temp = this.get_wordView(english_word);                
                if (temp == 0)
                {
                   query = "update dictionary set views=1 where english_word='" + english_word + "'";
                }
                else if(temp==-1||temp==-999)
                {
                    query = "select * from dictionary";
                }
                else
                {
                   query = "update dictionary set views="+(temp+1)+" where english_word='" + english_word + "'";
                }

                con.Open();
                //MessageBox.Show(query.ToString());
                SqlCommand com =new SqlCommand(query,con);
                com.ExecuteNonQuery();
                //int test = com.ExecuteNonQuery();
                //MessageBox.Show("Affected Rows:"+test.ToString());
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
            
        }
        // Get the current Word Views From Dictioary table
        public int get_wordView(string english_word)
        {
            try
            {
                this.con.Open();
                string query = "select views from dictionary where english_word='"+english_word+"'";
                SqlDataReader reader;
                SqlCommand com = new SqlCommand(query, this.con);
                reader = com.ExecuteReader();
                reader.Read();
                if(reader.HasRows)
                {
                    //MessageBox.Show(reader.GetInt32(0).ToString());                   
                    if (reader.GetInt32(0) > 0)
                    {                        
                        return reader.GetInt32(0);
                    }                    
                    return 0;
                }
                 //MessageBox.Show("0");
                 return -1;               
            }
            catch//(Exception Ex)
            {
                //MessageBox.Show("-999\n" + Ex.Message.ToString());
                return -999;
            }
            finally
            {
                this.con.Close();
            }
        }
        // Insert Search Word to "searchedword" table
        public void insertSearchedWord(string english_word)
        {
            try
            {
                string query;
                int word_id,temp;
                word_id = getIdByWord(english_word); // Get word_id from dictionary table
                temp = haveIdSearchedWord(word_id); // Check wheather word_id inserted or not
                con.Open();
                if (temp != -999)
                {                    
                    if(temp==-1)
                    {
                        query = "insert into searched_word(word_id) values(" + word_id + ")";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                        query = "";
                    }
                }
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
        }
        // Get ID from dictionary table by english_word
        public int getIdByWord(string english_word)
        {
            try
            {
                this.con.Open();
                string query = "select id from dictionary where english_word='" + english_word + "'";
                //MessageBox.Show("" + query);
                SqlDataReader reader;
                SqlCommand com = new SqlCommand(query, this.con);
                reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    return reader.GetInt32(0);
                }
                return -1;
            }
            catch//(Exception Ex)
            {
                //MessageBox.Show("-999\n"+Ex.Message.ToString());
                return -999;
            }
            finally
            {
                this.con.Close();
            }
        }
        // Is word_id is inserted or not 
        public int haveIdSearchedWord(int word_id)
        {
            try
            {
                con.Open();
                string query = "select id from searched_word where word_id=" + word_id;
                //MessageBox.Show("" + query);
                SqlDataReader reader;
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    return reader.GetInt32(0);
                }
                return -1;
            }
            catch
            {
                return -999;
            }
            finally
            {
                con.Close();
            }
        }
        //
        public void add_Word(string eng,string pos,string bn,string cat,string top,string fp,string sp,string tp,string com)
        {
            try
            {
                string query;
                con.Open();
                query = "insert into dictionary(english_word,part_of_speech,bangla_word,category,topic,first_person_meaning,second_person_meaning,third_person_meaning,comments) ";
                query += " values('"+eng+"','"+pos+"',N'"+bn+"','"+cat+"','"+top+"',N'"+fp+"',N'"+sp+"',N'"+tp+"',N'"+com+"')";
                //MessageBox.Show(query);                
                SqlCommand comand = new SqlCommand(query,con);
                comand.ExecuteNonQuery();
                MessageBox.Show("Word Added Successfully!");
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
    }
}
