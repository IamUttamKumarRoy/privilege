﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class Exercise_Main : Form
    {
        public Exercise_Main()
        {
            InitializeComponent();
        }

        private void Main_Exercise_Load(object sender, EventArgs e)
        {

        }

        private void home_btn_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void voice_exercise_btn_Click(object sender, EventArgs e)
        {
            Exercise_Voice exVoice_form = new Exercise_Voice();
            exVoice_form.ShowDialog();
        }

        private void advanced_dic_btn_Click(object sender, EventArgs e)
        {
            Exercise_Article exArt_form = new Exercise_Article();
            exArt_form.ShowDialog();
        }

        private void translator_btn_Click(object sender, EventArgs e)
        {
            Exercise_Adjective exAdj_form = new Exercise_Adjective();
            exAdj_form.ShowDialog();
        }

        private void grammar_btn_Click(object sender, EventArgs e)
        {
            Exercise_RFOV exRFOV_form = new Exercise_RFOV();
            exRFOV_form.ShowDialog();
        }

        private void exercise_btn_Click(object sender, EventArgs e)
        {
            Exercise_Preposition exPre_form = new Exercise_Preposition();
            exPre_form.ShowDialog();
        }
    }
}
