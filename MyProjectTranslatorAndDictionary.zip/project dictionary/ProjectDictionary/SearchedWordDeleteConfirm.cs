﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class SearchedWordDeleteConfirm : Form
    {
        public SearchedWordDeleteConfirm()
        {
            InitializeComponent();
        }

        private void ok_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No; 
        }

        private void SearchedWordDeleteConfirm_Load(object sender, EventArgs e)
        {

        }
    }
}
