﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ProjectDictionary
{
    public partial class AdvancedDictionary : Form
    {
        public AdvancedDictionary()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");

        private void AdvancedDictionary_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
            }
            catch(Exception Ex)
            {
                MessageBox.Show("Following Error Occured:\n"+Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void advanced_dic_btn_Click(object sender, EventArgs e)
        {
            main main_form = new main();
            main_form.ShowDialog();
            //main_form.Show();
        }

        private void translator_btn_Click(object sender, EventArgs e)
        {
            Translator tr_form = new Translator();
            tr_form.ShowDialog();
        }

        private void grammar_btn_Click(object sender, EventArgs e)
        {
            Grammar gr_form = new Grammar();
            gr_form.ShowDialog();
        }

        private void exercise_btn_Click(object sender, EventArgs e)
        {
            Exercise_Main mex_form = new Exercise_Main();
            mex_form.ShowDialog();
        }

        private void about_btn_Click(object sender, EventArgs e)
        {
            About_Dev abd_form = new About_Dev();
            abd_form.ShowDialog();
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            //this.Dispose();
            Application.Exit();
        }
    }
}
