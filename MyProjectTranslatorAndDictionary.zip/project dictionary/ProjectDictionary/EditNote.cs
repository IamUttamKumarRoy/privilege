﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class EditNote : Form
    {
        public EditNote()
        {
            InitializeComponent();
        }
        public string note_text { get; set; }
        public string note_title { get; set; }

        public void set_field(string title,string noteText)
        {
            note_title = title;
            note_text = noteText;            
        }
        private void EditNote_Load(object sender, EventArgs e)
        {
            title_tb.Text = note_title;
            noteText_rtb.Text = note_text;
        }
        private void updateNote_btn_Click(object sender, EventArgs e)
        {
            note_title = title_tb.Text;
            note_text = noteText_rtb.Text;     
            this.DialogResult = DialogResult.OK;
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
        }

        private void wrapper_panel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
