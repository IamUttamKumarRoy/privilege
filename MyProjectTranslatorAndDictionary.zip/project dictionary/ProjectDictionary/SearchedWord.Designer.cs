﻿namespace ProjectDictionary
{
    partial class SearchedWord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.all_word_lb = new System.Windows.Forms.ListBox();
            this.delete_btn = new System.Windows.Forms.Button();
            this.delete_all_btn = new System.Windows.Forms.Button();
            this.result_tv = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // all_word_lb
            // 
            this.all_word_lb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.all_word_lb.FormattingEnabled = true;
            this.all_word_lb.ItemHeight = 23;
            this.all_word_lb.Location = new System.Drawing.Point(12, 12);
            this.all_word_lb.Name = "all_word_lb";
            this.all_word_lb.Size = new System.Drawing.Size(214, 303);
            this.all_word_lb.TabIndex = 0;
            this.all_word_lb.SelectedIndexChanged += new System.EventHandler(this.all_word_lb_SelectedIndexChanged);
            // 
            // delete_btn
            // 
            this.delete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete_btn.ForeColor = System.Drawing.Color.White;
            this.delete_btn.Location = new System.Drawing.Point(12, 321);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(103, 34);
            this.delete_btn.TabIndex = 4;
            this.delete_btn.Text = "Delete";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // delete_all_btn
            // 
            this.delete_all_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.delete_all_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_all_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete_all_btn.ForeColor = System.Drawing.Color.White;
            this.delete_all_btn.Location = new System.Drawing.Point(123, 321);
            this.delete_all_btn.Name = "delete_all_btn";
            this.delete_all_btn.Size = new System.Drawing.Size(103, 34);
            this.delete_all_btn.TabIndex = 5;
            this.delete_all_btn.Text = "Delete List";
            this.delete_all_btn.UseVisualStyleBackColor = false;
            this.delete_all_btn.Click += new System.EventHandler(this.delete_all_btn_Click);
            // 
            // result_tv
            // 
            this.result_tv.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.result_tv.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_tv.Location = new System.Drawing.Point(232, 12);
            this.result_tv.MultiSelect = false;
            this.result_tv.Name = "result_tv";
            this.result_tv.Size = new System.Drawing.Size(240, 303);
            this.result_tv.TabIndex = 14;
            this.result_tv.TileSize = new System.Drawing.Size(230, 50);
            this.result_tv.UseCompatibleStateImageBehavior = false;
            this.result_tv.View = System.Windows.Forms.View.Tile;
            // 
            // SearchedWord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(481, 366);
            this.Controls.Add(this.result_tv);
            this.Controls.Add(this.delete_all_btn);
            this.Controls.Add(this.delete_btn);
            this.Controls.Add(this.all_word_lb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "SearchedWord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "All Searched Word";
            this.Load += new System.EventHandler(this.SearchedWord_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox all_word_lb;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Button delete_all_btn;
        public System.Windows.Forms.ListView result_tv;
    }
}