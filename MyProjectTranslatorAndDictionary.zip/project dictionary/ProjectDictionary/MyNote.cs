﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectDictionary
{
    public partial class MyNote : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        public string myList_username { get; set; }

        public MyNote()
        {
            InitializeComponent();
        }
        private void MyNote_Load(object sender, EventArgs e)
        {
            show_user();
            check_user_control();
        }
        // Check User List
        public void check_user_control()
        {
            try
            {
                con.Open();
                string query = "select user_name from [user]";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    delete_btn.Enabled = true;
                    rename_btn.Enabled = true;
                    addNote_btn.Enabled = true;
                    deleteNote_btn.Enabled = true;
                    //export_btn.Enabled = true;
                }
                else
                {
                    delete_btn.Enabled = false;
                    rename_btn.Enabled = false;
                    addNote_btn.Enabled = false;
                    deleteNote_btn.Enabled = false;
                    //export_btn.Enabled = false;
                    //MessageBox.Show("Work");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show("check_user_control\nFollowing Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();

            }
        }
        // Show User to List Box
        public void show_user()
        {
            try
            {
                con.Open();
                string query = "select user_name from [user]";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                all_user_lb.Items.Clear();
                while (reader.Read())
                {
                    if (reader.HasRows)
                    {
                        all_user_lb.Items.Add(reader.GetString(0));
                    }
                }
                if (all_user_lb.Items.Count > 0)
                {
                    //all_user_lb.SelectedIndex = 0;
                }
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("show_user\nFollowing Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        // Create User
        private void create_list_btn_Click(object sender, EventArgs e)
        {
            CreateUser cu_form = new CreateUser();
            if (cu_form.ShowDialog() == DialogResult.OK)
            {
                //string test = cu_form.test2;
                string username = cu_form.username;
                if (username != "")
                {
                    try
                    {
                        con.Open();
                        string query = "insert into [user](user_name) values('" + username + "')";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        show_user();
                        check_user_control();
                    }
                }
                //MessageBox.Show("UserName:"+username+"\n");
            }
        }
        // Rename User
        private void rename_btn_Click(object sender, EventArgs e)
        {
            RenameUser ru_form = new RenameUser();
            myList_username = all_user_lb.SelectedItem.ToString();
            ru_form.username = myList_username;
            if (ru_form.ShowDialog() == DialogResult.OK)
            {
                string username = ru_form.username;
                if (username != "" && myList_username != username)
                {
                    try
                    {
                        con.Open();
                        string query = "update [user] set user_name='" + username + "' where user_name='" + all_user_lb.SelectedItem.ToString() + "'";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        check_user_control();
                        show_user();
                    }
                }
            }
        }
        // Delete User
        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (all_user_lb.SelectedItem.ToString() != "" || all_user_lb.SelectedIndex != -1)
            {
                DeleteConfirm dc_form = new DeleteConfirm();
                if (dc_form.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        con.Open();
                        string query2;
                        query2 = "delete from user_note where user_id=(select id from [user] where user_name='" + all_user_lb.SelectedItem.ToString().TrimEnd() + "')";
                        //MessageBox.Show("Query:" + query2);
                        SqlCommand com2 = new SqlCommand(query2, con);
                        com2.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                    }

                    try
                    {
                        con.Open();
                        string query = "delete from [user] where user_name='" + all_user_lb.SelectedItem.ToString() + "'";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        check_user_control();
                        show_user();
                    }
                }
            }
        }
        // Add Note To Selected User
        private void addNote_btn_Click(object sender, EventArgs e)
        {
            if (all_user_lb.Items.Count > 0 && all_user_lb.SelectedIndex != -1)
            {
                AddNote an_form = new AddNote();
                if (an_form.ShowDialog() == DialogResult.OK)
                {
                    string noteText = an_form.note_text;
                    string noteTitle = an_form.note_title;
                    if (noteText != "" && noteTitle!="")
                    {
                        try
                        {
                            string query;
                            con.Open();
                            query = "insert into user_note(user_id,note,title,date)";
                            query += " values((select id from [user] where user_name='" + all_user_lb.SelectedItem.ToString().Trim() + "'),N'" + noteText + "',N'"+noteTitle+"','" + DateTime.Today + "')";
                            //MessageBox.Show("Query:" + query);
                            SqlCommand com = new SqlCommand(query, con);
                            com.ExecuteNonQuery();
                            MessageBox.Show("Note Successfully Added!\n");
                        }
                        catch (Exception Ex)
                        {
                            MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                        }
                        finally
                        {
                            con.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("You dont Enter Any Note Text and Title");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select any user from user list");
            }

        }
        // User Change from listbox
        private void all_user_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (all_user_lb.SelectedIndex != -1)
            {
                try
                {
                    string query, temp;
                    con.Open();
                    query = "select * from user_note where user_id=(select id from [user] where user_name='" + all_user_lb.SelectedItem.ToString().Trim() + "')";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    result_tv.Items.Clear();
                    while (reader.Read())
                    {
                        temp = "";
                        //temp += "Note#"+reader.GetInt32(0).ToString()+":"+reader.GetString(2).Substring(0,10) +" On "+ reader.GetDateTime(3).ToShortDateString();
                        //temp += "Note#" + reader.GetInt32(0).ToString() + ":" + " On " + reader.GetDateTime(4).ToShortDateString();
                        temp += "" + reader.GetString(3).ToString();
                        result_tv.Items.Add(temp);
                    }
                    reader.Close();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occcured\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }
        // Note Edit / Update of selected User
        private void result_tv_DoubleClick(object sender, EventArgs e)
        {
            string title;            
            string g_title="", g_text="";
            int id=0;
            try
            {
                title = result_tv.SelectedItems[0].Text;
                //MessageBox.Show("Note Title:" + title);
                con.Open();
                string query = "select * from user_note where title=N'" + title + "'";
                //MessageBox.Show("Query:"+query);
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                id = reader.GetInt32(0);
                g_title = reader.GetString(3);
                g_text = reader.GetString(2);
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
            // Update form show and update
            EditNote en_form = new EditNote();
            en_form.set_field(g_title, g_text);
            if (en_form.ShowDialog() == DialogResult.OK)
            {
                g_title = en_form.note_title.Trim();
                g_text = en_form.note_text.Trim();
                //MessageBox.Show(g_title + "<=>" + g_text);
                if (g_text != "" && g_title != "")
                {
                    try
                    {
                        con.Open();
                        string query = "update user_note set title=N'" + g_title + "' ,note=N'" + g_text + "' where id=" + id;
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                        MessageBox.Show("Note Updated Successfully");
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Note Title And Note Description Must Be Given");
                }
            }
        }
        // Delete Note of selected User
        private void deleteNote_btn_Click(object sender, EventArgs e)
        {
            DeleteConfirm dc_form = new DeleteConfirm();
            if(dc_form.ShowDialog()==DialogResult.OK)
            {
                string title ;
                try
                {
                    title = result_tv.SelectedItems[0].Text.Trim();
                    //MessageBox.Show("Note Title:" + title);
                    con.Open();
                    string query = "delete from user_note where title='" + title + "'";
                    SqlCommand com = new SqlCommand(query, con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Note Deleted Successfully");
                }
                catch(Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n"+Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }
        // --------------------------------------------------------------------
        private void result_tv_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        // --------------------------------------------------------------------
    }
}
