﻿namespace ProjectDictionary
{
    partial class Excercise_article2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Excercise_article2));
            this.exercise_btn = new System.Windows.Forms.Button();
            this.clear_btn = new System.Windows.Forms.Button();
            this.show_ans_btn = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.question_5_tb = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.status_lb = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.question_4_tb = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.question_3_tb = new System.Windows.Forms.TextBox();
            this.question_2_tb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.check_btn = new System.Windows.Forms.Button();
            this.question_1_tb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // exercise_btn
            // 
            this.exercise_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exercise_btn.Location = new System.Drawing.Point(554, 411);
            this.exercise_btn.Name = "exercise_btn";
            this.exercise_btn.Size = new System.Drawing.Size(63, 25);
            this.exercise_btn.TabIndex = 23;
            this.exercise_btn.Text = "Back";
            this.exercise_btn.UseVisualStyleBackColor = true;
            this.exercise_btn.Click += new System.EventHandler(this.exercise_btn_Click);
            // 
            // clear_btn
            // 
            this.clear_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clear_btn.Location = new System.Drawing.Point(291, 411);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(57, 25);
            this.clear_btn.TabIndex = 22;
            this.clear_btn.Text = "Clear";
            this.clear_btn.UseVisualStyleBackColor = true;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // show_ans_btn
            // 
            this.show_ans_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.show_ans_btn.Location = new System.Drawing.Point(453, 411);
            this.show_ans_btn.Name = "show_ans_btn";
            this.show_ans_btn.Size = new System.Drawing.Size(97, 25);
            this.show_ans_btn.TabIndex = 21;
            this.show_ans_btn.Text = "Show Answer";
            this.show_ans_btn.UseVisualStyleBackColor = true;
            this.show_ans_btn.Click += new System.EventHandler(this.show_ans_btn_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1, 66);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(622, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = resources.GetString("label13.Text");
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(358, 317);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(170, 20);
            this.label11.TabIndex = 18;
            this.label11.Text = "(a/an/the) beast in him.";
            // 
            // question_5_tb
            // 
            this.question_5_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question_5_tb.Location = new System.Drawing.Point(233, 311);
            this.question_5_tb.Name = "question_5_tb";
            this.question_5_tb.Size = new System.Drawing.Size(121, 26);
            this.question_5_tb.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(23, 314);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(206, 20);
            this.label12.TabIndex = 16;
            this.label12.Text = "Education could not remove";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.status_lb);
            this.panel2.Location = new System.Drawing.Point(7, 411);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(278, 23);
            this.panel2.TabIndex = 15;
            // 
            // status_lb
            // 
            this.status_lb.AutoSize = true;
            this.status_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_lb.Location = new System.Drawing.Point(2, 1);
            this.status_lb.Name = "status_lb";
            this.status_lb.Size = new System.Drawing.Size(62, 16);
            this.status_lb.TabIndex = 0;
            this.status_lb.Text = "0 Answer";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(153, 269);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(507, 20);
            this.label10.TabIndex = 14;
            this.label10.Text = "(a/an/the) Ekushey February is the international mother  lamguage day.";
            // 
            // question_4_tb
            // 
            this.question_4_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question_4_tb.Location = new System.Drawing.Point(26, 269);
            this.question_4_tb.Name = "question_4_tb";
            this.question_4_tb.Size = new System.Drawing.Size(121, 26);
            this.question_4_tb.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(205, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 20);
            this.label9.TabIndex = 12;
            this.label9.Text = "(a/an) honest man";
            // 
            // question_3_tb
            // 
            this.question_3_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question_3_tb.Location = new System.Drawing.Point(78, 207);
            this.question_3_tb.Name = "question_3_tb";
            this.question_3_tb.Size = new System.Drawing.Size(121, 26);
            this.question_3_tb.TabIndex = 11;
            // 
            // question_2_tb
            // 
            this.question_2_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question_2_tb.Location = new System.Drawing.Point(96, 158);
            this.question_2_tb.Name = "question_2_tb";
            this.question_2_tb.Size = new System.Drawing.Size(121, 26);
            this.question_2_tb.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(349, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = " (a/an/the) subject.";
            // 
            // check_btn
            // 
            this.check_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.check_btn.Location = new System.Drawing.Point(352, 411);
            this.check_btn.Name = "check_btn";
            this.check_btn.Size = new System.Drawing.Size(97, 25);
            this.check_btn.TabIndex = 8;
            this.check_btn.Text = "Check Answer";
            this.check_btn.UseVisualStyleBackColor = true;
            this.check_btn.Click += new System.EventHandler(this.check_btn_Click);
            // 
            // question_1_tb
            // 
            this.question_1_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question_1_tb.Location = new System.Drawing.Point(222, 113);
            this.question_1_tb.Name = "question_1_tb";
            this.question_1_tb.Size = new System.Drawing.Size(121, 26);
            this.question_1_tb.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "He is ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(221, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "(a/an) book on the table.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "There is ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "She has experience on";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(552, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Complete each sentence using the correct article.Click in a box,then type in your" +
                " answer.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(8, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Article Practice";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.YellowGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.exercise_btn);
            this.panel1.Controls.Add(this.clear_btn);
            this.panel1.Controls.Add(this.show_ans_btn);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.question_5_tb);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.question_4_tb);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.question_3_tb);
            this.panel1.Controls.Add(this.question_2_tb);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.check_btn);
            this.panel1.Controls.Add(this.question_1_tb);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(663, 467);
            this.panel1.TabIndex = 3;
            // 
            // Excercise_article2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 491);
            this.Controls.Add(this.panel1);
            this.Name = "Excercise_article2";
            this.Text = "Excercise_article2";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exercise_btn;
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.Button show_ans_btn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox question_5_tb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label status_lb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox question_4_tb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox question_3_tb;
        private System.Windows.Forms.TextBox question_2_tb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button check_btn;
        private System.Windows.Forms.TextBox question_1_tb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;

    }
}