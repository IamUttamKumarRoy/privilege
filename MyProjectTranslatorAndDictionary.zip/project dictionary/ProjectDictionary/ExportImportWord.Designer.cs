﻿namespace ProjectDictionary
{
    partial class ExportImportWord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.all_user_lb = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.importWord_btn = new System.Windows.Forms.Button();
            this.exportWord_btn = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.importWord_btn);
            this.panel1.Controls.Add(this.exportWord_btn);
            this.panel1.Location = new System.Drawing.Point(55, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(290, 310);
            this.panel1.TabIndex = 17;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.all_user_lb);
            this.panel2.Location = new System.Drawing.Point(19, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 225);
            this.panel2.TabIndex = 2;
            // 
            // all_user_lb
            // 
            this.all_user_lb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.all_user_lb.FormattingEnabled = true;
            this.all_user_lb.ItemHeight = 23;
            this.all_user_lb.Location = new System.Drawing.Point(-2, -2);
            this.all_user_lb.Name = "all_user_lb";
            this.all_user_lb.Size = new System.Drawing.Size(250, 211);
            this.all_user_lb.TabIndex = 1;
            this.all_user_lb.SelectedIndexChanged += new System.EventHandler(this.all_user_lb_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(101, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "User List";
            // 
            // importWord_btn
            // 
            this.importWord_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.importWord_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.importWord_btn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.importWord_btn.ForeColor = System.Drawing.Color.White;
            this.importWord_btn.Location = new System.Drawing.Point(19, 261);
            this.importWord_btn.Name = "importWord_btn";
            this.importWord_btn.Size = new System.Drawing.Size(90, 37);
            this.importWord_btn.TabIndex = 8;
            this.importWord_btn.Text = "Import";
            this.importWord_btn.UseVisualStyleBackColor = false;
            this.importWord_btn.Click += new System.EventHandler(this.importWord_btn_Click);
            // 
            // exportWord_btn
            // 
            this.exportWord_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.exportWord_btn.Enabled = false;
            this.exportWord_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exportWord_btn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exportWord_btn.ForeColor = System.Drawing.Color.White;
            this.exportWord_btn.Location = new System.Drawing.Point(115, 261);
            this.exportWord_btn.Name = "exportWord_btn";
            this.exportWord_btn.Size = new System.Drawing.Size(90, 37);
            this.exportWord_btn.TabIndex = 6;
            this.exportWord_btn.Text = "Export";
            this.exportWord_btn.UseVisualStyleBackColor = false;
            this.exportWord_btn.Click += new System.EventHandler(this.exportWord_btn_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // ExportImportWord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(400, 378);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "ExportImportWord";
            this.Text = "Export / Import Word";
            this.Load += new System.EventHandler(this.ExportImportWord_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button importWord_btn;
        private System.Windows.Forms.Button exportWord_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox all_user_lb;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}