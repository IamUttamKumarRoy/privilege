﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ProjectDictionary
{
    public partial class MyList : Form
    {
        string selected_text;
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        public string myList_username { get; set; }
        ClassUserWord UW = new ClassUserWord();
        public MyList()
        {
            InitializeComponent();            
        }
        public void setSelectedText(string sel_text="")
        {
            this.selected_text = sel_text;            
        }
        private void MyList_Load(object sender, EventArgs e)
        {
            check_user_control();
            show_user();
            show_word();
            if (all_user_lb.Items.Count > 0)
            {
                all_user_lb.SelectedIndex = 0;
            }
        }
        // Show User to List Box
        public void show_user()
        {
            try
            {
                con.Open();
                string query = "select user_name from [user]";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                all_user_lb.Items.Clear();
                while(reader.Read())
                {
                    if (reader.HasRows)
                    {
                        all_user_lb.Items.Add(reader.GetString(0));
                    }
                }
                if(all_user_lb.Items.Count>0)
                {
                    //all_user_lb.SelectedIndex = 0;
                }
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("show_user\nFollowing Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        // Check User List
        public void check_user_control()
        {
            try
            {
                con.Open();
                string query = "select user_name from [user]";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    delete_btn.Enabled = true;
                    rename_btn.Enabled = true;
                    addToList_btn.Enabled = true;
                    deleteFromList_btn.Enabled = true;
                    //export_btn.Enabled = true;
                }      
                else
                {
                    delete_btn.Enabled = false;
                    rename_btn.Enabled = false;
                    addToList_btn.Enabled = false;
                    deleteFromList_btn.Enabled = false;
                    //export_btn.Enabled = false;
                    //MessageBox.Show("Work");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show("check_user_control\nFollowing Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
                
            }
        }
        // Show Word List
        public void show_word()
        {
            if (all_user_lb.Items.Count > 0 && all_user_lb.SelectedIndex != -1)
            {
                try
                {
                    con.Open();
                    string query;
                    string detail;
                    query = "select * from dictionary where id ";
                    query += "IN(select word_id from memorize where user_id=(select id from [user] where user_name='"+all_user_lb.SelectedItem.ToString().Trim()+"'))";
                    //query = "select word_id from memorize where user_id=(select id from [user] where user_name='" + all_user_lb.SelectedItem.ToString().Trim() + "')";
                   // MessageBox.Show(query);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    result_tv.Items.Clear();
                    while(reader.Read())
                    {
                        detail = "";
                        
                        detail += "" + reader.GetString(1).ToUpper().Trim() + " ";
                        detail += "(" + reader.GetString(2).Trim() + ")\n";
                        detail += "" + reader.GetString(3) + "\n\n";                       
                        result_tv.Items.Add(detail);
                    }
                    reader.Close();
                }
                catch (SqlException Ex)
                {
                    MessageBox.Show("show_word\nFollowing Error Occured!\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }         
        }
        // Create List
        private void create_list_btn_Click(object sender, EventArgs e)
        {
            CreateUser cu_form = new CreateUser();
            if(cu_form.ShowDialog()==DialogResult.OK)
            {
                //string test = cu_form.test2;
                string username = cu_form.username;
                if(username!="")
                {
                    try
                    {
                        con.Open();
                        string query = "insert into [user](user_name) values('"+username+"')";
                        SqlCommand com = new SqlCommand(query,con);
                        com.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n"+Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        show_user();
                        check_user_control();
                    }
                }
                //MessageBox.Show("UserName:"+username+"\n");
            }
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if(all_user_lb.SelectedItem.ToString()!=""||all_user_lb.SelectedIndex!=-1)
            {
                DeleteConfirm dc_form = new DeleteConfirm();
                if (dc_form.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        con.Open();
                        string query2;
                        query2 = "delete from memorize where user_id=(select id from [user] where user_name='" + all_user_lb.SelectedItem.ToString().TrimEnd() + "')";
                        //MessageBox.Show("Query" + query2);
                        SqlCommand com2 = new SqlCommand(query2, con);
                        com2.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                    }

                    try
                    {
                        con.Open();
                        string query = "delete from [user] where user_name='" + all_user_lb.SelectedItem.ToString() + "'";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        check_user_control();
                        show_user();
                    }
                }
            }
        }

        private void rename_btn_Click(object sender, EventArgs e)
        {
            RenameUser ru_form = new RenameUser();
            myList_username = all_user_lb.SelectedItem.ToString();
            ru_form.username = myList_username;
            if(ru_form.ShowDialog()==DialogResult.OK)
            {
                string username = ru_form.username;
                if (username != "" && myList_username != username)
                {
                    try
                    {
                        con.Open();
                        string query = "update [user] set user_name='" + username + "' where user_name='" + all_user_lb.SelectedItem.ToString() + "'";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        check_user_control();
                        show_user();
                    }
                }
            }
        }

        private void addToList_btn_Click(object sender, EventArgs e)
        {
            if (all_user_lb.Items.Count > 0 && all_user_lb.SelectedIndex!=-1)
            {
                if (selected_text != "" && selected_text != null)
                {
                    string eng_word;
                    string[] word = selected_text.Split('(');
                    eng_word =word[0];
                    //MessageBox.Show("Selected Text:" + eng_word.ToLower());
                    UW.add_userWord(all_user_lb.SelectedItem.ToString(), eng_word);
                }
                else
                {
                    MessageBox.Show("You not selected any word in main form");
                }
            }
            show_word();
        }

        private void all_user_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            show_word();
        }

        private void deleteFromList_btn_Click(object sender, EventArgs e)
        {
            if (all_user_lb.Items.Count > 0 && all_user_lb.SelectedIndex != -1)
            {
                DeleteConfirm dc_form = new DeleteConfirm();
                if(dc_form.ShowDialog()==DialogResult.OK)
                {
                    try
                    {
                        string eng_word;
                        string[] word;
                        if (result_tv.Items.Count > 0 && result_tv.SelectedItems[0].Text.Trim() != "")
                        {
                            word = result_tv.SelectedItems[0].Text.Trim().Split('(');
                            eng_word = word[0];
                            //MessageBox.Show("Selected Text:" + eng_word.ToLower());
                        
                        }
                        else
                        {
                            MessageBox.Show("You not selected any word from list");
                            return;
                        }
                        con.Open();
                        string query;
                        query = "delete from memorize where user_id=";
                        query += "(select id from [user] where user_name='" + all_user_lb.SelectedItem.ToString().Trim()+ "')";
                        query += " and word_id=(select id from dictionary where english_word='" + eng_word + "')";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                    }
                    catch
                    {

                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        private void result_tv_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            try
            {
                //int word;
                //word = Convert.ToInt32(result_tv.SelectedIndices[0]);
                //MessageBox.Show("Word ID:" + word.ToString());           
                 MessageBox.Show("Word:" + result_tv.SelectedItems[0].Text);
                //MessageBox.Show("Word:" + result_tv.SelectedItems[word].Text);
                //MessageBox.Show("Index:"+result_tv.SelectedIndices[0].ToString());
                 string eng_word;
                 string[] word = result_tv.SelectedItems[0].Text.Split('(');
                 eng_word = word[0];
                 //MessageBox.Show("Selected Text:" + eng_word.ToLower());
                 MessageBox.Show("English Word:"+eng_word.ToLower());
            }
           catch//(Exception Ex)
            {
                //MessageBox.Show("Following Error Occured\n"+Ex.Message.ToString());
            }
            */
        }
        //
    }
}
