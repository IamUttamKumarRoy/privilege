﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class RenameUser : Form
    {
        public RenameUser()
        {
            InitializeComponent();
        }
        public string username { get; set; }

        private void ok_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            username = userName_tb.Text;
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void RenameUser_Load(object sender, EventArgs e)
        {
            userName_tb.Text = username;
            userName_tb.Focus();
        }
    }
}
