﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ProjectDictionary
{
    public partial class AdvancedSearch : Form
    {
        public AdvancedSearch()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        private void AdvancedSearch_Load(object sender, EventArgs e)
        {
            category_cb.SelectedIndex = 0;
            pos_cb.SelectedIndex = 0;
            topic_cb.SelectedIndex = 0;
        }

        private void find_btn_Click(object sender, EventArgs e)
        {
            if (search_tb.Text != "Optional : Type a word here")
            {
                /*MessageBox.Show("You Entered:"+search_tb.Text);
                MessageBox.Show("Category:"+category_cb.SelectedItem.ToString());
                MessageBox.Show("POS:" + pos_cb.SelectedItem.ToString());
                MessageBox.Show("Topic:" + topic_cb.SelectedItem.ToString());
                */
                try
                {
                    string query,detail;
                    con.Open();
                    query = "select * from dictionary where";
                    if(category_cb.SelectedItem.ToString()!="Any")
                    {
                        query += " category='"+category_cb.Text+"' and";
                    }
                    if (pos_cb.SelectedItem.ToString() != "Any")
                    {
                        query += " part_of_speech='" + pos_cb.Text + "' and";
                    }
                    if (topic_cb.SelectedItem.ToString() != "Any")
                    {
                        query += " topic='" + topic_cb.Text + "' and";
                    }
                    query += " english_word like '"+search_tb.Text+"%'";
                    //MessageBox.Show("Query:"+query);
                    SqlCommand com = new SqlCommand(query,con);
                    SqlDataReader reader = com.ExecuteReader();
                    result_tv.Items.Clear();
                    while(reader.Read())
                    {
                        detail = "";
                        detail += reader.GetString(1).ToUpper().Trim() + "";
                        detail += "(" + reader.GetString(2).Trim() + ")\n";
                        detail += reader.GetString(3) + "\n";
                        result_tv.Items.Add(detail);  
                    }
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n"+Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                try
                {
                    string query, detail;
                    con.Open();
                    query = "select * from dictionary where 1=1 ";
                    if (category_cb.SelectedItem.ToString() != "Any")
                    {
                        query += " and category='" + category_cb.Text + "'";
                    }
                    if (pos_cb.SelectedItem.ToString() != "Any")
                    {
                        query += " and part_of_speech='" + pos_cb.Text + "' ";
                    }
                    if (topic_cb.SelectedItem.ToString() != "Any")
                    {
                        query += "and topic='" + topic_cb.Text + "'";
                    }
                   // MessageBox.Show("Query:" + query);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    result_tv.Items.Clear();
                    while (reader.Read())
                    {
                        detail = "";
                        detail += reader.GetString(1).ToUpper().Trim() + "";
                        detail += "(" + reader.GetString(2).Trim() + ")\n";
                        detail += reader.GetString(3) + "\n";
                        result_tv.Items.Add(detail);
                    }
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }

        }

        private void clear_form_btn_Click(object sender, EventArgs e)
        {
            search_tb.Text = "Optional : Type a word here";
            category_cb.SelectedIndex = 0;
            pos_cb.SelectedIndex = 0;
            topic_cb.SelectedIndex = 0;
        }
    }
}
