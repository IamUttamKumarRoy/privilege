﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace ProjectDictionary
{
    class ClassTranslator
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        public string prev_tag = "";
        String[] tag;
        String[] bangla;
        String[] english;
        int len;

        public void setDetails(String[] pos_tag,String[] bangla,String[] english,int lenght)
        {
            this.tag = pos_tag;
            this.bangla = bangla;
            this.english = english;
            this.len = lenght;
        }
        //------------------------------------------------------------------------
        public string translate_v3()
        {
            string subj = "", verb = "", obj = "", pre_text = "", sent_part = "",temp_sub="";
            int is_sub = 0, is_verb = 0, is_pre = 0, is_conj1 = 0;
            int i;
            if (len <= 0)
            {
                return "";
            }
            else
            {
                for (i = 0; i < len; i++)
                {
                    if (tag[i] == "Article")
                    {
                        if (i == 0 && english[i] != "the")
                        {
                            subj = " " + bangla[i].Trim();
                        }
                        else if (english[i] == "the") { }
                        else if (is_sub == 1)
                            obj += " " + bangla[i].Trim();
                        else
                            obj += " " + bangla[i].Trim();

                    }// End of Tag Article
                    else if (tag[i] == "Noun")
                    {
                        if (i == 0)
                        {
                            subj = " " + bangla[i].Trim();
                            temp_sub = english[i];
                            is_sub = 1;
                        }
                        else if (i == 1 && (tag[i - 1] == "Noun" ||
                                        tag[i - 1] == "Pronoun" ||
                                        tag[i - 1] == "Adjective" ||
                                        tag[i] == "Article"))
                        {
                            subj += " " + bangla[i].Trim();
                            //temp_sub = english[i];
                            is_sub = 1;
                        }
                        else if (i == 1 && is_verb != 1 && (tag[i - 1] == "Noun" ||
                                             tag[i - 1] == "Pronoun" ||
                                             tag[i - 1] == "Adjective" ||
                                             tag[i] == "Article"))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (is_verb != 1)
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (is_verb == 1)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else if (tag[i - 1] == "Conjunction")
                        {
                            subj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Noun
                    else if (tag[i] == "Pronoun")
                    {
                        if (i == 0)
                        {
                            subj = " " + bangla[i].Trim();
                            temp_sub = english[i];
                            is_sub = 1;
                        }
                        else if (i == 1 && (tag[i - 1] == "Article" || is_sub != 1))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (tag[i - 1] == "Conjunction")
                        {
                            subj = " " + bangla[i].Trim();
                        }
                        else
                        {
                            obj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Pronoun
                    else if (tag[i] == "Verb")
                    {
                        if (is_verb != 1)
                        {
                            //verb = " " + bangla[i].Trim();
                            verb = " " + check_person(english[i],temp_sub).Trim();
                            is_verb = 1;
                        }
                        else if (is_verb == 1)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else
                        {
                            //verb += " " + bangla[i].Trim();
                            verb = " " + check_person(english[i], temp_sub).Trim();
                            is_verb = 1;
                        }
                    }// End of Tag Verb
                    else if (tag[i] == "Adjective")
                    {
                        if (is_verb == 1)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else if (is_sub != 1 && (i == 0 || i == 1))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else
                        {
                            obj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Adjective
                    else if (tag[i] == "Adverb")
                    {
                        if (i != 0)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else
                        {
                            obj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Adverb
                    else if (tag[i] == "Interjection")
                    {
                        if (i == 0)
                        {
                            subj += " " + bangla[i].Trim();
                        }
                        else
                        {
                            subj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Interjection
                    else if (tag[i] == "Preposition")
                    {
                        is_pre = 1;
                        pre_text = " " + bangla[i].Trim();
                    }// End of Tag Preposition
                    else if (tag[i] == "Conjunction")
                    {
                        if (is_conj1 == 0)
                        {
                            if (is_pre == 1)
                            {
                                sent_part = subj + obj + pre_text + verb + bangla[i].Trim();
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                            else
                            {
                                sent_part = subj + obj + verb + bangla[i].Trim();
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                        }
                        else if (is_conj1 == 1)
                        {
                            if (is_pre == 1)
                            {
                                sent_part += subj + obj + pre_text + verb + bangla[i].Trim();
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                            else
                            {
                                sent_part += subj + obj + verb + bangla[i].Trim();
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                        }
                    }// End of Tag Conjunction

                }//End of for Loop
                // Return sentence
                if (is_pre == 1)
                {
                    sent_part += subj + obj + pre_text + verb;
                }
                else
                {
                    sent_part += subj + obj + verb;
                }

                return sent_part;
            }
        }
        //------------------------------------------------------------------------
        public string translate_v2()
        {
            string subj = "", verb = "", obj = "", pre_text = "", sent_part = "";
            int is_sub=0,is_verb=0,is_pre=0,is_conj1=0;
            int i;
            if (len <= 0)
            {
                return "";
            }
            else
            {
                for (i = 0; i < len; i++)
                {
                    if (tag[i] == "Article")
                    {
                        if (i == 0 && english[i] != "the")
                        {
                            subj = " " + bangla[i].Trim();
                        }
                        else if (english[i] == "the") { }
                        else if (is_sub == 1)
                            obj += " " + bangla[i].Trim();
                        else
                            obj += " " + bangla[i].Trim();

                    }// End of Tag Article
                    else if (tag[i] == "Noun")
                    {
                        if (i == 0)
                        {
                            subj = " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (i == 1 && (tag[i - 1] == "Noun" ||
                                        tag[i - 1] == "Pronoun" ||
                                        tag[i - 1] == "Adjective" ||
                                        tag[i] == "Article"))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (i == 1 && is_verb != 1 && (tag[i - 1] == "Noun" ||
                                             tag[i - 1] == "Pronoun" ||
                                             tag[i - 1] == "Adjective" ||
                                             tag[i] == "Article"))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (is_verb != 1)
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (is_verb == 1)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else if (tag[i - 1] == "Conjunction")
                        {
                            subj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Noun
                    else if (tag[i] == "Pronoun")
                    {
                        if (i == 0)
                        {
                            subj = " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (i == 1 && (tag[i - 1] == "Article" || is_sub != 1))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else if (tag[i - 1] == "Conjunction")
                        {
                            subj = " " + bangla[i].Trim();
                        }
                        else
                        {
                            obj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Pronoun
                    else if (tag[i] == "Verb")
                    {
                        if (is_verb != 1)
                        {
                            //verb = " " + bangla[i].Trim();
                            verb = " " + check_person(english[i],subj).Trim();
                            is_verb = 1;
                        }
                        else if (is_verb == 1)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else
                        {
                            //verb += " " + bangla[i].Trim();
                            verb = " " + check_person(english[i],subj).Trim();
                            is_verb = 1;
                        }
                    }// End of Tag Verb
                    else if (tag[i] == "Adjective")
                    {
                        if (is_verb == 1)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else if (is_sub != 1 && (i == 0 || i == 1))
                        {
                            subj += " " + bangla[i].Trim();
                            is_sub = 1;
                        }
                        else
                        {
                            obj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Adjective
                    else if (tag[i] == "Adverb")
                    {
                        if (i != 0)
                        {
                            obj += " " + bangla[i].Trim();
                        }
                        else
                        {
                            obj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Adverb
                    else if (tag[i] == "Interjection")
                    {
                        if (i == 0)
                        {
                            subj += " " + bangla[i].Trim();
                        }
                        else
                        {
                            subj += " " + bangla[i].Trim();
                        }
                    }// End of Tag Interjection
                    else if (tag[i] == "Preposition")
                    {
                        is_pre = 1;
                        pre_text = " " + bangla[i].Trim();
                    }// End of Tag Preposition
                    else if (tag[i] == "Conjunction")
                    {
                        if (is_conj1 == 0)
                        {
                            if (is_pre == 1)
                            {
                                sent_part = subj + obj + pre_text + verb;
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                            else
                            {
                                sent_part = subj + obj + verb;
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                        }
                        else if (is_conj1 == 1)
                        {
                            if (is_pre == 1)
                            {
                                sent_part += subj + obj + pre_text + verb;
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                            else
                            {
                                sent_part += subj + obj + verb;
                                is_conj1 = 1;

                                subj = "";
                                verb = "";
                                obj = "";
                                pre_text = "";
                                is_sub = 0;
                                is_verb = 0;
                                is_pre = 0;
                            }
                        }
                    }// End of Tag Conjunction

                }//End of for Loop
               // Return sentence
                if (is_pre == 1)
                 {
                        sent_part = subj + obj + pre_text + verb;
                 }
                else
                 {
                        sent_part = subj + obj + verb;
                 }

                return sent_part;
            }
        }
        //----------------------------------------------------------------
        public string check_person(string english_word,string subject)
        {
            //MessageBox.Show("Subject:"+subject+"\nEnglish:"+english_word);
            //subject = subject.Substring(0,3);
            string person_meaning = "";
            if (subject.ToLower() == "i" || subject.ToLower() == "we")
            {
                person_meaning = get_meaningByPerson(english_word,"first_person_meaning");
            }
            else if (subject.ToLower() == "you")
            {
                person_meaning = get_meaningByPerson(english_word, "second_person_meaning");
            }
            else
            {
               /* if(subject=="")
                {

                }
                */
                person_meaning = get_meaningByPerson(english_word, "third_person_meaning");
            }
            return person_meaning;
        }
        //----------------------------------------------------------------
        public string get_meaningByPerson(string english_word,string person)
        {
            string pos = "", temp_word = "";

            if (english_word.Length > 1)
            {
                temp_word = english_word.Substring(0, english_word.Length - 1); // If Word Contain s to the end;It remove it

                pos = this.get_partOfSpeechByWord(temp_word);

                if (pos != "")
                {
                    english_word = temp_word;
                }
            }
            if (english_word.Length > 2)
            {
                temp_word = english_word.Substring(0, english_word.Length - 2); // If Word Contain s to the end;It remove it

                pos = this.get_partOfSpeechByWord(temp_word);

                if (pos != "")
                {
                    english_word = temp_word;
                }
            }
            if (english_word.Length > 3)
            {
                temp_word = english_word.Substring(0, english_word.Length - 3); // If Word Contain s to the end;It remove it
                pos = this.get_partOfSpeechByWord(temp_word);
                if (pos != "")
                {
                    english_word = temp_word;
                }
            }

            string bangla_mean = "";
            try
            {
                con.Open();
                string query;
                query = "select bangla_word," + person + " from dictionary where english_word='" + english_word + "'";
                SqlCommand com = new SqlCommand(query,con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                if(reader.HasRows)
                {
                    if (reader.GetString(1).ToString() == null || reader.GetString(1).ToString().Trim() == "")
                    {
                        bangla_mean = reader.GetString(0).ToString();
                    }
                    else
                    {
                        bangla_mean = reader.GetString(1).ToString();
                    }
                }

            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
            return bangla_mean;
        }
        //----------------------------------------------------------------
        public string translate()
        {
            string prev_tag = "", subj, verb, obj;//, pre_prev_tag = "";
            int i;
            subj = "";
            obj = "";
            verb = "";
            //string test = "";            
            //MessageBox.Show(len.ToString());
            for (i = 0; i < len; i++)
            {
                //test = bangla[i]+" ";
                //MessageBox.Show("BM:"+bangla[i]);
                if (i == 0 && tag[i] == "Article")
                {
                    prev_tag = "Determiner";
                    if (english[i] == "the" || english[i] == "The")
                    {
                    }
                    else
                    {
                        subj += " " + bangla[i].Trim();
                    }
                }
                else if (i == 0 && tag[i] == "Noun")
                {
                    prev_tag = "Noun";
                    subj += " " + bangla[i].Trim();
                }
                else if (i == 0 && tag[i] == "Pronoun")
                {
                    prev_tag = "Pronoun";
                    subj += " " + bangla[i].Trim();
                }
                else if (prev_tag == "Determiner" && tag[i] == "Noun")
                {
                    //pre_prev_tag = "Determiner";
                    prev_tag = "Noun";
                    subj += " " + bangla[i].Trim();
                }
                else if (prev_tag == "Noun" && tag[i] == "Adjective" && verb == "")
                {
                    //pre_prev_tag = "Noun";
                    prev_tag = "Adjective";
                    subj += " " + bangla[i].Trim();
                }
                else if (tag[i] == "Verb" && verb == "")
                {
                    prev_tag = "Verb";
                    verb = " " + bangla[i].Trim();
                }
                else
                {
                    obj += " " + bangla[i].Trim();
                }
            }
            //MessageBox.Show(subj + obj + verb);
            //MessageBox.Show(subj + obj + verb);
            //result_rtb.Text += subj + obj + verb;
            //result_rtb.Text += test;
            return subj + obj + verb;                
        }
        // Get Bangla word from english Word
        public string get_bangla(string english_word,string is_verb="")
        {
            string pos = "", temp_word = "";
            if (is_verb == "Verb")
            {
                if (english_word.Length > 1)
                {
                    temp_word = english_word.Substring(0, english_word.Length - 1); // If Word Contain s to the end;It remove it

                    pos = this.get_partOfSpeechByWord(temp_word);

                    if (pos != "")
                    {
                        english_word = temp_word;
                    }
                }
            }
            /*
            if (english_word.Length > 2)
            {
                temp_word = english_word.Substring(0, english_word.Length - 2); // If Word Contain s to the end;It remove it

                pos = this.get_partOfSpeechByWord(temp_word);

                if (pos != "")
                {
                    english_word = temp_word;
                }
            }
            if (english_word.Length > 3)
            {
                temp_word = english_word.Substring(0, english_word.Length - 3); // If Word Contain s to the end;It remove it
                pos = this.get_partOfSpeechByWord(temp_word);
                if (pos != "")
                {
                    english_word = temp_word;
                }
            }
            */
            string bangla_meaning = "";
            try
            {
                con.Open();
                SqlDataReader reader = null;
                string query = "select bangla_word from dictionary where english_word='" + english_word + "';";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    bangla_meaning = reader.GetString(0);                    
                    //MessageBox.Show("BM:"+bangla_meaning);
                }
                else
                {
                    bangla_meaning = english_word;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString() + "!_get_partOfSpeechByWord");
            }
            finally
            {
                con.Close();
            }
            //MessageBox.Show("Temp WOrd:"+temp_word+"\nPOS:"+pos+"\nBM:"+bangla_meaning);
            return bangla_meaning;
        }
        //
        public string get_partOfSpeech(string english_word)
        {
            string pos="",temp_word="";
            //int i;
            pos = this.get_partOfSpeechByWord(english_word);

           // temp_word = english_word.Substring(0,english_word.Length-1); // If Word Contain s to the end;It remove it

            //pos = this.get_partOfSpeechByWord(temp_word);
            if (pos == "")
            {
                if (english_word.Length > 1)
                {
                    temp_word = english_word.Substring(0, english_word.Length - 1); // If Word Contain s to the end;It remove it

                    pos = this.get_partOfSpeechByWord(temp_word);
                }
            }
            if (pos == "")
            {
                if (english_word.Length > 2)
                {
                    temp_word = english_word.Substring(0, english_word.Length - 2); // If Word Contain s to the end;It remove it

                    pos = this.get_partOfSpeechByWord(temp_word);
                }
            }
            if (pos == "")
            {
                if (english_word.Length > 3)
                {
                    temp_word = english_word.Substring(0, english_word.Length - 3); // If Word Contain s to the end;It remove it
                    pos = this.get_partOfSpeechByWord(temp_word);
                }
            }
            if (pos == "")
            {
                pos = this.partOfSpeech_ByTag(english_word);                
                if (pos == "")
                {
                    this.prev_tag = "Noun";
                    pos = "Noun";
                    return pos;
                }
                //MessageBox.Show("POS=0\nWORD:" + english_word + " <=> POS:" + pos + " <=>Pre Tag: " + prev_tag);
                this.prev_tag = pos;
                return pos;
            }
            else
            {
                //MessageBox.Show("POS=1\nWORD:" + english_word + " <=> POS:" + pos + " <=>Pre Tag: " + prev_tag);
                this.prev_tag = pos;
                return pos;
            }
        }
        //
        public string get_partOfSpeechByWord(string english_word)
        {
            string pos = "";
            try
            {
                con.Open();
                SqlDataReader reader = null;
                string query = "select part_of_speech from dictionary where english_word='" + english_word + "';";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    pos = reader.GetString(0);
                }
                else
                {
                    pos = "";
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString() + "!_get_partOfSpeechByWord");
            }
            finally
            {
                con.Close();
            }
            return pos;
        }
        //
        public string partOfSpeech_ByTag(string english_word)
        {
            string pos = "";
            /*
            pos = this.get_partOfSpeechByWord(english_word);
            if (pos != "")
            {
                return pos;
            }
            */
            /*
             if(prev_tag=="Verb") // if previous word is auxiliary verb then remove ing from word [eg playing to play]
            {
                //MessageBox.Show("VERB WORK");
                pos = is_verb(english_word);
                if (pos != "")
                    return pos;
            }
            */ 
            pos = is_noun_2(english_word);
            
            if (pos == "")
            {
                pos = is_adjective(english_word);
            }
           else if (pos == "")
            {
                pos = is_adverb(english_word);
            }
          /* else if (pos == "")
            {
                pos = is_adverb(english_word);
            }           
           */
           else if (pos == "")
            {
                pos = is_verb(english_word);
            }
            return pos;
        }
        public string is_verb(string english_word)
        {
            string pos = "";
            int i;
            string[] suffix = { "le", "on", "om", "m", "en" };
            //MessageBox.Show("WORD:" + english_word + " <=> POS:" + pos + " <=>Pre Tag: " + prev_tag);

            if(prev_tag=="Verb")
            {
                english_word = english_word.Substring(0,english_word.Length-3);
                //MessageBox.Show("MOD WORD:" + english_word);
                pos = get_partOfSpeechByWord(english_word);
                if (pos != "")
                    return pos;
            }
            for (i = 0; i < suffix.Length; i++)
            {
                Match match = Regex.Match(english_word, @"\w+" + suffix[i] + "$");
                if (match.Success)
                {
                    pos = "Verb";
                    return pos;
                }
            }
            return pos;
        }
        // End of is_verb
        public string is_adverb(string english_word)
        {
            string pos = "";
            int i;
            string[] suffix = {"ly","ling","long","way","ways","wise",
                               "ward","wards"};

            for (i = 0; i < suffix.Length; i++)
            {
                Match match = Regex.Match(english_word, @"\w+" + suffix[i] + "$");
                if (match.Success)
                {
                    pos = "Adverb";
                    return pos;
                }
            }
            return pos;
        }
        // End of is_adverb
        public string is_adjective(string english_word)
        {
            string pos = "";
            int i;
            string[] suffix = {"ed","en","ful","ish","ly","like","less","y","some",
                               "word","th","fold","ern","al","ar","ant","ary",
                               "arious","arian","ate","ive","ine","ile","ian","ese","ble",
                               "able","ite","ose","ous","fiq","ble","ple","ory","orious",
                               "ic","istic","astic","ly","ling","long","way","ways","wise",
                               "ward","wards"};

            for (i = 0; i < suffix.Length; i++)
            {
                Match match = Regex.Match(english_word, @"\w+" + suffix[i] + "$");
                if (match.Success)
                {
                    pos = "Adjective";
                    return pos;
                }
            }
            return pos;
        }
        // End of is_adjective
        public string is_noun_2(string english_word)
        {            
            string pos = "", temp;
            int i;
            string[] suffix = {"ter","ther","ard","art","ster","ar","or","t",
                               "ness","ing","red","ledge","lock","ship","th","dom",
                               "hood","ling","ock","ain","en","an","eer","ier","ant",
                               "ent","ary","aire","ar","acy","lence","ity","ty","many",
                               "al","als","sion","age","tion","son","som","ment","ance",
                               "tude","ancy","ism","asm","isk"};

            temp = english_word.Substring(0, 1);
            i = string.Compare(temp.ToUpper(), temp);
            if (i == 0)
            {
                pos = "Noun";
                return pos;
            }
           // MessageBox.Show("ID:"+i+"\nPOS:" + pos+"\nFirst WOrd:"+temp);
            if (this.prev_tag == "Determiner")
            {
                pos = "Noun";
                return pos;
            }
            /*else if (this.prev_tag == "Conjunction")
            {
                pos = "Pronoun";
                return pos;
            }
            else if (this.prev_tag == "Preposition")
            {
                pos = "Pronoun";
                return pos;
            }
            */
            for (i = 0; i < suffix.Length; i++)
            {
                Match match = Regex.Match(english_word, @"\w+" + suffix[i] + "$");
                if (match.Success)
                {
                    pos = "Noun";
                    return pos;
                }
            }
            return pos;
        }
        // End of is_noun_2
        public string is_noun(string english_word)
        {
            string pos = "", temp;
            string[] suffix = {"ter","ther","ard","art","ster","er","ar","or","t",
                               "ness","ing","red","ledge","lock","ship","th","dom",
                               "hood","ling","ock","ain","en","an","eer","ier","ant",
                               "ent","ary","aire","ar","acy","lence","ity","ty","many",
                               "al","als","sion","age","tion","son","som","ment","ance",
                               "tude","ancy","ism","asm","isk"};
            int i;
            temp = english_word.Substring(0, 1);// If first Char is capital
            i = string.Compare(temp.ToUpper(), temp);
            if (i == 0)
            {
                pos = "Noun";
                return pos;
            }
            if (this.prev_tag == "Determiner")
            {
                pos = "Noun";
                return pos;
            }
            /*else if (this.prev_tag == "Conjunction")
            {
                pos = "Pronoun";
                return pos;
            }
            else if (this.prev_tag == "Preposition")
            {
                pos = "Pronoun";
                return pos;
            }
            */
            int index;
            for (i = 0; i < suffix.Length; i++)
            {
                index = english_word.LastIndexOf(suffix[i]);
                if (index != -1)
                {
                    pos = "Noun";
                    return pos;
                }
            }
            return pos;
        }
        // End of is_noun

        // End of get_partOfSpeechByWord(string word)
        public string get_pos_by_pos_tag(string pos_tag)
        {
            string pos = "";
            switch (pos_tag)
            {
                case "CC":
                    pos = "Conjunction";
                    break;
                case "CD":
                    pos = "Number";
                    break;
                case "DT":
                    pos = "Determiner";
                    break;
                case "EX":
                    pos = "Existential there";
                    break;
                case "FW":
                    pos = "Foreign Word";
                    break;
                case "IN":
                    pos = "Preposition";
                    break;
                case "JJ":
                    pos = "Adjective";
                    break;
                case "JJR":
                    pos = "Adjective";
                    break;
                case "JJS":
                    pos = "Adjective";
                    break;
                case "LS":
                    pos = "List";
                    break;
                case "MD":
                    pos = "Modal";
                    break;
                case "NN":
                    pos = "Noun";
                    break;
                case "NNP":
                    pos = "Noun";
                    break;
                case "NNPS":
                    pos = "Noun";
                    break;
                case "NNS":
                    pos = "Noun";
                    break;
                case "PDT":
                    pos = "Predeterminer";
                    break;
                case "POS":
                    pos = "PossessiveEnding";
                    break;
                case "PRP":
                    pos = "Pronoun";
                    break;
                case "PRP$":
                    pos = "Pronoun";
                    break;
                case "RB":
                    pos = "Adverb";
                    break;
                case "RBR":
                    pos = "Adverb";
                    break;
                case "RBS":
                    pos = "Adverb";
                    break;
                case "RPP":
                    pos = "Particle";
                    break;
                case "SYM":
                    pos = "Symbol";
                    break;
                case "UH":
                    pos = "Interjection";
                    break;
                case "VV":
                    pos = "Verb";
                    break;
                case "VB":
                    pos = "Verb";
                    break;
                case "VBD":
                    pos = "Verb";
                    break;
                case "VBG":
                    pos = "Verb";
                    break;
                case "VBN":
                    pos = "Verb";
                    break;
                case "VBP":
                    pos = "Verb";
                    break;
                case "VBZ":
                    pos = "Verb";
                    break;
                case "WDT":
                    pos = "Pronoun";
                    break;
                case "WP":
                    pos = "Pronoun";
                    break;
                case "WP$":
                    pos = "Pronoun";
                    break;
                case "WRB":
                    pos = "Adverb";
                    break;
                default:
                    pos = "";
                    break;
            }
            return pos;
        }
        // End of get_pos_by_pos_tag(string pos_tag)
    }
}
