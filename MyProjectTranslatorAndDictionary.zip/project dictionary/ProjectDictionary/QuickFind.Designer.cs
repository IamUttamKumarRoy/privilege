﻿namespace ProjectDictionary
{
    partial class QuickFind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.result_tv = new System.Windows.Forms.ListView();
            this.find_btn = new System.Windows.Forms.Button();
            this.search_tb = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.az_lb = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.result_lb = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.result_tv);
            this.panel1.Location = new System.Drawing.Point(11, 197);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 250);
            this.panel1.TabIndex = 0;
            // 
            // result_tv
            // 
            this.result_tv.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.result_tv.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_tv.Location = new System.Drawing.Point(-1, -1);
            this.result_tv.MultiSelect = false;
            this.result_tv.Name = "result_tv";
            this.result_tv.Size = new System.Drawing.Size(300, 250);
            this.result_tv.TabIndex = 14;
            this.result_tv.TileSize = new System.Drawing.Size(265, 50);
            this.result_tv.UseCompatibleStateImageBehavior = false;
            this.result_tv.View = System.Windows.Forms.View.Tile;
            // 
            // find_btn
            // 
            this.find_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.find_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.find_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find_btn.ForeColor = System.Drawing.Color.White;
            this.find_btn.Location = new System.Drawing.Point(207, 7);
            this.find_btn.Name = "find_btn";
            this.find_btn.Size = new System.Drawing.Size(103, 27);
            this.find_btn.TabIndex = 8;
            this.find_btn.Text = "FIND";
            this.find_btn.UseVisualStyleBackColor = false;
            this.find_btn.Click += new System.EventHandler(this.find_btn_Click);
            // 
            // search_tb
            // 
            this.search_tb.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_tb.Location = new System.Drawing.Point(12, 7);
            this.search_tb.Name = "search_tb";
            this.search_tb.Size = new System.Drawing.Size(185, 26);
            this.search_tb.TabIndex = 9;
            this.search_tb.TextChanged += new System.EventHandler(this.search_tb_TextChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 39);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(30, 5);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(298, 149);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.az_lb);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(290, 119);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "A-Z List";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // az_lb
            // 
            this.az_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.az_lb.FormattingEnabled = true;
            this.az_lb.ItemHeight = 16;
            this.az_lb.Location = new System.Drawing.Point(-1, -1);
            this.az_lb.Name = "az_lb";
            this.az_lb.Size = new System.Drawing.Size(290, 116);
            this.az_lb.TabIndex = 0;
            this.az_lb.SelectedIndexChanged += new System.EventHandler(this.az_lb_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.result_lb);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(290, 119);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Result";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // result_lb
            // 
            this.result_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_lb.FormattingEnabled = true;
            this.result_lb.ItemHeight = 16;
            this.result_lb.Location = new System.Drawing.Point(-1, -1);
            this.result_lb.Name = "result_lb";
            this.result_lb.Size = new System.Drawing.Size(290, 116);
            this.result_lb.TabIndex = 0;
            this.result_lb.SelectedIndexChanged += new System.EventHandler(this.result_lb_SelectedIndexChanged);
            // 
            // QuickFind
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(322, 454);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.search_tb);
            this.Controls.Add(this.find_btn);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "QuickFind";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quick Find";
            this.Load += new System.EventHandler(this.QuickFind_Load);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.ListView result_tv;
        private System.Windows.Forms.Button find_btn;
        private System.Windows.Forms.TextBox search_tb;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox az_lb;
        private System.Windows.Forms.ListBox result_lb;
    }
}