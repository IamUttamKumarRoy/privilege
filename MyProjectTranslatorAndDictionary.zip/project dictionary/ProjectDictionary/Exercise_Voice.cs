﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class Exercise_Voice : Form
    {
        public Exercise_Voice()
        {
            InitializeComponent();
        }

        private void Exercise_Load(object sender, EventArgs e)
        {
        
        }

        private void check_btn_Click(object sender, EventArgs e)
        {
            int correct_ans=0,wrong_ans=0,total_ans=0;
            if (question_1_tb.Text != "")
            {
                if (question_1_tb.Text.ToLower() == "regarded")
                {
                    correct_ans++;
                    question_1_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_1_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End First Question
            if(question_2_tb.Text!="")
            {
                if (question_2_tb.Text.ToLower() == "been kept")
                {
                    correct_ans++;
                    question_2_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_2_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Second Question
            if (question_3_tb.Text != "")
            {
                if (question_3_tb.Text.ToLower() == "be relied")
                {
                    correct_ans++;
                    question_3_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_3_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Third Question
            if (question_4_tb.Text != "")
            {
                if (question_4_tb.Text.ToLower() == "be sent")
                {
                    correct_ans++;
                    question_4_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_4_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Fourth Question
            if (question_5_tb.Text != "")
            {
                if (question_5_tb.Text.ToLower() == "be held")
                {
                    correct_ans++;
                    question_5_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_5_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Fourth Question
            status_lb.Text=total_ans + " Answered "+correct_ans+" Correct "+wrong_ans+" Wrong";
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            question_1_tb.Text = "";
            question_2_tb.Text = "";
            question_3_tb.Text = "";
            question_4_tb.Text = "";
            question_5_tb.Text = "";
        }

        private void more_btn_Click(object sender, EventArgs e)
        {

        }

        private void show_ans_btn_Click(object sender, EventArgs e)
        {
            question_1_tb.ForeColor = question_2_tb.ForeColor = question_3_tb.ForeColor = question_4_tb.ForeColor = question_5_tb.ForeColor = Color.Green;
            question_1_tb.Text = "regarded";
            question_2_tb.Text = "been kept";
            question_3_tb.Text = "be relied";
            question_4_tb.Text = "be sent";
            question_5_tb.Text = "be held";
        }

        private void exercise_btn_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
