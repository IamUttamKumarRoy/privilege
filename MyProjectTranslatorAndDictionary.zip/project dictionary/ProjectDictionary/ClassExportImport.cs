﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace ProjectDictionary
{
    class ClassExportImport
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        // Check User Already Exist or Not
        public int hasUserId(string user_name)
        {
            int user_id = 0;
            try
            {
                con.Open();
                string query = "select id from [user] where user_name='"+user_name+"'";
                //MessageBox.Show("Query:" + query.ToString());
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    user_id = Convert.ToInt32(reader.GetValue(0));
                    //MessageBox.Show("HasRows Work");
                }                                
            }
            catch(Exception Ex)
            {
                //user_id = -1;
                MessageBox.Show("User_Id" + user_id + "Error:" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
            return user_id;
        }
        // Delete User Word 
        public void deleteUserWord(int user_id)
        {
            try
            {
                con.Open();
                string query = "delete from memorize where user_id="+user_id;
                SqlCommand com = new SqlCommand(query, con);
                com.ExecuteNonQuery();
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
        // Insert all word_id to memorize table
        public void insertUserWord(string query)
        {
            try
            {
                con.Open();                
                SqlCommand com = new SqlCommand(query, con);
                com.ExecuteNonQuery();
            }
            catch(Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n"+Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        // Insert User and get the inserted ID
        public void addUser(string user_name)
        {
            try
            {
                con.Open();
                string query = "insert into [user](user_name) values('"+user_name+"')";
                SqlCommand com = new SqlCommand(query, con);
                //com.Parameters[@"user_name"]=user_name;;
                com.ExecuteNonQuery();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        // Get the user id
        public int getUserID(string user_name)
        {
            int user_id = 0;
            try
            {
                con.Open();
                string query = "select id from [user] where user_name='"+user_name+"'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                if(reader.HasRows)
                {
                    user_id = Convert.ToInt32(reader.GetValue(0));
                }
               // MessageBox.Show("User ID:");
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
            return user_id;
        }
        //--------------
        // Delete User Word 
        public void deleteUserNote(int user_id)
        {
            try
            {
                con.Open();
                string query = "delete from user_note where user_id=" + user_id;
                SqlCommand com = new SqlCommand(query, con);
                com.ExecuteNonQuery();
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
        //----------------
        // Insert all word_id to memorize table
        public void insertUserNote(string query)
        {
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand(query, con);
                com.ExecuteNonQuery();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        //---------------------------
    }
}
