﻿namespace ProjectDictionary
{
    partial class Grammar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Noun");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Pronoun");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Adjective");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Verb");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Adverb");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Preposition");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Conjunction");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Interjection");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Part of Speech", new System.Windows.Forms.TreeNode[] {
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26,
            treeNode27});
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Present");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Past");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Future");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Tense", new System.Windows.Forms.TreeNode[] {
            treeNode29,
            treeNode30,
            treeNode31});
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Active Voice");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Passive Voice");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Voice", new System.Windows.Forms.TreeNode[] {
            treeNode33,
            treeNode34});
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Sentense");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Narration");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Others");
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.desc_rtb = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            treeNode20.Name = "noun_pos_child";
            treeNode20.Text = "Noun";
            treeNode21.Name = "Node19";
            treeNode21.Text = "Pronoun";
            treeNode22.Name = "Node20";
            treeNode22.Text = "Adjective";
            treeNode23.Name = "Node21";
            treeNode23.Text = "Verb";
            treeNode24.Name = "Node22";
            treeNode24.Text = "Adverb";
            treeNode25.Name = "Node23";
            treeNode25.Text = "Preposition";
            treeNode26.Name = "Node24";
            treeNode26.Text = "Conjunction";
            treeNode27.Name = "Node27";
            treeNode27.Text = "Interjection";
            treeNode28.Name = "pos_node";
            treeNode28.Text = "Part of Speech";
            treeNode29.Name = "Node33";
            treeNode29.Text = "Present";
            treeNode30.Name = "Node34";
            treeNode30.Text = "Past";
            treeNode31.Name = "Node35";
            treeNode31.Text = "Future";
            treeNode32.Name = "Node31";
            treeNode32.Text = "Tense";
            treeNode33.Name = "Node29";
            treeNode33.Text = "Active Voice";
            treeNode34.Name = "Node30";
            treeNode34.Text = "Passive Voice";
            treeNode35.Name = "Node28";
            treeNode35.Text = "Voice";
            treeNode36.Name = "Node36";
            treeNode36.Text = "Sentense";
            treeNode37.Name = "Node37";
            treeNode37.Text = "Narration";
            treeNode38.Name = "Node38";
            treeNode38.Text = "Others";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode28,
            treeNode32,
            treeNode35,
            treeNode36,
            treeNode37,
            treeNode38});
            this.treeView1.Size = new System.Drawing.Size(224, 443);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.treeView1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(225, 443);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.desc_rtb);
            this.panel2.Location = new System.Drawing.Point(242, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(365, 440);
            this.panel2.TabIndex = 2;
            // 
            // desc_rtb
            // 
            this.desc_rtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desc_rtb.Location = new System.Drawing.Point(0, 0);
            this.desc_rtb.Name = "desc_rtb";
            this.desc_rtb.ReadOnly = true;
            this.desc_rtb.Size = new System.Drawing.Size(365, 440);
            this.desc_rtb.TabIndex = 0;
            this.desc_rtb.Text = "";
            // 
            // Grammar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(615, 467);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Grammar";
            this.Text = "Grammar";
            this.Load += new System.EventHandler(this.Grammar_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox desc_rtb;
    }
}