﻿namespace ProjectDictionary
{
    partial class EditNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wrapper_panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.title_tb = new System.Windows.Forms.TextBox();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.updateNote_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.noteText_rtb = new System.Windows.Forms.RichTextBox();
            this.wrapper_panel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // wrapper_panel
            // 
            this.wrapper_panel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.wrapper_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wrapper_panel.Controls.Add(this.panel2);
            this.wrapper_panel.Controls.Add(this.cancel_btn);
            this.wrapper_panel.Controls.Add(this.updateNote_btn);
            this.wrapper_panel.Controls.Add(this.panel1);
            this.wrapper_panel.Location = new System.Drawing.Point(-2, -2);
            this.wrapper_panel.Name = "wrapper_panel";
            this.wrapper_panel.Size = new System.Drawing.Size(390, 290);
            this.wrapper_panel.TabIndex = 1;
            this.wrapper_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.wrapper_panel_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.title_tb);
            this.panel2.Location = new System.Drawing.Point(17, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(355, 30);
            this.panel2.TabIndex = 12;
            // 
            // title_tb
            // 
            this.title_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title_tb.Location = new System.Drawing.Point(-2, -1);
            this.title_tb.Name = "title_tb";
            this.title_tb.Size = new System.Drawing.Size(355, 29);
            this.title_tb.TabIndex = 0;
            // 
            // cancel_btn
            // 
            this.cancel_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cancel_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel_btn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_btn.ForeColor = System.Drawing.Color.White;
            this.cancel_btn.Location = new System.Drawing.Point(197, 247);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(175, 35);
            this.cancel_btn.TabIndex = 11;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // updateNote_btn
            // 
            this.updateNote_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.updateNote_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.updateNote_btn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateNote_btn.ForeColor = System.Drawing.Color.White;
            this.updateNote_btn.Location = new System.Drawing.Point(16, 247);
            this.updateNote_btn.Name = "updateNote_btn";
            this.updateNote_btn.Size = new System.Drawing.Size(175, 35);
            this.updateNote_btn.TabIndex = 9;
            this.updateNote_btn.Text = "Update";
            this.updateNote_btn.UseVisualStyleBackColor = false;
            this.updateNote_btn.Click += new System.EventHandler(this.updateNote_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.noteText_rtb);
            this.panel1.Location = new System.Drawing.Point(17, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(355, 195);
            this.panel1.TabIndex = 0;
            // 
            // noteText_rtb
            // 
            this.noteText_rtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noteText_rtb.Location = new System.Drawing.Point(-2, -2);
            this.noteText_rtb.Name = "noteText_rtb";
            this.noteText_rtb.Size = new System.Drawing.Size(355, 195);
            this.noteText_rtb.TabIndex = 0;
            this.noteText_rtb.Text = "";
            // 
            // EditNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(386, 286);
            this.Controls.Add(this.wrapper_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditNote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Edit Note";
            this.Load += new System.EventHandler(this.EditNote_Load);
            this.wrapper_panel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel wrapper_panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox title_tb;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.Button updateNote_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox noteText_rtb;

    }
}