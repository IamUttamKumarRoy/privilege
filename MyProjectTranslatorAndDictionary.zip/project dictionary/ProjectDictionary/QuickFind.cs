﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ProjectDictionary
{
    public partial class QuickFind : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        public QuickFind()
        {
            InitializeComponent();
        }

        private void QuickFind_Load(object sender, EventArgs e)
        {

        }

        private void search_tb_TextChanged(object sender, EventArgs e)
        {
            if (search_tb.Text != "")
            {
                try
                {                    
                    string detail;
                    con.Open();
                    string query = "select * from dictionary where english_word like '"+search_tb.Text+"%'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    az_lb.Items.Clear();
                    while(reader.Read())
                    {                        
                        detail = "";
                        detail += reader.GetString(1).ToUpper().Trim() + " ";
                        detail += "(" + reader.GetString(2).Trim() + ")\n";
                        //detail += reader.GetString(3) + "\n";
                        az_lb.Items.Add(detail);
                    }
                    /*
                     reader.Read();
                    if (reader.HasRows)
                    {
                        result_tv.Items.Clear();
                    }
                    if (reader.HasRows)
                    {
                        detail = "";
                        detail += reader.GetString(1).ToUpper().Trim() + " ";
                        detail += "(" + reader.GetString(2).Trim() + ")\n";
                        detail += reader.GetString(3) + "\n";
                        result_tv.Items.Add(detail);
                    }
                    */
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void find_btn_Click(object sender, EventArgs e)
        {
            if (search_tb.Text != "")
            {
                try
                {
                    string detail,temp;
                    con.Open();
                    string query = "select * from dictionary where english_word ='" + search_tb.Text + "'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    reader.Read();
                    if (reader.HasRows)
                    {
                        result_tv.Items.Clear();
                        result_lb.Items.Clear();
                        detail = "";
                        temp = "";
                        temp += reader.GetString(1).ToUpper().Trim() + " ";
                        temp += "(" + reader.GetString(2).Trim() + ")\n";
                        detail =temp+ reader.GetString(3) + "\n";
                        result_tv.Items.Add(detail);
                        result_lb.Items.Add(temp);
                        //MessageBox.Show("" + search_tb.Text);
                        while(reader.Read())
                        {
                            detail = "";
                            detail += reader.GetString(1).ToUpper().Trim() + " ";
                            detail += "(" + reader.GetString(2).Trim() + ")\n";
                            //detail += reader.GetString(3) + "\n";
                            result_lb.Items.Add(detail);
                        }
                    }
                    
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please Enter Any Word And Search");
            }
        }

        private void az_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (az_lb.Items.Count > 0 && az_lb.SelectedIndex != -1)
            {
                string eng_word;
                string[] word = az_lb.SelectedItem.ToString().Split('(');
                eng_word = word[0];
                try
                {
                    string detail, temp;
                    con.Open();
                    string query = "select * from dictionary where english_word ='" + eng_word + "'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    reader.Read();
                    if (reader.HasRows)
                    {
                        result_tv.Items.Clear();
                        detail = "";
                        temp = "";
                        temp += reader.GetString(1).ToUpper().Trim() + " ";
                        temp += "(" + reader.GetString(2).Trim() + ")\n";
                        detail = temp + reader.GetString(3) + "\n";
                        result_tv.Items.Add(detail);
                        //MessageBox.Show("" + search_tb.Text);
                    }

                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void result_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (result_lb.Items.Count > 0 && result_lb.SelectedIndex != -1)
            {
                string eng_word;
                string[] word = result_lb.SelectedItem.ToString().Split('(');
                eng_word = word[0];
                try
                {
                    string detail, temp;
                    con.Open();
                    string query = "select * from dictionary where english_word ='" + eng_word + "'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                    reader.Read();
                    if (reader.HasRows)
                    {
                        result_tv.Items.Clear();
                        detail = "";
                        temp = "";
                        temp += reader.GetString(1).ToUpper().Trim() + " ";
                        temp += "(" + reader.GetString(2).Trim() + ")\n";
                        detail = temp + reader.GetString(3) + "\n";
                        result_tv.Items.Add(detail);
                        //MessageBox.Show("" + search_tb.Text);
                    }

                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
