﻿namespace ProjectDictionary
{
    partial class InsertWord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.english_word_lb = new System.Windows.Forms.Label();
            this.english_word_tb = new System.Windows.Forms.TextBox();
            this.part_of_speech_lb = new System.Windows.Forms.Label();
            this.part_of_speech_cb = new System.Windows.Forms.ComboBox();
            this.bangla_word_lb = new System.Windows.Forms.Label();
            this.bangla_word_tb = new System.Windows.Forms.TextBox();
            this.category_lb = new System.Windows.Forms.Label();
            this.category_cb = new System.Windows.Forms.ComboBox();
            this.topic_lb = new System.Windows.Forms.Label();
            this.topic_cb = new System.Windows.Forms.ComboBox();
            this.first_person_lb = new System.Windows.Forms.Label();
            this.first_person_tb = new System.Windows.Forms.TextBox();
            this.second_person_lb = new System.Windows.Forms.Label();
            this.second_person_tb = new System.Windows.Forms.TextBox();
            this.third_person_lb = new System.Windows.Forms.Label();
            this.third_person_tb = new System.Windows.Forms.TextBox();
            this.comment_rtb = new System.Windows.Forms.RichTextBox();
            this.comment_lb = new System.Windows.Forms.Label();
            this.add_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // english_word_lb
            // 
            this.english_word_lb.AutoSize = true;
            this.english_word_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.english_word_lb.ForeColor = System.Drawing.Color.White;
            this.english_word_lb.Location = new System.Drawing.Point(9, 15);
            this.english_word_lb.Name = "english_word_lb";
            this.english_word_lb.Size = new System.Drawing.Size(166, 23);
            this.english_word_lb.TabIndex = 0;
            this.english_word_lb.Text = "English Word";
            // 
            // english_word_tb
            // 
            this.english_word_tb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.english_word_tb.Location = new System.Drawing.Point(181, 15);
            this.english_word_tb.Name = "english_word_tb";
            this.english_word_tb.Size = new System.Drawing.Size(203, 29);
            this.english_word_tb.TabIndex = 1;
            // 
            // part_of_speech_lb
            // 
            this.part_of_speech_lb.AutoSize = true;
            this.part_of_speech_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part_of_speech_lb.ForeColor = System.Drawing.Color.White;
            this.part_of_speech_lb.Location = new System.Drawing.Point(9, 50);
            this.part_of_speech_lb.Name = "part_of_speech_lb";
            this.part_of_speech_lb.Size = new System.Drawing.Size(192, 23);
            this.part_of_speech_lb.TabIndex = 2;
            this.part_of_speech_lb.Text = "Part Of Speech";
            // 
            // part_of_speech_cb
            // 
            this.part_of_speech_cb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part_of_speech_cb.FormattingEnabled = true;
            this.part_of_speech_cb.Items.AddRange(new object[] {
            "Article",
            "Noun",
            "Pronoun",
            "Adjective",
            "Verb",
            "Adverb",
            "Preposition",
            "Conjunction",
            "Interjection"});
            this.part_of_speech_cb.Location = new System.Drawing.Point(207, 50);
            this.part_of_speech_cb.Name = "part_of_speech_cb";
            this.part_of_speech_cb.Size = new System.Drawing.Size(177, 31);
            this.part_of_speech_cb.TabIndex = 3;
            // 
            // bangla_word_lb
            // 
            this.bangla_word_lb.AutoSize = true;
            this.bangla_word_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bangla_word_lb.ForeColor = System.Drawing.Color.White;
            this.bangla_word_lb.Location = new System.Drawing.Point(9, 87);
            this.bangla_word_lb.Name = "bangla_word_lb";
            this.bangla_word_lb.Size = new System.Drawing.Size(153, 23);
            this.bangla_word_lb.TabIndex = 4;
            this.bangla_word_lb.Text = "Bangla Word";
            // 
            // bangla_word_tb
            // 
            this.bangla_word_tb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bangla_word_tb.Location = new System.Drawing.Point(181, 87);
            this.bangla_word_tb.Name = "bangla_word_tb";
            this.bangla_word_tb.Size = new System.Drawing.Size(203, 29);
            this.bangla_word_tb.TabIndex = 5;
            // 
            // category_lb
            // 
            this.category_lb.AutoSize = true;
            this.category_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.category_lb.ForeColor = System.Drawing.Color.White;
            this.category_lb.Location = new System.Drawing.Point(87, 122);
            this.category_lb.Name = "category_lb";
            this.category_lb.Size = new System.Drawing.Size(114, 23);
            this.category_lb.TabIndex = 6;
            this.category_lb.Text = "Category";
            // 
            // category_cb
            // 
            this.category_cb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.category_cb.FormattingEnabled = true;
            this.category_cb.Items.AddRange(new object[] {
            "Others",
            "headwords",
            "phrasal verbs",
            "phrases",
            "idioms",
            "definations",
            "example"});
            this.category_cb.Location = new System.Drawing.Point(207, 122);
            this.category_cb.Name = "category_cb";
            this.category_cb.Size = new System.Drawing.Size(177, 31);
            this.category_cb.TabIndex = 7;
            // 
            // topic_lb
            // 
            this.topic_lb.AutoSize = true;
            this.topic_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topic_lb.ForeColor = System.Drawing.Color.White;
            this.topic_lb.Location = new System.Drawing.Point(87, 159);
            this.topic_lb.Name = "topic_lb";
            this.topic_lb.Size = new System.Drawing.Size(75, 23);
            this.topic_lb.TabIndex = 8;
            this.topic_lb.Text = "Topic";
            // 
            // topic_cb
            // 
            this.topic_cb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topic_cb.FormattingEnabled = true;
            this.topic_cb.Items.AddRange(new object[] {
            "Others",
            "Biology",
            "Chemistry",
            "Clothing",
            "Colours",
            "Communications Technology",
            "Computer Technology",
            "Crime & Law",
            "Education",
            "Environmental issues",
            "Feelings",
            "Finance & Bussiness",
            "Food & Drinks"});
            this.topic_cb.Location = new System.Drawing.Point(181, 159);
            this.topic_cb.Name = "topic_cb";
            this.topic_cb.Size = new System.Drawing.Size(203, 31);
            this.topic_cb.TabIndex = 9;
            // 
            // first_person_lb
            // 
            this.first_person_lb.AutoSize = true;
            this.first_person_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first_person_lb.ForeColor = System.Drawing.Color.White;
            this.first_person_lb.Location = new System.Drawing.Point(9, 200);
            this.first_person_lb.Name = "first_person_lb";
            this.first_person_lb.Size = new System.Drawing.Size(244, 23);
            this.first_person_lb.TabIndex = 10;
            this.first_person_lb.Text = "1st Person Meaning";
            // 
            // first_person_tb
            // 
            this.first_person_tb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first_person_tb.Location = new System.Drawing.Point(259, 200);
            this.first_person_tb.Name = "first_person_tb";
            this.first_person_tb.Size = new System.Drawing.Size(125, 29);
            this.first_person_tb.TabIndex = 11;
            // 
            // second_person_lb
            // 
            this.second_person_lb.AutoSize = true;
            this.second_person_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.second_person_lb.ForeColor = System.Drawing.Color.White;
            this.second_person_lb.Location = new System.Drawing.Point(9, 241);
            this.second_person_lb.Name = "second_person_lb";
            this.second_person_lb.Size = new System.Drawing.Size(244, 23);
            this.second_person_lb.TabIndex = 12;
            this.second_person_lb.Text = "2nd Person Meaning";
            // 
            // second_person_tb
            // 
            this.second_person_tb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.second_person_tb.Location = new System.Drawing.Point(259, 241);
            this.second_person_tb.Name = "second_person_tb";
            this.second_person_tb.Size = new System.Drawing.Size(125, 29);
            this.second_person_tb.TabIndex = 13;
            // 
            // third_person_lb
            // 
            this.third_person_lb.AutoSize = true;
            this.third_person_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.third_person_lb.ForeColor = System.Drawing.Color.White;
            this.third_person_lb.Location = new System.Drawing.Point(12, 281);
            this.third_person_lb.Name = "third_person_lb";
            this.third_person_lb.Size = new System.Drawing.Size(244, 23);
            this.third_person_lb.TabIndex = 14;
            this.third_person_lb.Text = "2nd Person Meaning";
            // 
            // third_person_tb
            // 
            this.third_person_tb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.third_person_tb.Location = new System.Drawing.Point(259, 281);
            this.third_person_tb.Name = "third_person_tb";
            this.third_person_tb.Size = new System.Drawing.Size(125, 29);
            this.third_person_tb.TabIndex = 15;
            // 
            // comment_rtb
            // 
            this.comment_rtb.Location = new System.Drawing.Point(130, 330);
            this.comment_rtb.Name = "comment_rtb";
            this.comment_rtb.Size = new System.Drawing.Size(254, 65);
            this.comment_rtb.TabIndex = 16;
            this.comment_rtb.Text = "";
            // 
            // comment_lb
            // 
            this.comment_lb.AutoSize = true;
            this.comment_lb.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comment_lb.ForeColor = System.Drawing.Color.White;
            this.comment_lb.Location = new System.Drawing.Point(12, 330);
            this.comment_lb.Name = "comment_lb";
            this.comment_lb.Size = new System.Drawing.Size(114, 23);
            this.comment_lb.TabIndex = 17;
            this.comment_lb.Text = "Comments";
            // 
            // add_btn
            // 
            this.add_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.add_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_btn.ForeColor = System.Drawing.Color.White;
            this.add_btn.Location = new System.Drawing.Point(266, 409);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(118, 34);
            this.add_btn.TabIndex = 18;
            this.add_btn.Text = "Add Word";
            this.add_btn.UseVisualStyleBackColor = false;
            this.add_btn.Click += new System.EventHandler(this.add_btn_Click);
            // 
            // InsertWord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(399, 456);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.comment_lb);
            this.Controls.Add(this.comment_rtb);
            this.Controls.Add(this.third_person_tb);
            this.Controls.Add(this.third_person_lb);
            this.Controls.Add(this.second_person_tb);
            this.Controls.Add(this.second_person_lb);
            this.Controls.Add(this.first_person_tb);
            this.Controls.Add(this.first_person_lb);
            this.Controls.Add(this.topic_cb);
            this.Controls.Add(this.topic_lb);
            this.Controls.Add(this.category_cb);
            this.Controls.Add(this.category_lb);
            this.Controls.Add(this.bangla_word_tb);
            this.Controls.Add(this.bangla_word_lb);
            this.Controls.Add(this.part_of_speech_cb);
            this.Controls.Add(this.part_of_speech_lb);
            this.Controls.Add(this.english_word_tb);
            this.Controls.Add(this.english_word_lb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "InsertWord";
            this.Text = "Insert Word to Database";
            this.Load += new System.EventHandler(this.InsertWord_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label english_word_lb;
        private System.Windows.Forms.TextBox english_word_tb;
        private System.Windows.Forms.Label part_of_speech_lb;
        private System.Windows.Forms.ComboBox part_of_speech_cb;
        private System.Windows.Forms.Label bangla_word_lb;
        private System.Windows.Forms.TextBox bangla_word_tb;
        private System.Windows.Forms.Label category_lb;
        private System.Windows.Forms.ComboBox category_cb;
        private System.Windows.Forms.Label topic_lb;
        private System.Windows.Forms.ComboBox topic_cb;
        private System.Windows.Forms.Label first_person_lb;
        private System.Windows.Forms.TextBox first_person_tb;
        private System.Windows.Forms.Label second_person_lb;
        private System.Windows.Forms.TextBox second_person_tb;
        private System.Windows.Forms.Label third_person_lb;
        private System.Windows.Forms.TextBox third_person_tb;
        private System.Windows.Forms.RichTextBox comment_rtb;
        private System.Windows.Forms.Label comment_lb;
        private System.Windows.Forms.Button add_btn;
    }
}