﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Speech.AudioFormat;
using System.Speech.Recognition;
using System.Speech.Recognition.SrgsGrammar;
using System.Speech.Synthesis;
using System.Speech.Synthesis.TtsEngine;

namespace ProjectDictionary
{
    public partial class main : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        ClassEnglish2Bangla etb = new ClassEnglish2Bangla();

        public main()
        {
            InitializeComponent();
        }

        private void main_Load(object sender, EventArgs e)
        {
            show_all_word();
        }
        //------------------------------------------------------
        public void show_all_word()
        {
            try
            {
                con.Open();
                SqlDataReader reader;
                string query = "select english_word from dictionary order by english_word";
                SqlCommand com = new SqlCommand(query,con);
                reader = com.ExecuteReader();
                while(reader.Read())
                {
                    az_list_lb.Items.Add(reader.GetString(0));
                }
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Follwing Error Occurred!\n\n"+Ex.Message.ToString());
            }
            finally
            {                
                con.Close();
            }
        }
        //------------------------------------------------------
        private void az_list_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(az_list_lb.SelectedItem.ToString());
            try
            {
                con.Open();                
                SqlDataReader reader;
                string query = "select * from dictionary where english_word ='" + az_list_lb.SelectedItem.ToString() + "'";
               // string query = "select * from dictionary";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                result_tv.Items.Clear();
                string temp;
                while (reader.Read())
                {
                    temp = "";
                    temp += reader.GetString(1).ToUpper().Trim() + "";
                    temp += "(" + reader.GetString(2).Trim() + ")\n";
                    temp += reader.GetString(3) + "\n";
                    //temp +="Category:"+ reader.GetString(4).ToString() + "\n";
                    //temp += "Topic:" + reader.GetString(5).ToString() + "\n";    
                    result_tv.Items.Add(temp);                                       
                }
                result_tv.Items[0].Selected = true;
                result_tv.Select();
                result_tv.Items[0].Focused = true;
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n\n"+Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        //------------------------------------------------------
        public void result_list(string english_word)
        {
            try
            {
                con.Open();
                SqlDataReader reader;
                string query = "select english_word,part_of_speech from dictionary where english_word like '" + english_word + "%'";
                // string query = "select * from dictionary";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                string temp;
                result_lb.Items.Clear();
                while (reader.Read())
                {
                    temp = "";
                    temp = reader.GetString(0).ToUpper().Trim() + " ";
                    //temp += "(" + reader.GetString(1).Trim() + ")";
                    result_lb.Items.Add(temp);
                    //MessageBox.Show(temp);
                }
                result_tv.Items[0].Selected = true;
                result_tv.Select();
                result_tv.Items[0].Focused = true;
                reader.Close();
            }
            catch //(Exception Ex)
            {
                //MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        //------------------------------------------------------
        private void result_rtb_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(result_rtb);
            MessageBox.Show("Hello");
        }
        //------------------------------------------------------
        private void find_btn_Click(object sender, EventArgs e)
        {
            try
            {
               // ~ERROR
                string details = "";
                if (search_tb.Text!="")
                {
                    result_list(search_tb.Text); 
                    details = etb.get_detailsByWord(search_tb.Text);
                    if(details=="")
                    {
                        MessageBox.Show("The Word Does not Exist in the Dictionary");
                    }
                    else if (details.IndexOf("~ERROR") == 1)
                    {
                        MessageBox.Show("Error!" + details);
                    }
                    else
                    {
                        result_tv.Items.Clear();
                        result_tv.Items.Add(details);
                        result_tv.Items[0].Selected = true;
                        result_tv.Select();
                        result_tv.Items[0].Focused = true;
                        etb.increment_wordView(search_tb.Text);// Increment Word Views 
                        etb.insertSearchedWord(search_tb.Text);// Insert Search Word to "searched_word" table                                                                      
                    }
                }
               else
                {
                    MessageBox.Show("Enter your desire word and then press find button\n");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show("??Following Error Occured!\n\n"+Ex.Message.ToString());
            }
            finally
            {
                
            }
        }
        //------------------------------------------------------
        private void result_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(az_list_lb.SelectedItem.ToString());
            try
            {
                con.Open();
                SqlDataReader reader;
                string query = "select * from dictionary where english_word ='" + result_lb.SelectedItem.ToString() + "'";
                //MessageBox.Show(query);
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                result_tv.Items.Clear();
                string temp;
                while (reader.Read())
                {
                    temp = "";
                    temp += reader.GetString(1).ToUpper().Trim() + " ";
                    temp += "(" + reader.GetString(2).Trim() + ")\n";
                    temp += reader.GetString(3) + "\n";
                    result_tv.Items.Add(temp);
                }
                result_tv.Items[0].Selected = true;
                result_tv.Select();
                result_tv.Items[0].Focused=true;
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        //------------------------------------------------------
        private void insertAddWordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertWord insert_form = new InsertWord();
            insert_form.Show();
        }
        //------------------------------------------------------
        private void searched_word_btn_Click(object sender, EventArgs e)
        {
            SearchedWord search_form = new SearchedWord();
            search_form.ShowDialog();
        }
        //------------------------------------------------------
        private void speak_btn_Click(object sender, EventArgs e)
        {
            try
            {
                string text = search_tb.Text;
                if (search_tb.Text != "")
                {
                    text = search_tb.Text;
                    SpeechSynthesizer speech_synth = new SpeechSynthesizer();
                    speech_synth.Volume = 100;
                    speech_synth.Rate = -1;
                    //MessageBox.Show("Search Text Box Worked:" + text);
                    speech_synth.Speak(text);
                }
                else    
                {
                    if (az_list_lb.SelectedItem.ToString() != null)
                    {
                        text = az_list_lb.SelectedItem.ToString();
                        SpeechSynthesizer speech_synth = new SpeechSynthesizer();
                        speech_synth.Volume = 100;
                        speech_synth.Rate = -1;
                        //MessageBox.Show("az_list_lb.SelectedItem.ToString Worked:" + text);
                        speech_synth.Speak(text);
                    }
                    else if (result_lb.SelectedItem.ToString() != null)
                    {
                        text = result_lb.SelectedItem.ToString();
                        SpeechSynthesizer speech_synth = new SpeechSynthesizer();
                        speech_synth.Volume = 100;
                        speech_synth.Rate = -1;
                        //MessageBox.Show("result_lb.SelectedItem.ToString Worked:" + text);
                        speech_synth.Speak(text);
                    }
                    else if (result_tv.SelectedItems.ToString() != null)
                    {
                        text = result_tv.SelectedItems.ToString();
                        SpeechSynthesizer speech_synth = new SpeechSynthesizer();
                        speech_synth.Volume = 100;
                        speech_synth.Rate = -1;
                        //MessageBox.Show("result_tv.SelectedItems.ToString Worked:" + text);
                        speech_synth.Speak(text);
                    }
                }
            }
            catch// (Exception Ex)
            {
                //MessageBox.Show("Please Select Any Word from list box click Speak Button Or\nCheck Your Audio Deviece");
               // MessageBox.Show("Following Error Occured!\n"+Ex.Message.ToString());
            }
            finally
            {
            }
        }
        //------------------------------------------------------
        private void mylist_btn_Click(object sender, EventArgs e)
        {
            MyList mylist_form = new MyList();
            if (result_tv.Items.Count>0)
            {
             mylist_form.setSelectedText(result_tv.SelectedItems[0].Text);
             //MessageBox.Show("" + result_tv.SelectedItems[0].Text);
            }
            mylist_form.Show();
        }
        //------------------------------------------------------
        private void result_tv_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (result_tv.Items.Count == 1)
            {
                if (result_tv.Items[0].Selected == false)
                {
                    result_tv.Items[0].Selected = true;
                    result_tv.Select();
                    result_tv.Items[0].Focused = true;
                }
            }
        }
        //------------------------------------------------------
        private void adv_search_btn_Click(object sender, EventArgs e)
        {
            AdvancedSearch adv_form = new AdvancedSearch();
            adv_form.ShowDialog();
            //adv_form.Show();
        }
        //------------------------------------------------------
        private void mynote_btn_Click(object sender, EventArgs e)
        {
            MyNote mn_form = new MyNote();
            mn_form.ShowDialog();
        }
        //------------------------------------------------------
        private void quickFind_btn_Click(object sender, EventArgs e)
        {
            QuickFind qf_form = new QuickFind();
            qf_form.ShowDialog();
        }
        //------------------------------------------------------
        private void importWordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportImportWord eiw_form = new ExportImportWord();
            eiw_form.ShowDialog();
        }
        //------------------------------------------------------
        private void translatorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        //------------------------------------------------------
        private void importNoteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportImportNote ex_in = new ExportImportNote();
            ex_in.ShowDialog();
        }
        //------------------------------------------------------
        private void aboutDeveloperToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About_Dev abd_form = new About_Dev();
            abd_form.ShowDialog();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //------------------------------------------------------
    }
}
