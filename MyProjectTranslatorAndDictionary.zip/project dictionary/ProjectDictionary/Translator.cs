﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace ProjectDictionary
{
    public partial class Translator : Form
    {
        String[] tag = new String[20];
        String[] bangla = new String[20];
        String[] english = new String[20];     
        int len;
        string prev_tag = "", subj, verb, obj;//, pre_prev_tag = "";
        ClassTranslator trans = new ClassTranslator();

        public Translator()
        {
            InitializeComponent();
        }
        private void Translator_Load(object sender, EventArgs e)
        {
            /*for (int i = 0; i < 10; i++)
            {
                tag[i] = "";
                bangla[i] = "";
            }
            */
        }
        //
        private void pos_btn_Click(object sender, EventArgs e)
        {
            if (sentence_tb.Text != "")
            {
                string sentence;
                string[] spl_sentence;
                int i = 0;
                //sentence = sentence_tb.Text.ToLower();
                sentence = sentence_tb.Text;//
                sentence = Regex.Replace(sentence, "    ", " ");
                sentence = Regex.Replace(sentence, "   ", " ");
                sentence = Regex.Replace(sentence, "  ", " ");
                spl_sentence = Regex.Split(sentence, " ");
                result_rtb.Text = "";
                sentence = "";
                len = spl_sentence.Length;
                //MessageBox.Show("Length:"+len.ToString());
                foreach (string word in spl_sentence)
                {
                    sentence += word + "(" + trans.get_partOfSpeech(word.Trim()).Trim() + "-";
                    sentence += trans.get_bangla(word.Trim(), trans.get_partOfSpeech(word.Trim())).Trim() + ")\n";

                    //tag[i] = trans.get_partOfSpeech(word.Trim()).Trim();
                    //bangla[i] = trans.get_bangla(word.Trim());
                    i++;
                }
                result_rtb.Text = sentence + "\n\n";
                //show_sentense();
            }
            else
            {
                sentence_tb.Focus();
                MessageBox.Show("Please Enter Some text and then Press Find POS Button");
            }
        }
        //-------------------
        private void translate_btn_Click(object sender, EventArgs e)
        {
            if (sentence_tb.Text != "")
            {
                string sentence;
                string[] spl_sentence;
                int i = 0;
                sentence = sentence_tb.Text;
                sentence = Regex.Replace(sentence, "    ", " ");
                sentence = Regex.Replace(sentence, "   ", " ");
                sentence = Regex.Replace(sentence, "  ", " ");
                spl_sentence = Regex.Split(sentence, " ");
                result_rtb.Text = "";
                sentence = "";
                len = spl_sentence.Length;
                //MessageBox.Show("Length:" + len.ToString());
                foreach (string word in spl_sentence)
                {
                    tag[i] = trans.get_partOfSpeech(word.Trim()).Trim();
                    english[i] = word.Trim();
                    bangla[i] = trans.get_bangla(word.Trim(), trans.get_partOfSpeech(word.Trim()));
                    i++;
                }
                //show_sentense();
                trans.setDetails(tag,bangla,english,len);
                //result_rtb.Text = trans.translate()+"\n";
                //result_rtb.Text += trans.translate_v2();
                result_rtb.Text += trans.translate_v3();
            }
            else
            {
                sentence_tb.Focus();
                MessageBox.Show("Please Enter Some text and then Press Translate Button");
            }
        }
        // Translate English TO bangla Sentence
        public void show_sentense()
        {
            int i;
            subj = "";
            obj = "";
            verb = "";
            //string test = "";            
            //MessageBox.Show(len.ToString());
            for (i = 0; i < len; i++)
            {
                //test = bangla[i]+" ";
                //MessageBox.Show("BM:"+bangla[i]);
                /*if (i == 0 && tag[i] == "Determiner")
                {
                    prev_tag = "Determiner";
                    if (english[i] == "the" || english[i] == "The")
                    {
                    }
                    else
                    {
                        subj += " " + bangla[i].Trim();
                    }
                }
                */
                if (i == 0 && tag[i] == "Article")
                {
                    prev_tag = "Determiner";
                    if (english[i] == "the" || english[i] == "The")
                    {
                    }
                    else
                    {
                        subj += " " + bangla[i].Trim();
                    }
                }
                else if (i == 0 && tag[i] == "Noun")
                {
                    prev_tag = "Noun";
                    subj += "" + bangla[i].Trim();
                }
                else if (i == 0 && tag[i] == "Pronoun")
                {
                    prev_tag = "Pronoun";
                    subj += "" + bangla[i].Trim();
                }
                else if (prev_tag == "Determiner" && tag[i] == "Noun")
                {
                    //pre_prev_tag = "Determiner";
                    prev_tag = "Noun";
                    subj += " " + bangla[i].Trim();
                }
                else if (prev_tag == "Noun" && tag[i] == "Adjective" && verb == "")
                {
                    //pre_prev_tag = "Noun";
                    prev_tag = "Adjective";
                    subj += " " + bangla[i].Trim();
                }
                else if (tag[i] == "Verb" && verb == "")
                {
                    prev_tag = "Verb";
                    verb = " " + bangla[i].Trim();
                }
                else
                {
                    obj += " " + bangla[i].Trim();
                }
            }
            //MessageBox.Show(subj + obj + verb);
            //MessageBox.Show(subj + obj + verb);
            result_rtb.Text += subj + obj + verb;
            //result_rtb.Text += test;
        }

        private void result_rtb_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show(result_rtb.SelectedText);
        }

        private void result_rtb_TextChanged(object sender, EventArgs e)
        {

        }
        //--------------------------------------

    }
}
