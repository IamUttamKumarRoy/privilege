﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class AddNote : Form
    {
        public AddNote()
        {
            InitializeComponent();
        }
        public string note_text { get; set; }
        public string note_title { get; set; }
        private void AddNote_Load(object sender, EventArgs e)
        {

        }
        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
        }

        private void addNote_btn_Click(object sender, EventArgs e)
        {
            note_text = noteText_rtb.Text;
            note_title = title_tb.Text;
            this.DialogResult = DialogResult.OK;
        }

        private void wrapper_panel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
