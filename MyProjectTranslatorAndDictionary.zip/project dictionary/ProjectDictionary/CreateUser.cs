﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class CreateUser : Form
    {
        public string username { get; set; }
        //public string test2 { get; set; }
        public CreateUser()
        {
            InitializeComponent();
        }

        private void ok_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.username = userName_tb.Text;
            //this.test2 = "Testing";
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void CreateUser_Load(object sender, EventArgs e)
        {

        }
    }
}
