﻿namespace ProjectDictionary
{
    partial class Exercise_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.home_btn = new System.Windows.Forms.Button();
            this.voice_exercise_btn = new System.Windows.Forms.Button();
            this.exercise_btn = new System.Windows.Forms.Button();
            this.grammar_btn = new System.Windows.Forms.Button();
            this.translator_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.advanced_dic_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.YellowGreen;
            this.panel1.Controls.Add(this.home_btn);
            this.panel1.Controls.Add(this.voice_exercise_btn);
            this.panel1.Controls.Add(this.exercise_btn);
            this.panel1.Controls.Add(this.grammar_btn);
            this.panel1.Controls.Add(this.translator_btn);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.advanced_dic_btn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(10, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(537, 373);
            this.panel1.TabIndex = 15;
            // 
            // home_btn
            // 
            this.home_btn.BackColor = System.Drawing.Color.OliveDrab;
            this.home_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.home_btn.Location = new System.Drawing.Point(385, 299);
            this.home_btn.Name = "home_btn";
            this.home_btn.Size = new System.Drawing.Size(108, 34);
            this.home_btn.TabIndex = 16;
            this.home_btn.Text = "Back";
            this.home_btn.UseVisualStyleBackColor = false;
            this.home_btn.Click += new System.EventHandler(this.home_btn_Click);
            // 
            // voice_exercise_btn
            // 
            this.voice_exercise_btn.BackColor = System.Drawing.Color.Olive;
            this.voice_exercise_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.voice_exercise_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voice_exercise_btn.ForeColor = System.Drawing.Color.White;
            this.voice_exercise_btn.Location = new System.Drawing.Point(47, 252);
            this.voice_exercise_btn.Name = "voice_exercise_btn";
            this.voice_exercise_btn.Size = new System.Drawing.Size(446, 26);
            this.voice_exercise_btn.TabIndex = 14;
            this.voice_exercise_btn.Text = "5.  Voice";
            this.voice_exercise_btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.voice_exercise_btn.UseVisualStyleBackColor = false;
            this.voice_exercise_btn.Click += new System.EventHandler(this.voice_exercise_btn_Click);
            // 
            // exercise_btn
            // 
            this.exercise_btn.BackColor = System.Drawing.Color.Olive;
            this.exercise_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exercise_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exercise_btn.ForeColor = System.Drawing.Color.White;
            this.exercise_btn.Location = new System.Drawing.Point(47, 220);
            this.exercise_btn.Name = "exercise_btn";
            this.exercise_btn.Size = new System.Drawing.Size(446, 26);
            this.exercise_btn.TabIndex = 13;
            this.exercise_btn.Text = "4.  Preposition";
            this.exercise_btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.exercise_btn.UseVisualStyleBackColor = false;
            this.exercise_btn.Click += new System.EventHandler(this.exercise_btn_Click);
            // 
            // grammar_btn
            // 
            this.grammar_btn.BackColor = System.Drawing.Color.Olive;
            this.grammar_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.grammar_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grammar_btn.ForeColor = System.Drawing.Color.White;
            this.grammar_btn.Location = new System.Drawing.Point(47, 188);
            this.grammar_btn.Name = "grammar_btn";
            this.grammar_btn.Size = new System.Drawing.Size(446, 26);
            this.grammar_btn.TabIndex = 12;
            this.grammar_btn.Text = "3.  Right Form of Verb";
            this.grammar_btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.grammar_btn.UseVisualStyleBackColor = false;
            this.grammar_btn.Click += new System.EventHandler(this.grammar_btn_Click);
            // 
            // translator_btn
            // 
            this.translator_btn.BackColor = System.Drawing.Color.Olive;
            this.translator_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.translator_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.translator_btn.ForeColor = System.Drawing.Color.White;
            this.translator_btn.Location = new System.Drawing.Point(47, 156);
            this.translator_btn.Name = "translator_btn";
            this.translator_btn.Size = new System.Drawing.Size(446, 26);
            this.translator_btn.TabIndex = 11;
            this.translator_btn.Text = "2.  Adjective";
            this.translator_btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.translator_btn.UseVisualStyleBackColor = false;
            this.translator_btn.Click += new System.EventHandler(this.translator_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label2.Location = new System.Drawing.Point(43, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Category";
            // 
            // advanced_dic_btn
            // 
            this.advanced_dic_btn.BackColor = System.Drawing.Color.Olive;
            this.advanced_dic_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.advanced_dic_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advanced_dic_btn.ForeColor = System.Drawing.Color.White;
            this.advanced_dic_btn.Location = new System.Drawing.Point(47, 124);
            this.advanced_dic_btn.Name = "advanced_dic_btn";
            this.advanced_dic_btn.Size = new System.Drawing.Size(446, 26);
            this.advanced_dic_btn.TabIndex = 9;
            this.advanced_dic_btn.Text = "1.  Article";
            this.advanced_dic_btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.advanced_dic_btn.UseVisualStyleBackColor = false;
            this.advanced_dic_btn.Click += new System.EventHandler(this.advanced_dic_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Maiandra GD", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(152, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Grammar Exercise";
            // 
            // Exercise_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(556, 387);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Exercise_Main";
            this.Text = "Exercise Home";
            this.Load += new System.EventHandler(this.Main_Exercise_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button home_btn;
        private System.Windows.Forms.Button voice_exercise_btn;
        private System.Windows.Forms.Button exercise_btn;
        private System.Windows.Forms.Button grammar_btn;
        private System.Windows.Forms.Button translator_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button advanced_dic_btn;
        private System.Windows.Forms.Label label1;

    }
}