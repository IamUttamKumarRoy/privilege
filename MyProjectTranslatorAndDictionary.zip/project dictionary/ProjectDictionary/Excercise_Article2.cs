﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class Excercise_article2 : Form
    {
        public Excercise_article2()
        {
            InitializeComponent();
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            question_1_tb.Text = "";
            question_2_tb.Text = "";
            question_3_tb.Text = "";
            question_4_tb.Text = "";
            question_5_tb.Text = "";
        }

        private void check_btn_Click(object sender, EventArgs e)
        {
            int correct_ans = 0, wrong_ans = 0, total_ans = 0;
            if (question_1_tb.Text != "")
            {
                if (question_1_tb.Text.ToLower() == "the")
                {
                    correct_ans++;
                    question_1_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_1_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End First Question
            if (question_2_tb.Text != "")
            {
                if (question_2_tb.Text.ToLower() == "a")
                {
                    correct_ans++;
                    question_2_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_2_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Second Question
            if (question_3_tb.Text != "")
            {
                if (question_3_tb.Text.ToLower() == "an")
                {
                    correct_ans++;
                    question_3_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_3_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Third Question
            if (question_4_tb.Text != "")
            {
                if (question_4_tb.Text.ToLower() == "the")
                {
                    correct_ans++;
                    question_4_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_4_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Fourth Question
            if (question_5_tb.Text != "")
            {
                if (question_5_tb.Text.ToLower() == "the")
                {
                    correct_ans++;
                    question_5_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_5_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Fourth Question
            status_lb.Text = total_ans + " Answered " + correct_ans + " Correct " + wrong_ans + " Wrong";
        }

        private void show_ans_btn_Click(object sender, EventArgs e)
        {
            question_1_tb.ForeColor = question_2_tb.ForeColor = question_3_tb.ForeColor = question_4_tb.ForeColor = question_5_tb.ForeColor = Color.Green;
            question_1_tb.Text = "the";
            question_2_tb.Text = "a";
            question_3_tb.Text = "an";
            question_4_tb.Text = "the";
            question_5_tb.Text = "the";
        }

        private void exercise_btn_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
