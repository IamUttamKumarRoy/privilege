﻿namespace ProjectDictionary
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importNoteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertAddWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutDeveloperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adv_search_btn = new System.Windows.Forms.Button();
            this.mylist_btn = new System.Windows.Forms.Button();
            this.mynote_btn = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.az_list_tp = new System.Windows.Forms.TabPage();
            this.az_list_lb = new System.Windows.Forms.ListBox();
            this.result_tp = new System.Windows.Forms.TabPage();
            this.result_lb = new System.Windows.Forms.ListBox();
            this.search_tb = new System.Windows.Forms.TextBox();
            this.find_btn = new System.Windows.Forms.Button();
            this.speak_btn = new System.Windows.Forms.Button();
            this.quickFind_btn = new System.Windows.Forms.Button();
            this.searched_word_btn = new System.Windows.Forms.Button();
            this.result_tv = new System.Windows.Forms.ListView();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.az_list_tp.SuspendLayout();
            this.result_tp.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(565, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importWordToolStripMenuItem,
            this.importNoteToolStripMenuItem,
            this.insertAddWordToolStripMenuItem,
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // importWordToolStripMenuItem
            // 
            this.importWordToolStripMenuItem.Name = "importWordToolStripMenuItem";
            this.importWordToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.importWordToolStripMenuItem.Text = "Export / Import Word";
            this.importWordToolStripMenuItem.Click += new System.EventHandler(this.importWordToolStripMenuItem_Click);
            // 
            // importNoteToolStripMenuItem
            // 
            this.importNoteToolStripMenuItem.Name = "importNoteToolStripMenuItem";
            this.importNoteToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.importNoteToolStripMenuItem.Text = "Export / Import Note";
            this.importNoteToolStripMenuItem.Click += new System.EventHandler(this.importNoteToolStripMenuItem_Click);
            // 
            // insertAddWordToolStripMenuItem
            // 
            this.insertAddWordToolStripMenuItem.Name = "insertAddWordToolStripMenuItem";
            this.insertAddWordToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.insertAddWordToolStripMenuItem.Text = "Insert / Add Word";
            this.insertAddWordToolStripMenuItem.Click += new System.EventHandler(this.insertAddWordToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(186, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutDeveloperToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutDeveloperToolStripMenuItem
            // 
            this.aboutDeveloperToolStripMenuItem.Name = "aboutDeveloperToolStripMenuItem";
            this.aboutDeveloperToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.aboutDeveloperToolStripMenuItem.Text = "About Developer";
            this.aboutDeveloperToolStripMenuItem.Click += new System.EventHandler(this.aboutDeveloperToolStripMenuItem_Click);
            // 
            // adv_search_btn
            // 
            this.adv_search_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.adv_search_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.adv_search_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adv_search_btn.ForeColor = System.Drawing.Color.White;
            this.adv_search_btn.Location = new System.Drawing.Point(4, 27);
            this.adv_search_btn.Name = "adv_search_btn";
            this.adv_search_btn.Size = new System.Drawing.Size(186, 34);
            this.adv_search_btn.TabIndex = 1;
            this.adv_search_btn.Text = "ADVANCED SEARCH";
            this.adv_search_btn.UseVisualStyleBackColor = false;
            this.adv_search_btn.Click += new System.EventHandler(this.adv_search_btn_Click);
            // 
            // mylist_btn
            // 
            this.mylist_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.mylist_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.mylist_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mylist_btn.ForeColor = System.Drawing.Color.White;
            this.mylist_btn.Location = new System.Drawing.Point(319, 27);
            this.mylist_btn.Name = "mylist_btn";
            this.mylist_btn.Size = new System.Drawing.Size(118, 34);
            this.mylist_btn.TabIndex = 2;
            this.mylist_btn.Text = "MY LIST";
            this.mylist_btn.UseVisualStyleBackColor = false;
            this.mylist_btn.Click += new System.EventHandler(this.mylist_btn_Click);
            // 
            // mynote_btn
            // 
            this.mynote_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.mynote_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.mynote_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mynote_btn.ForeColor = System.Drawing.Color.White;
            this.mynote_btn.Location = new System.Drawing.Point(442, 27);
            this.mynote_btn.Name = "mynote_btn";
            this.mynote_btn.Size = new System.Drawing.Size(118, 34);
            this.mynote_btn.TabIndex = 3;
            this.mynote_btn.Text = "MY NOTE";
            this.mynote_btn.UseVisualStyleBackColor = false;
            this.mynote_btn.Click += new System.EventHandler(this.mynote_btn_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.az_list_tp);
            this.tabControl1.Controls.Add(this.result_tp);
            this.tabControl1.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(4, 105);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(43, 5);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(276, 426);
            this.tabControl1.TabIndex = 4;
            // 
            // az_list_tp
            // 
            this.az_list_tp.BackColor = System.Drawing.Color.White;
            this.az_list_tp.Controls.Add(this.az_list_lb);
            this.az_list_tp.Location = new System.Drawing.Point(4, 4);
            this.az_list_tp.Name = "az_list_tp";
            this.az_list_tp.Padding = new System.Windows.Forms.Padding(3);
            this.az_list_tp.Size = new System.Drawing.Size(268, 393);
            this.az_list_tp.TabIndex = 0;
            this.az_list_tp.Text = "A-Z LIST";
            // 
            // az_list_lb
            // 
            this.az_list_lb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.az_list_lb.FormattingEnabled = true;
            this.az_list_lb.ItemHeight = 23;
            this.az_list_lb.Location = new System.Drawing.Point(-1, -1);
            this.az_list_lb.Name = "az_list_lb";
            this.az_list_lb.Size = new System.Drawing.Size(272, 395);
            this.az_list_lb.TabIndex = 0;
            this.az_list_lb.SelectedIndexChanged += new System.EventHandler(this.az_list_lb_SelectedIndexChanged);
            // 
            // result_tp
            // 
            this.result_tp.Controls.Add(this.result_lb);
            this.result_tp.Location = new System.Drawing.Point(4, 4);
            this.result_tp.Name = "result_tp";
            this.result_tp.Padding = new System.Windows.Forms.Padding(3);
            this.result_tp.Size = new System.Drawing.Size(268, 393);
            this.result_tp.TabIndex = 1;
            this.result_tp.Text = "Result";
            this.result_tp.UseVisualStyleBackColor = true;
            // 
            // result_lb
            // 
            this.result_lb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_lb.FormattingEnabled = true;
            this.result_lb.ItemHeight = 23;
            this.result_lb.Location = new System.Drawing.Point(-1, -1);
            this.result_lb.Name = "result_lb";
            this.result_lb.Size = new System.Drawing.Size(276, 418);
            this.result_lb.TabIndex = 0;
            this.result_lb.SelectedIndexChanged += new System.EventHandler(this.result_lb_SelectedIndexChanged);
            // 
            // search_tb
            // 
            this.search_tb.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_tb.Location = new System.Drawing.Point(5, 69);
            this.search_tb.Name = "search_tb";
            this.search_tb.Size = new System.Drawing.Size(185, 26);
            this.search_tb.TabIndex = 5;
            // 
            // find_btn
            // 
            this.find_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.find_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.find_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find_btn.ForeColor = System.Drawing.Color.White;
            this.find_btn.Location = new System.Drawing.Point(196, 69);
            this.find_btn.Name = "find_btn";
            this.find_btn.Size = new System.Drawing.Size(84, 27);
            this.find_btn.TabIndex = 7;
            this.find_btn.Text = "FIND";
            this.find_btn.UseVisualStyleBackColor = false;
            this.find_btn.Click += new System.EventHandler(this.find_btn_Click);
            // 
            // speak_btn
            // 
            this.speak_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.speak_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.speak_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speak_btn.ForeColor = System.Drawing.Color.White;
            this.speak_btn.Location = new System.Drawing.Point(286, 69);
            this.speak_btn.Name = "speak_btn";
            this.speak_btn.Size = new System.Drawing.Size(106, 27);
            this.speak_btn.TabIndex = 10;
            this.speak_btn.Text = "SPEAK";
            this.speak_btn.UseVisualStyleBackColor = false;
            this.speak_btn.Click += new System.EventHandler(this.speak_btn_Click);
            // 
            // quickFind_btn
            // 
            this.quickFind_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.quickFind_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.quickFind_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quickFind_btn.ForeColor = System.Drawing.Color.White;
            this.quickFind_btn.Location = new System.Drawing.Point(196, 27);
            this.quickFind_btn.Name = "quickFind_btn";
            this.quickFind_btn.Size = new System.Drawing.Size(118, 34);
            this.quickFind_btn.TabIndex = 11;
            this.quickFind_btn.Text = "QUICK FIND";
            this.quickFind_btn.UseVisualStyleBackColor = false;
            this.quickFind_btn.Click += new System.EventHandler(this.quickFind_btn_Click);
            // 
            // searched_word_btn
            // 
            this.searched_word_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.searched_word_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searched_word_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searched_word_btn.ForeColor = System.Drawing.Color.White;
            this.searched_word_btn.Location = new System.Drawing.Point(398, 69);
            this.searched_word_btn.Name = "searched_word_btn";
            this.searched_word_btn.Size = new System.Drawing.Size(162, 27);
            this.searched_word_btn.TabIndex = 12;
            this.searched_word_btn.Text = "SEARCHED WORD";
            this.searched_word_btn.UseVisualStyleBackColor = false;
            this.searched_word_btn.Click += new System.EventHandler(this.searched_word_btn_Click);
            // 
            // result_tv
            // 
            this.result_tv.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.result_tv.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_tv.Location = new System.Drawing.Point(289, 105);
            this.result_tv.MultiSelect = false;
            this.result_tv.Name = "result_tv";
            this.result_tv.Size = new System.Drawing.Size(271, 397);
            this.result_tv.TabIndex = 13;
            this.result_tv.TileSize = new System.Drawing.Size(265, 50);
            this.result_tv.UseCompatibleStateImageBehavior = false;
            this.result_tv.View = System.Windows.Forms.View.Tile;
            this.result_tv.SelectedIndexChanged += new System.EventHandler(this.result_tv_SelectedIndexChanged);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(565, 536);
            this.Controls.Add(this.result_tv);
            this.Controls.Add(this.searched_word_btn);
            this.Controls.Add(this.quickFind_btn);
            this.Controls.Add(this.speak_btn);
            this.Controls.Add(this.find_btn);
            this.Controls.Add(this.search_tb);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.mynote_btn);
            this.Controls.Add(this.mylist_btn);
            this.Controls.Add(this.adv_search_btn);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "English To Bangla Dictionary";
            this.Load += new System.EventHandler(this.main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.az_list_tp.ResumeLayout(false);
            this.result_tp.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importWordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importNoteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertAddWordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutDeveloperToolStripMenuItem;
        private System.Windows.Forms.Button adv_search_btn;
        private System.Windows.Forms.Button mylist_btn;
        private System.Windows.Forms.Button mynote_btn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage az_list_tp;
        private System.Windows.Forms.TabPage result_tp;
        private System.Windows.Forms.ListBox result_lb;
        private System.Windows.Forms.TextBox search_tb;
        private System.Windows.Forms.Button find_btn;
        private System.Windows.Forms.Button speak_btn;
        private System.Windows.Forms.Button quickFind_btn;
        private System.Windows.Forms.Button searched_word_btn;
        public System.Windows.Forms.ListView result_tv;
        public System.Windows.Forms.ListBox az_list_lb;
    }
}

