﻿namespace ProjectDictionary
{
    partial class MyList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rename_btn = new System.Windows.Forms.Button();
            this.delete_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.create_list_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.all_user_lb = new System.Windows.Forms.ListBox();
            this.deleteFromList_btn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.addToList_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.result_tv = new System.Windows.Forms.ListView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // rename_btn
            // 
            this.rename_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.rename_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.rename_btn.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rename_btn.ForeColor = System.Drawing.Color.White;
            this.rename_btn.Location = new System.Drawing.Point(171, 378);
            this.rename_btn.Name = "rename_btn";
            this.rename_btn.Size = new System.Drawing.Size(72, 30);
            this.rename_btn.TabIndex = 7;
            this.rename_btn.Text = "Rename List";
            this.rename_btn.UseVisualStyleBackColor = false;
            this.rename_btn.Click += new System.EventHandler(this.rename_btn_Click);
            // 
            // delete_btn
            // 
            this.delete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.delete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_btn.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete_btn.ForeColor = System.Drawing.Color.White;
            this.delete_btn.Location = new System.Drawing.Point(104, 378);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(63, 30);
            this.delete_btn.TabIndex = 6;
            this.delete_btn.Text = "Delete List";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.create_list_btn);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.delete_btn);
            this.panel1.Controls.Add(this.rename_btn);
            this.panel1.Location = new System.Drawing.Point(8, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(260, 415);
            this.panel1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "User List";
            // 
            // create_list_btn
            // 
            this.create_list_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.create_list_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.create_list_btn.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.create_list_btn.ForeColor = System.Drawing.Color.White;
            this.create_list_btn.Location = new System.Drawing.Point(15, 378);
            this.create_list_btn.Name = "create_list_btn";
            this.create_list_btn.Size = new System.Drawing.Size(86, 30);
            this.create_list_btn.TabIndex = 8;
            this.create_list_btn.Text = "Create New List";
            this.create_list_btn.UseVisualStyleBackColor = false;
            this.create_list_btn.Click += new System.EventHandler(this.create_list_btn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.all_user_lb);
            this.panel2.Location = new System.Drawing.Point(14, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(230, 349);
            this.panel2.TabIndex = 0;
            // 
            // all_user_lb
            // 
            this.all_user_lb.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.all_user_lb.FormattingEnabled = true;
            this.all_user_lb.ItemHeight = 23;
            this.all_user_lb.Location = new System.Drawing.Point(-2, -2);
            this.all_user_lb.Name = "all_user_lb";
            this.all_user_lb.Size = new System.Drawing.Size(230, 349);
            this.all_user_lb.TabIndex = 1;
            this.all_user_lb.SelectedIndexChanged += new System.EventHandler(this.all_user_lb_SelectedIndexChanged);
            // 
            // deleteFromList_btn
            // 
            this.deleteFromList_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.deleteFromList_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deleteFromList_btn.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteFromList_btn.ForeColor = System.Drawing.Color.White;
            this.deleteFromList_btn.Location = new System.Drawing.Point(149, 378);
            this.deleteFromList_btn.Name = "deleteFromList_btn";
            this.deleteFromList_btn.Size = new System.Drawing.Size(125, 30);
            this.deleteFromList_btn.TabIndex = 17;
            this.deleteFromList_btn.Text = "Delete From List";
            this.deleteFromList_btn.UseVisualStyleBackColor = false;
            this.deleteFromList_btn.Click += new System.EventHandler(this.deleteFromList_btn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.addToList_btn);
            this.panel3.Controls.Add(this.deleteFromList_btn);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(276, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(290, 415);
            this.panel3.TabIndex = 18;
            // 
            // addToList_btn
            // 
            this.addToList_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.addToList_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addToList_btn.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addToList_btn.ForeColor = System.Drawing.Color.White;
            this.addToList_btn.Location = new System.Drawing.Point(14, 378);
            this.addToList_btn.Name = "addToList_btn";
            this.addToList_btn.Size = new System.Drawing.Size(125, 30);
            this.addToList_btn.TabIndex = 10;
            this.addToList_btn.Text = "Add To List";
            this.addToList_btn.UseVisualStyleBackColor = false;
            this.addToList_btn.Click += new System.EventHandler(this.addToList_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(110, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Word List";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.result_tv);
            this.panel4.Location = new System.Drawing.Point(14, 23);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 349);
            this.panel4.TabIndex = 0;
            // 
            // result_tv
            // 
            this.result_tv.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.result_tv.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_tv.Location = new System.Drawing.Point(-2, -2);
            this.result_tv.MultiSelect = false;
            this.result_tv.Name = "result_tv";
            this.result_tv.Size = new System.Drawing.Size(260, 349);
            this.result_tv.TabIndex = 15;
            this.result_tv.TileSize = new System.Drawing.Size(200, 50);
            this.result_tv.UseCompatibleStateImageBehavior = false;
            this.result_tv.View = System.Windows.Forms.View.Tile;
            this.result_tv.SelectedIndexChanged += new System.EventHandler(this.result_tv_SelectedIndexChanged);
            // 
            // MyList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(574, 428);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "MyList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Word List By User";
            this.Load += new System.EventHandler(this.MyList_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button rename_btn;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox all_user_lb;
        private System.Windows.Forms.Button create_list_btn;
        private System.Windows.Forms.Button deleteFromList_btn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button addToList_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ListView result_tv;

    }
}