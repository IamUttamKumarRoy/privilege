﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class InsertWord : Form
    {
        ClassEnglish2Bangla e2b = new ClassEnglish2Bangla();
        public InsertWord()
        {
            InitializeComponent();
        }

        private void InsertWord_Load(object sender, EventArgs e)
        {

        }
        //----------------------
        private void add_btn_Click(object sender, EventArgs e)
        {
            if (english_word_tb.Text != "" && part_of_speech_cb.Text != "" && bangla_word_tb.Text != "")
            {
                e2b.add_Word(english_word_tb.Text,part_of_speech_cb.Text,bangla_word_tb.Text,
                    category_cb.Text,topic_cb.Text,first_person_tb.Text,second_person_tb.Text,
                    third_person_tb.Text,comment_rtb.Text);
                clearControl();// Clear the entered field 
            }
            else
            {
                string msg = "English Word\nPart Of Speech &\nBangla Meaning Must be given";
                MessageBox.Show(msg);
            }
        }
        //-------------------------
        public void clearControl()
        {
            english_word_tb.Text = "";
            part_of_speech_cb.SelectedIndex = 0;
            bangla_word_tb.Text = "";
            category_cb.SelectedIndex = 0;
            topic_cb.SelectedIndex = 0;
            first_person_tb.Text = "";
            second_person_tb.Text = "";
            third_person_tb.Text = "";
            comment_rtb.Text = "";
        }
    }
}
