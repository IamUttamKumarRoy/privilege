﻿namespace ProjectDictionary
{
    partial class About_Dev
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_uttam = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.about_uttam_lb = new System.Windows.Forms.Label();
            this.panel_uttam_pic = new System.Windows.Forms.Panel();
            this.pictureBox_uttam = new System.Windows.Forms.PictureBox();
            this.panel_uttam.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel_uttam_pic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uttam)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_uttam
            // 
            this.panel_uttam.BackColor = System.Drawing.Color.YellowGreen;
            this.panel_uttam.Controls.Add(this.panel5);
            this.panel_uttam.Controls.Add(this.panel_uttam_pic);
            this.panel_uttam.Location = new System.Drawing.Point(25, 12);
            this.panel_uttam.Name = "panel_uttam";
            this.panel_uttam.Size = new System.Drawing.Size(311, 482);
            this.panel_uttam.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.about_uttam_lb);
            this.panel5.Location = new System.Drawing.Point(29, 291);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(258, 188);
            this.panel5.TabIndex = 1;
            // 
            // about_uttam_lb
            // 
            this.about_uttam_lb.AutoSize = true;
            this.about_uttam_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.about_uttam_lb.Location = new System.Drawing.Point(3, 6);
            this.about_uttam_lb.Name = "about_uttam_lb";
            this.about_uttam_lb.Size = new System.Drawing.Size(181, 168);
            this.about_uttam_lb.TabIndex = 1;
            this.about_uttam_lb.Text = "Uttam Kumar Roy\r\nSession:2007-08\r\nRoll:0714012\r\nReg No:1016\r\nDept of CSE\r\nIslamic" +
                " University\r\nKushtia,Bangladesh.\r\n";
            this.about_uttam_lb.Click += new System.EventHandler(this.about_uttam_lb_Click);
            // 
            // panel_uttam_pic
            // 
            this.panel_uttam_pic.BackColor = System.Drawing.Color.YellowGreen;
            this.panel_uttam_pic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_uttam_pic.Controls.Add(this.pictureBox_uttam);
            this.panel_uttam_pic.Location = new System.Drawing.Point(14, 10);
            this.panel_uttam_pic.Name = "panel_uttam_pic";
            this.panel_uttam_pic.Size = new System.Drawing.Size(273, 274);
            this.panel_uttam_pic.TabIndex = 0;
            // 
            // pictureBox_uttam
            // 
            this.pictureBox_uttam.Image = global::ProjectDictionary.Properties.Resources.about_UKR;
            this.pictureBox_uttam.Location = new System.Drawing.Point(8, 7);
            this.pictureBox_uttam.Name = "pictureBox_uttam";
            this.pictureBox_uttam.Size = new System.Drawing.Size(258, 260);
            this.pictureBox_uttam.TabIndex = 0;
            this.pictureBox_uttam.TabStop = false;
            this.pictureBox_uttam.Click += new System.EventHandler(this.pictureBox_uttam_Click);
            // 
            // About_Dev
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkViolet;
            this.ClientSize = new System.Drawing.Size(364, 504);
            this.Controls.Add(this.panel_uttam);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "About_Dev";
            this.Text = "About Devloper";
            this.Load += new System.EventHandler(this.About_Dev_Load);
            this.panel_uttam.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel_uttam_pic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uttam)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_uttam;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label about_uttam_lb;
        private System.Windows.Forms.Panel panel_uttam_pic;
        private System.Windows.Forms.PictureBox pictureBox_uttam;


    }
}