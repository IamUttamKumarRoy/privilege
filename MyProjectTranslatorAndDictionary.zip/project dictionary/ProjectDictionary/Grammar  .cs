﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace ProjectDictionary
{
    public partial class Grammar : Form
    {
        public Grammar()
        {
            InitializeComponent();
        }
        private void Grammar_Load(object sender, EventArgs e)
        {
            
        }
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string fileName="";
            string dir = @"C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\Resourcess\grammar\";
           /*
            if (treeView1.SelectedNode.Text=="Part of Speech")
            {
                fileName = dir + "pos.txt";
            }
            */
            fileName = dir + treeView1.SelectedNode.Text + ".txt";
            //MessageBox.Show(fileName);
            desc_rtb.Text = get_text(fileName);
        }
        //------------------------------------------------------------------
        public string get_text(string fileName)
        {
            string details="";
            if (File.Exists(fileName))
            {
                // display file contents through StreamReader
                try
                {
                    // obtain reader and file contents
                    StreamReader stream = new StreamReader(fileName);
                    details += stream.ReadToEnd();
                } // end try
                // handle exception if StreamReader is unavailable
                catch (IOException)
                {
                    MessageBox.Show("Error reading from file", "File Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                } // end catch
            } // end if
            return details;
        }
        //------------------------------------------------------------------
    }
}
