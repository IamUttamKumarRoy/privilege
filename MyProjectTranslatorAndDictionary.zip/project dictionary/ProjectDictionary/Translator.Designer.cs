﻿namespace ProjectDictionary
{
    partial class Translator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pos_btn = new System.Windows.Forms.Button();
            this.translate_btn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.result_rtb = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.sentence_tb = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.YellowGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pos_btn);
            this.panel1.Controls.Add(this.translate_btn);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(15, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(460, 253);
            this.panel1.TabIndex = 0;
            // 
            // pos_btn
            // 
            this.pos_btn.BackColor = System.Drawing.Color.Olive;
            this.pos_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pos_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pos_btn.ForeColor = System.Drawing.Color.White;
            this.pos_btn.Location = new System.Drawing.Point(133, 200);
            this.pos_btn.Name = "pos_btn";
            this.pos_btn.Size = new System.Drawing.Size(120, 45);
            this.pos_btn.TabIndex = 13;
            this.pos_btn.Text = "Show POS";
            this.pos_btn.UseVisualStyleBackColor = false;
            this.pos_btn.Click += new System.EventHandler(this.pos_btn_Click);
            // 
            // translate_btn
            // 
            this.translate_btn.BackColor = System.Drawing.Color.Olive;
            this.translate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.translate_btn.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.translate_btn.ForeColor = System.Drawing.Color.White;
            this.translate_btn.Location = new System.Drawing.Point(7, 200);
            this.translate_btn.Name = "translate_btn";
            this.translate_btn.Size = new System.Drawing.Size(120, 45);
            this.translate_btn.TabIndex = 12;
            this.translate_btn.Text = "Translate";
            this.translate_btn.UseVisualStyleBackColor = false;
            this.translate_btn.Click += new System.EventHandler(this.translate_btn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.result_rtb);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(7, 43);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(445, 150);
            this.panel3.TabIndex = 1;
            // 
            // result_rtb
            // 
            this.result_rtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_rtb.Location = new System.Drawing.Point(-2, -2);
            this.result_rtb.Name = "result_rtb";
            this.result_rtb.Size = new System.Drawing.Size(445, 150);
            this.result_rtb.TabIndex = 0;
            this.result_rtb.Text = "";
            this.toolTip1.SetToolTip(this.result_rtb, "Translation of Your Sentence");
            this.result_rtb.TextChanged += new System.EventHandler(this.result_rtb_TextChanged);
            this.result_rtb.DoubleClick += new System.EventHandler(this.result_rtb_DoubleClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.sentence_tb);
            this.panel2.Location = new System.Drawing.Point(7, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(445, 30);
            this.panel2.TabIndex = 0;
            // 
            // sentence_tb
            // 
            this.sentence_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sentence_tb.Location = new System.Drawing.Point(-2, -1);
            this.sentence_tb.Name = "sentence_tb";
            this.sentence_tb.Size = new System.Drawing.Size(445, 29);
            this.sentence_tb.TabIndex = 0;
            this.toolTip1.SetToolTip(this.sentence_tb, "Type your desire sentence \r\n[Only Simple Sentence\r\nLike Uttam is a good boy]\r\n");
            // 
            // Translator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(490, 295);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Translator";
            this.Text = "Translator";
            this.Load += new System.EventHandler(this.Translator_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox sentence_tb;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button translate_btn;
        private System.Windows.Forms.Button pos_btn;
        private System.Windows.Forms.RichTextBox result_rtb;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}