﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Data.SqlClient;

namespace ProjectDictionary
{
    public partial class ExportImportWord : Form
    {
        public ExportImportWord()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        ClassExportImport ex_im = new ClassExportImport();
        private void ExportImportWord_Load(object sender, EventArgs e)
        {
            show_user();
        }
        // Show User to List Box
        public void show_user()
        {
            try
            {
                con.Open();
                string query = "select user_name from [user]";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataReader reader = com.ExecuteReader();
                all_user_lb.Items.Clear();
                while (reader.Read())
                {
                    if (reader.HasRows)
                    {
                        all_user_lb.Items.Add(reader.GetString(0));
                    }
                }
                if (all_user_lb.Items.Count > 0)
                {
                    //all_user_lb.SelectedIndex = 0;
                }
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("show_user\nFollowing Error Occured!\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        //----------------------
        private void exportWord_btn_Click(object sender, EventArgs e)
        {
            if (all_user_lb.Items.Count > 0)
            {
              string user_name = all_user_lb.SelectedItem.ToString().Trim();
              //MessageBox.Show("user_name:" + user_name);            
              try
               {
                 con.Open();
                        //DialogResult result = openFileDialog1.ShowDialog();
                   DialogResult result = saveFileDialog1.ShowDialog();
                   if (result == DialogResult.OK)
                    {
                       string name = saveFileDialog1.FileName;
                       //MessageBox.Show(name); 
                       string query;
                       query = "select * from memorize where user_id=";
                       query += "(select id from [user] where user_name='" + user_name + "')";
                       //MessageBox.Show("Query:" + query); 
                       SqlCommand com = new SqlCommand(query, con);
                       SqlDataReader reader = com.ExecuteReader();
                        using (XmlWriter writer = XmlWriter.Create(name + ".xml"))
                         {
                            writer.WriteStartDocument();
                            writer.WriteStartElement(user_name);
                             while (reader.Read())
                              {
                                writer.WriteStartElement("Word_ID");
                                 // writer.WriteElementString("ID", reader.GetInt32(0).ToString());
                                   writer.WriteElementString("ID", reader.GetInt32(2).ToString());
                                writer.WriteEndElement();
                              }
                             writer.WriteEndElement();
                             writer.WriteEndDocument();
                       }
                        MessageBox.Show("User Word Successfully Exported!");
                    }
                   
                }
               catch (Exception ex)
                {
                        MessageBox.Show(ex.Message.ToString());
                }
               finally
                {
                        con.Close();
                }
            }
        }

        private void importWord_btn_Click(object sender, EventArgs e)
        {
            DialogResult openDl = openFileDialog.ShowDialog();            
            if (openDl == DialogResult.OK)
            {
                string fname = openFileDialog.FileName;
                //MessageBox.Show("File Name:"+fname);
                try
                {
                    using (XmlTextReader reader = new XmlTextReader(fname))
                    {
                        string query="";
                        int user_id=0;
                        while (reader.Read())
                        {
                            if (reader.IsStartElement())
                            {
                                switch (reader.Name)
                                {
                                    case "ID":
                                        //Console.WriteLine("ID: " + reader.ReadString());
                                        query += "(" + user_id + "," + reader.ReadString() + "),";
                                        break;
                                    case "Word_ID":
                                        break;
                                    default:
                                        query += "insert into memorize(user_id,word_id) values";                                        
                                        user_id= ex_im.hasUserId(reader.Name);
                                        //MessageBox.Show(user_id.ToString());
                                        if(user_id!=0)
                                        {
                                            //MessageBox.Show("User Already Exist.Do you want to replaced it");
                                            ReplaceConfirm rc_form = new ReplaceConfirm();
                                            if (rc_form.ShowDialog()==DialogResult.No)
                                            {
                                                return;
                                            }                                            
                                        }
                                        if(user_id==0)
                                        {
                                            ex_im.addUser(reader.Name);
                                            user_id = ex_im.getUserID(reader.Name);
                                        }
                                        break;
                                }
                            }
                        }
                        query = query.TrimEnd(',');
                        //query += ")";
                        
                        ex_im.deleteUserWord(user_id);
                        ex_im.insertUserWord(query);
                        MessageBox.Show("Word Successfully Imported\n");
                        //MessageBox.Show("Word Successfully Imported\n"+query.TrimEnd(',') + "\n------------------->");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void all_user_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            exportWord_btn.Enabled = true;
        }
        //-----------------------------
    }
}
