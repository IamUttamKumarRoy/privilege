﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class About_Dev : Form
    {
        public About_Dev()
        {
            InitializeComponent();
        }

        private void About_Dev_Load(object sender, EventArgs e)
        {

        }

        private void about_uttam_lb_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox_uttam_Click(object sender, EventArgs e)
        {

        }
    }
}
