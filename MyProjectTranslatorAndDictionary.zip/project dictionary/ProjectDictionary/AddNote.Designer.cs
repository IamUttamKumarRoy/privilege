﻿namespace ProjectDictionary
{
    partial class AddNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.wrapper_panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.title_tb = new System.Windows.Forms.TextBox();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.addNote_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.noteText_rtb = new System.Windows.Forms.RichTextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.wrapper_panel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // wrapper_panel
            // 
            this.wrapper_panel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.wrapper_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wrapper_panel.Controls.Add(this.panel2);
            this.wrapper_panel.Controls.Add(this.cancel_btn);
            this.wrapper_panel.Controls.Add(this.addNote_btn);
            this.wrapper_panel.Controls.Add(this.panel1);
            this.wrapper_panel.Location = new System.Drawing.Point(0, 0);
            this.wrapper_panel.Name = "wrapper_panel";
            this.wrapper_panel.Size = new System.Drawing.Size(390, 290);
            this.wrapper_panel.TabIndex = 0;
            this.wrapper_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.wrapper_panel_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.title_tb);
            this.panel2.Location = new System.Drawing.Point(17, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(355, 30);
            this.panel2.TabIndex = 12;
            // 
            // title_tb
            // 
            this.title_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title_tb.Location = new System.Drawing.Point(-2, -1);
            this.title_tb.Name = "title_tb";
            this.title_tb.Size = new System.Drawing.Size(355, 29);
            this.title_tb.TabIndex = 0;
            this.toolTip1.SetToolTip(this.title_tb, "Enter Your Title for Note Title");
            // 
            // cancel_btn
            // 
            this.cancel_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cancel_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel_btn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_btn.ForeColor = System.Drawing.Color.White;
            this.cancel_btn.Location = new System.Drawing.Point(197, 247);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(175, 35);
            this.cancel_btn.TabIndex = 11;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // addNote_btn
            // 
            this.addNote_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.addNote_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addNote_btn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addNote_btn.ForeColor = System.Drawing.Color.White;
            this.addNote_btn.Location = new System.Drawing.Point(16, 247);
            this.addNote_btn.Name = "addNote_btn";
            this.addNote_btn.Size = new System.Drawing.Size(175, 35);
            this.addNote_btn.TabIndex = 9;
            this.addNote_btn.Text = "Add ";
            this.addNote_btn.UseVisualStyleBackColor = false;
            this.addNote_btn.Click += new System.EventHandler(this.addNote_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.noteText_rtb);
            this.panel1.Location = new System.Drawing.Point(17, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(355, 195);
            this.panel1.TabIndex = 0;
            // 
            // noteText_rtb
            // 
            this.noteText_rtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noteText_rtb.Location = new System.Drawing.Point(-2, -2);
            this.noteText_rtb.Name = "noteText_rtb";
            this.noteText_rtb.Size = new System.Drawing.Size(355, 195);
            this.noteText_rtb.TabIndex = 0;
            this.noteText_rtb.Text = "";
            this.toolTip1.SetToolTip(this.noteText_rtb, "Enter Your Note Text Hare");
            // 
            // AddNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(390, 290);
            this.Controls.Add(this.wrapper_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddNote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Add Note";
            this.Load += new System.EventHandler(this.AddNote_Load);
            this.wrapper_panel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel wrapper_panel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox noteText_rtb;
        private System.Windows.Forms.Button addNote_btn;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox title_tb;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}