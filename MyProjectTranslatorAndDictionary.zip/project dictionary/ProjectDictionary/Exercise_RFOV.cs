﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProjectDictionary
{
    public partial class Exercise_RFOV : Form
    {
        public Exercise_RFOV()
        {
            InitializeComponent();
        }

        private void Exercise_RFOV_Load(object sender, EventArgs e)
        {

        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            question_1_tb.Text = "";
            question_2_tb.Text = "";
            question_3_tb.Text = "";
            question_4_tb.Text = "";
            question_5_tb.Text = "";
        }
        private void show_ans_btn_Click(object sender, EventArgs e)
        {
            question_1_tb.ForeColor = question_2_tb.ForeColor = question_3_tb.ForeColor = question_4_tb.ForeColor = question_5_tb.ForeColor = Color.Green;
            question_1_tb.Text = "discussed";
            question_2_tb.Text = "to do";
            question_3_tb.Text = "had left";
            question_4_tb.Text = "have passed";
            question_5_tb.Text = "working";
        }

        private void exercise_btn_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void check_btn_Click(object sender, EventArgs e)
        {
            int correct_ans = 0, wrong_ans = 0, total_ans = 0;
            if (question_1_tb.Text != "")
            {
                if (question_1_tb.Text.ToLower() == "discussed")
                {
                    correct_ans++;
                    question_1_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_1_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End First Question
            if (question_2_tb.Text != "")
            {
                if (question_2_tb.Text.ToLower() == "to do")
                {
                    correct_ans++;
                    question_2_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_2_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Second Question
            if (question_3_tb.Text != "")
            {
                if (question_3_tb.Text.ToLower() == "had left")
                {
                    correct_ans++;
                    question_3_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_3_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Third Question
            if (question_4_tb.Text != "")
            {
                if (question_4_tb.Text.ToLower() == "have passed")
                {
                    correct_ans++;
                    question_4_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_4_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Fourth Question
            if (question_5_tb.Text != "")
            {
                if (question_5_tb.Text.ToLower() == "working")
                {
                    correct_ans++;
                    question_5_tb.ForeColor = Color.Green;
                }
                else
                {
                    wrong_ans++;
                    question_5_tb.ForeColor = Color.Red;
                }
                total_ans++;
            }
            // End Fourth Question
            status_lb.Text = total_ans + " Answered " + correct_ans + " Correct " + wrong_ans + " Wrong";

        }
    }
}
