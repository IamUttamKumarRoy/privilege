﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml;
namespace ProjectDictionary
{
    public partial class SearchedWord : Form
    {
        public SearchedWord()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\UTTAM\Documents\Visual Studio 2010\Projects\project dictionary\ProjectDictionary\EnglishToBangla.mdf;Integrated Security=True;User Instance=True");
        private void SearchedWord_Load(object sender, EventArgs e)
        {
            show_all_searched_word();
            check_control();
        }
        public void show_all_searched_word()
        {
            try
            {
                con.Open();
                SqlDataReader reader;
                string query = "select d.english_word as english from dictionary as d,searched_word sw where d.id=sw.word_id";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                all_word_lb.Items.Clear();
                while (reader.Read())
                {
                    all_word_lb.Items.Add(reader.GetString(0));
                }
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Follwing Error Occurred!\n\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        public void check_control()
        {
            if (all_word_lb.Items.Count == 0)
            {
                // delete_btn.FlatStyle = FlatStyle.System;
                delete_btn.Enabled = false;
                // delete_all_btn.FlatStyle = FlatStyle.System;
                delete_all_btn.Enabled = false;
            }
            // Alternative Way
            /*try
            {
                con.Open();
                SqlDataReader reader;
                string query = "select * from searched_word";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                reader.Read();
                if(!reader.HasRows)
                {
                   // delete_btn.FlatStyle = FlatStyle.System;
                    delete_btn.Enabled = false;
                   // delete_all_btn.FlatStyle = FlatStyle.System;
                    delete_all_btn.Enabled = false;
                }
                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
            */
        }
        private void all_word_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(az_list_lb.SelectedItem.ToString());
            try
            {
                con.Open();
                SqlDataReader reader;
                string query = "select * from dictionary where english_word ='" + all_word_lb.SelectedItem.ToString() + "'";
                // string query = "select * from dictionary";
                SqlCommand com = new SqlCommand(query, con);
                reader = com.ExecuteReader();
                string details = "";
                result_tv.Items.Clear();
                while (reader.Read())
                {
                    details += reader.GetString(1).ToUpper().Trim() + " ";
                    details += "(" + reader.GetString(2).Trim() + ")\n";
                    details += reader.GetString(3) + "\n";
                    result_tv.Items.Add(details);
                }

                reader.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Following Error Occured!\n\n" + Ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {           
            if (all_word_lb.SelectedIndex != -1)
            {
                //MessageBox.Show(all_word_lb.SelectedItem.ToString());
                SearchedWordDeleteConfirm confirm_form = new SearchedWordDeleteConfirm();
                if (confirm_form.ShowDialog() == DialogResult.OK)
                {                    
                    try
                    {
                        con.Open();
                        string query = "delete from searched_word where word_id=(select id from dictionary where english_word='" + all_word_lb.SelectedItem.ToString() + "')";
                        SqlCommand com = new SqlCommand(query, con);
                        com.ExecuteNonQuery();
                        //MessageBox.Show(all_word_lb.SelectedItem.ToString() + " is Deleted From List");                        
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("Following Error Occured\n" + Ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                        show_all_searched_word();
                        check_control();
                    }
                }
            }
            else
            {
                MessageBox.Show("Select Any word from list");
            }            
        }

        private void delete_all_btn_Click(object sender, EventArgs e)
        {
           if(all_word_lb.Items.Count==0)
            {
                MessageBox.Show("There is no items in the List");
                return;
            } 

           //MessageBox.Show(all_word_lb.SelectedItem.ToString());
                SearchedWordDeleteConfirm confirm_form = new SearchedWordDeleteConfirm();
          if (confirm_form.ShowDialog() == DialogResult.OK)
           {
              try
                {
                    con.Open();
                    string query = "delete from searched_word";
                    SqlCommand com = new SqlCommand(query, con);
                    com.ExecuteNonQuery();
                    //MessageBox.Show(all_word_lb.SelectedItem.ToString() + " is Deleted From List");                        
                }
              catch (Exception Ex)
                {
                   MessageBox.Show("Following Error Occured\n" + Ex.Message.ToString());
                }
              finally
                {
                    con.Close();
                    show_all_searched_word();
                    check_control();
                }
                
            }   
        }
    }
}
